import type { TtsProvider, TtsSpeakProfile, TtsVoiceInfo } from './types';

interface AndroidTtsBridge {
  listVoices?: () => string;
  speak?: (text: string, lang: string, rate: number, pitch: number, voiceId: string) => void;
  stop?: () => void;
}

interface CapacitorWindow extends Window {
  DznovaAndroidTTS?: AndroidTtsBridge;
}

/**
 * Native Android TextToSpeech provider used inside the Capacitor APK.
 * Uses Android's native TextToSpeech engine (supports ar-DZ / ar / en / fr offline & online voices).
 */
export class NativeAndroidProvider implements TtsProvider {
  public readonly id = 'native_android' as const;

  private getBridge(): AndroidTtsBridge | null {
    if (typeof window === 'undefined') return null;
    return (window as CapacitorWindow).DznovaAndroidTTS ?? null;
  }

  public isAvailable(): boolean {
    return Boolean(this.getBridge()?.speak);
  }

  public async listVoices(): Promise<TtsVoiceInfo[]> {
    const bridge = this.getBridge();
    if (!bridge?.listVoices) return [];
    try {
      const raw = JSON.parse(bridge.listVoices()) as Array<{
        id: string;
        name: string;
        lang: string;
      }>;
      return raw.map((v) => ({
        id: v.id,
        name: v.name,
        lang: v.lang,
        isNatural: v.name.toLowerCase().includes('network') || v.name.toLowerCase().includes('local'),
        provider: 'native_android' as const,
      }));
    } catch {
      return [];
    }
  }

  public cancel(): void {
    this.getBridge()?.stop?.();
  }

  public async speak(text: string, profile: TtsSpeakProfile): Promise<void> {
    const bridge = this.getBridge();
    if (!bridge?.speak) {
      throw new Error('Native Android TTS bridge is unavailable.');
    }
    bridge.speak(text, profile.lang, profile.rate, profile.pitch, profile.voiceId ?? '');
    const estimatedMs = Math.max(1200, Math.ceil((text.length * 85) / Math.max(0.5, profile.rate)));
    await new Promise((r) => setTimeout(r, estimatedMs));
  }
}
