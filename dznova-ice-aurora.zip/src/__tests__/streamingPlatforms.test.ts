import { describe, expect, it } from 'vitest';
import {
  COMPATIBILITY_PROFILES,
  buildOverlayUrl,
  computeHonestStage,
  createInitialPlatformStatus,
  createOverlayTokenRecord,
  isTokenValid,
  revokeOverlayToken,
} from '../engine/OverlayEngine';
import { MockLiveSource } from '../engine/MockLiveSource';

describe('DZNOVA Dual Streaming Platform Workflows', () => {
  it('supports TikTok LIVE Studio URL generation without falsely marking it connected', () => {
    const status = createInitialPlatformStatus('tiktok_live_studio');
    expect(computeHonestStage(status)).toBe('not_configured');

    const token = createOverlayTokenRecord({
      overlayType: 'alerts',
      platform: 'tiktok_live_studio',
      profile: 'tiktok_standard',
      width: 1080,
      height: 1920,
    });
    const url = buildOverlayUrl('https://takieddinexx4-cmyk.github.io/DZ-NOVA/', token);

    expect(url).toContain('#overlay/alerts?');
    expect(url).toContain('platform=tiktok_live_studio');
    expect(url).toContain('profile=tiktok_standard');
    expect(url).toContain(`token=${token.token}`);

    status.urlGeneratedAt = Date.now();
    expect(computeHonestStage(status)).toBe('url_generated');
    expect(computeHonestStage(status)).not.toBe('integration_verified');
  });

  it('supports OBS Studio token revocation and immediately invalidates revoked tokens', () => {
    const rec = createOverlayTokenRecord({
      overlayType: 'wilaya',
      platform: 'obs_studio',
      profile: 'obs_standard',
      width: 1920,
      height: 1080,
    });
    const registry = [rec];
    expect(isTokenValid(registry, rec.token)).toBe(true);

    const updated = revokeOverlayToken(registry, rec.token);
    expect(isTokenValid(updated, rec.token)).toBe(false);
  });

  it('distinguishes Browser Source load from event ingestion before marking integration verified', () => {
    const status = createInitialPlatformStatus('obs_studio');
    status.urlGeneratedAt = Date.now();
    expect(computeHonestStage(status)).toBe('url_generated');

    status.overlayOpenedAt = Date.now();
    expect(computeHonestStage(status)).toBe('overlay_opened');

    // Browser source loaded alone does NOT prove event ingestion
    status.browserSourceLoadedAt = Date.now();
    status.lastHeartbeatAt = Date.now();
    expect(computeHonestStage(status)).toBe('browser_source_loaded');

    // Once both heartbeat AND event ingestion are verified, stage becomes integration_verified
    status.eventSourceActive = true;
    status.lastEventAt = Date.now();
    expect(computeHonestStage(status)).toBe('integration_verified');
  });

  it('allows MockLiveSource to test both TikTok LIVE Studio and OBS Studio workflows', () => {
    const mock = new MockLiveSource();
    const received: string[] = [];
    const unsub = mock.subscribe((ev) => received.push(`${ev.targetPlatform}:${ev.type}`));

    mock.triggerTestGift('tiktok_live_studio');
    mock.triggerTestFollow('obs_studio');
    mock.triggerTestChat('!wilaya', 'all', 'Tester_DZ');
    unsub();

    expect(received).toEqual([
      'tiktok_live_studio:gift',
      'obs_studio:follow',
      'all:chat',
    ]);
  });

  it('exposes all 4 required overlay compatibility profiles', () => {
    expect(Object.keys(COMPATIBILITY_PROFILES).sort()).toEqual([
      'high_quality',
      'lightweight',
      'obs_standard',
      'tiktok_standard',
    ]);
  });
});
