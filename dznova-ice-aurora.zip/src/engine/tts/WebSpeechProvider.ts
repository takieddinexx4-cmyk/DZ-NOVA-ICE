import { chunkTtsText } from './arabicText';
import type { TtsProvider, TtsSpeakProfile, TtsVoiceInfo } from './types';

const FEMALE_HINTS = ['female', 'woman', 'salma', 'zariyah', 'amina', 'fatima', 'rana', 'laila', 'hoda', 'maryam', 'sara', 'nour', 'zeina', 'samantha', 'victoria', 'zira', 'aria', 'jenny'];
const MALE_HINTS = ['male', 'man', 'hamed', 'shakir', 'ismael', 'bassel', 'fahed', 'jamal', 'omar', 'naayf', 'maged', 'tarik', 'david', 'guy', 'mark', 'daniel'];

export function inferVoiceGender(name: string): 'female' | 'male' | 'neutral' {
  const lower = name.toLowerCase();
  if (FEMALE_HINTS.some((h) => lower.includes(h))) return 'female';
  if (MALE_HINTS.some((h) => lower.includes(h))) return 'male';
  return 'neutral';
}

export function isNaturalVoiceName(name: string): boolean {
  const lower = name.toLowerCase();
  return lower.includes('natural') || lower.includes('neural') || lower.includes('online');
}

/**
 * Rank Arabic voices: ar-DZ > ar-MA/ar-TN > ar-SA/ar-EG > any ar-*,
 * boosting Online/Natural/Neural voices at every tier.
 */
export function scoreArabicVoice(voice: Pick<TtsVoiceInfo, 'lang' | 'name' | 'isNatural'>): number {
  const lang = voice.lang.toLowerCase().replace('_', '-');
  let score = 0;
  if (lang === 'ar-dz') score += 1000;
  else if (lang === 'ar-ma' || lang === 'ar-tn') score += 800;
  else if (lang === 'ar-sa' || lang === 'ar-eg') score += 650;
  else if (lang.startsWith('ar')) score += 450;
  else return -1;

  if (voice.isNatural || isNaturalVoiceName(voice.name)) {
    score += 180;
  }
  return score;
}

export function rankArabicVoices<T extends Pick<TtsVoiceInfo, 'lang' | 'name' | 'isNatural'>>(voices: T[]): T[] {
  return voices
    .filter((v) => scoreArabicVoice(v) >= 0)
    .sort((a, b) => scoreArabicVoice(b) - scoreArabicVoice(a));
}

export class WebSpeechProvider implements TtsProvider {
  public readonly id = 'web_speech' as const;
  private cancelled = false;
  private keepAliveTimer: ReturnType<typeof setInterval> | null = null;

  public isAvailable(): boolean {
    return typeof window !== 'undefined' && 'speechSynthesis' in window && typeof SpeechSynthesisUtterance !== 'undefined';
  }

  public async listVoices(): Promise<TtsVoiceInfo[]> {
    if (!this.isAvailable()) return [];
    const synth = window.speechSynthesis;
    let raw = synth.getVoices();

    if (raw.length === 0) {
      raw = await new Promise<SpeechSynthesisVoice[]>((resolve) => {
        let settled = false;
        const done = () => {
          if (settled) return;
          settled = true;
          synth.removeEventListener('voiceschanged', onChanged);
          resolve(synth.getVoices());
        };
        const onChanged = () => {
          if (synth.getVoices().length > 0) done();
        };
        synth.addEventListener('voiceschanged', onChanged);
        setTimeout(done, 1200);
      });
    }

    return raw.map((v) => ({
      id: v.voiceURI || v.name,
      name: v.name,
      lang: v.lang,
      gender: inferVoiceGender(v.name),
      isNatural: isNaturalVoiceName(v.name),
      provider: 'web_speech' as const,
    }));
  }

  public cancel(): void {
    this.cancelled = true;
    this.stopKeepAlive();
    if (this.isAvailable()) {
      window.speechSynthesis.cancel();
    }
  }

  private startKeepAlive(): void {
    this.stopKeepAlive();
    // Chrome/Chromium workaround: prevent long utterances from silently stalling after ~15s
    this.keepAliveTimer = setInterval(() => {
      if (this.isAvailable() && window.speechSynthesis.speaking && !window.speechSynthesis.paused) {
        window.speechSynthesis.pause();
        window.speechSynthesis.resume();
      }
    }, 10000);
  }

  private stopKeepAlive(): void {
    if (this.keepAliveTimer) {
      clearInterval(this.keepAliveTimer);
      this.keepAliveTimer = null;
    }
  }

  public async speak(text: string, profile: TtsSpeakProfile): Promise<void> {
    if (!this.isAvailable()) {
      throw new Error('Web Speech API is not supported in this browser.');
    }
    this.cancelled = false;
    const chunks = chunkTtsText(text, 180);
    if (chunks.length === 0) return;

    const synth = window.speechSynthesis;
    const nativeVoices = synth.getVoices();
    const targetVoice = this.resolveNativeVoice(nativeVoices, profile);

    this.startKeepAlive();
    try {
      for (const chunk of chunks) {
        if (this.cancelled) break;
        await this.speakChunk(synth, chunk, profile, targetVoice);
      }
    } finally {
      this.stopKeepAlive();
    }
  }

  private resolveNativeVoice(
    nativeVoices: SpeechSynthesisVoice[],
    profile: TtsSpeakProfile,
  ): SpeechSynthesisVoice | null {
    if (profile.voiceId) {
      const exact = nativeVoices.find((v) => v.voiceURI === profile.voiceId || v.name === profile.voiceId);
      if (exact) return exact;
    }
    if (profile.lang.toLowerCase().startsWith('ar')) {
      const ranked = rankArabicVoices(
        nativeVoices.map((v) => ({
          lang: v.lang,
          name: v.name,
          isNatural: isNaturalVoiceName(v.name),
          native: v,
        })),
      );
      if (ranked.length > 0) return ranked[0].native;
    }
    const langPrefix = profile.lang.split('-')[0].toLowerCase();
    return (
      nativeVoices.find((v) => v.lang.toLowerCase() === profile.lang.toLowerCase()) ??
      nativeVoices.find((v) => v.lang.toLowerCase().startsWith(langPrefix)) ??
      null
    );
  }

  private speakChunk(
    synth: SpeechSynthesis,
    chunk: string,
    profile: TtsSpeakProfile,
    voice: SpeechSynthesisVoice | null,
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      let settled = false;
      // Scale watchdog to chunk length & speaking rate (minimum 6s, ~130ms per char)
      const watchdogMs = Math.max(6000, Math.ceil((chunk.length * 140) / Math.max(0.5, profile.rate)) + 4000);

      const finish = (err?: Error) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        if (err) reject(err);
        else resolve();
      };

      const timer = setTimeout(() => {
        finish();
      }, watchdogMs);

      const utterance = new SpeechSynthesisUtterance(chunk);
      utterance.lang = voice?.lang || profile.lang;
      if (voice) utterance.voice = voice;
      utterance.pitch = Math.max(0.5, Math.min(2, profile.pitch));
      utterance.rate = Math.max(0.5, Math.min(2, profile.rate));
      utterance.volume = Math.max(0, Math.min(1, profile.volume));

      utterance.onend = () => finish();
      utterance.onerror = (ev) => {
        if (ev.error === 'canceled' || ev.error === 'interrupted') {
          finish();
        } else {
          finish(new Error(`Speech synthesis error: ${ev.error}`));
        }
      };

      synth.speak(utterance);
    });
  }
}
