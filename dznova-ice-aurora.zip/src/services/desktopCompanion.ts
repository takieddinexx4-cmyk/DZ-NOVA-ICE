export interface DesktopDiagnostics {
  runtime: 'tauri_desktop' | 'web_browser';
  osInfo: string;
  obsPort4455Reachable: boolean;
  cachedAssetsCount: number;
  secureStorageAvailable: boolean;
  checkedAt: number;
}

interface TauriWindow extends Window {
  __TAURI_INTERNALS__?: {
    invoke: <T>(cmd: string, args?: Record<string, unknown>) => Promise<T>;
  };
}

export function isTauriDesktop(): boolean {
  return typeof window !== 'undefined' && Boolean((window as TauriWindow).__TAURI_INTERNALS__);
}

async function invokeDesktop<T>(cmd: string, args?: Record<string, unknown>): Promise<T | null> {
  if (!isTauriDesktop()) return null;
  try {
    const tauri = (window as TauriWindow).__TAURI_INTERNALS__;
    if (!tauri) return null;
    return await tauri.invoke<T>(cmd, args);
  } catch {
    return null;
  }
}

export async function runDesktopDiagnostics(): Promise<DesktopDiagnostics> {
  const native = await invokeDesktop<DesktopDiagnostics>('run_system_diagnostics');
  if (native) return native;
  return {
    runtime: 'web_browser',
    osInfo: typeof navigator !== 'undefined' ? navigator.platform || 'Web Browser' : 'Web Browser',
    obsPort4455Reachable: false,
    cachedAssetsCount: 0,
    secureStorageAvailable: typeof window !== 'undefined' && 'localStorage' in window,
    checkedAt: Date.now(),
  };
}

export async function sendNativeNotification(title: string, body: string): Promise<boolean> {
  const native = await invokeDesktop<boolean>('send_desktop_notification', { title, body });
  if (native !== null) return native;
  if (typeof window !== 'undefined' && 'Notification' in window) {
    if (Notification.permission === 'granted') {
      new Notification(title, { body });
      return true;
    }
  }
  return false;
}

export async function saveSecureTokenLocal(key: string, value: string): Promise<boolean> {
  const native = await invokeDesktop<boolean>('save_secure_token', { key, value });
  if (native !== null) return native;
  try {
    window.localStorage.setItem(`dznova_sec_${key}`, btoa(value));
    return true;
  } catch {
    return false;
  }
}

export async function cacheOverlayAssetLocal(name: string, payload: string): Promise<boolean> {
  const native = await invokeDesktop<boolean>('cache_overlay_asset', { name, payload });
  if (native !== null) return native;
  try {
    window.localStorage.setItem(`dznova_cache_${name}`, payload);
    return true;
  } catch {
    return false;
  }
}
