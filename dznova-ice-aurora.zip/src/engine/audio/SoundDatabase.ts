const DB_NAME = 'dznova_audio_store_v31';
const DB_VERSION = 1;
const STORE_CUSTOM_SOUNDS = 'custom_sounds';
const STORE_TTS_CACHE = 'tts_cache';

export interface CustomSoundAsset {
  id: string;
  name: string;
  mimeType: string;
  sizeBytes: number;
  createdAt: number;
  data: ArrayBuffer;
}

const MAX_UPLOAD_BYTES = 3 * 1024 * 1024; // 3 MB
const ALLOWED_MIME_PREFIXES = ['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/x-wav', 'audio/ogg'];

export function validateAudioUpload(file: { name: string; type: string; size: number }): string | null {
  if (file.size <= 0) return 'Audio file is empty.';
  if (file.size > MAX_UPLOAD_BYTES) return 'File exceeds the 3 MB limit.';
  const extOk = /\.(mp3|wav|ogg)$/i.test(file.name);
  const mimeOk = ALLOWED_MIME_PREFIXES.some((m) => file.type.toLowerCase().startsWith(m));
  if (!extOk && !mimeOk) return 'Only MP3, WAV, or OGG audio files are supported.';
  return null;
}

function openDb(): Promise<IDBDatabase | null> {
  if (typeof indexedDB === 'undefined') return Promise.resolve(null);
  return new Promise((resolve) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_CUSTOM_SOUNDS)) {
        db.createObjectStore(STORE_CUSTOM_SOUNDS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_TTS_CACHE)) {
        db.createObjectStore(STORE_TTS_CACHE, { keyPath: 'key' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => resolve(null);
  });
}

export async function saveCustomSound(asset: CustomSoundAsset): Promise<boolean> {
  const db = await openDb();
  if (!db) return false;
  return new Promise((resolve) => {
    const tx = db.transaction(STORE_CUSTOM_SOUNDS, 'readwrite');
    tx.objectStore(STORE_CUSTOM_SOUNDS).put(asset);
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => resolve(false);
  });
}

export async function getCustomSound(id: string): Promise<CustomSoundAsset | null> {
  const db = await openDb();
  if (!db) return null;
  return new Promise((resolve) => {
    const tx = db.transaction(STORE_CUSTOM_SOUNDS, 'readonly');
    const req = tx.objectStore(STORE_CUSTOM_SOUNDS).get(id);
    req.onsuccess = () => resolve((req.result as CustomSoundAsset) ?? null);
    req.onerror = () => resolve(null);
  });
}

export async function listCustomSounds(): Promise<Omit<CustomSoundAsset, 'data'>[]> {
  const db = await openDb();
  if (!db) return [];
  return new Promise((resolve) => {
    const tx = db.transaction(STORE_CUSTOM_SOUNDS, 'readonly');
    const req = tx.objectStore(STORE_CUSTOM_SOUNDS).getAll();
    req.onsuccess = () => {
      const all = (req.result as CustomSoundAsset[]) ?? [];
      resolve(
        all.map(({ id, name, mimeType, sizeBytes, createdAt }) => ({
          id,
          name,
          mimeType,
          sizeBytes,
          createdAt,
        })),
      );
    };
    req.onerror = () => resolve([]);
  });
}

export async function deleteCustomSound(id: string): Promise<boolean> {
  const db = await openDb();
  if (!db) return false;
  return new Promise((resolve) => {
    const tx = db.transaction(STORE_CUSTOM_SOUNDS, 'readwrite');
    tx.objectStore(STORE_CUSTOM_SOUNDS).delete(id);
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => resolve(false);
  });
}

export async function getCachedTtsAudio(key: string): Promise<ArrayBuffer | null> {
  const db = await openDb();
  if (!db) return null;
  return new Promise((resolve) => {
    const tx = db.transaction(STORE_TTS_CACHE, 'readonly');
    const req = tx.objectStore(STORE_TTS_CACHE).get(key);
    req.onsuccess = () => {
      const rec = req.result as { key: string; data: ArrayBuffer } | undefined;
      resolve(rec?.data ?? null);
    };
    req.onerror = () => resolve(null);
  });
}

export async function putCachedTtsAudio(key: string, data: ArrayBuffer): Promise<void> {
  const db = await openDb();
  if (!db) return;
  await new Promise<void>((resolve) => {
    const tx = db.transaction(STORE_TTS_CACHE, 'readwrite');
    tx.objectStore(STORE_TTS_CACHE).put({ key, data, ts: Date.now() });
    tx.oncomplete = () => resolve();
    tx.onerror = () => resolve();
  });
}
