import React, { useEffect, useMemo, useState } from 'react';
import { useDznova } from '../context/DznovaContext';
import { GlassBadge, GlassButton, GlassCard } from '../components/GlassUI';
import { sharedAudioEngine } from '../engine/audio/AudioEngine';
import {
  deleteCustomSound,
  listCustomSounds,
  saveCustomSound,
  validateAudioUpload,
  type CustomSoundAsset,
} from '../engine/audio/SoundDatabase';
import {
  BUILT_IN_SOUNDS,
  loadSoundConfig,
  playSoundById,
  saveSoundConfig,
  type EventSoundRule,
  type SoundCategory,
  type SoundConfigState,
  type SoundEventTrigger,
} from '../engine/audio/SoundLibrary';
import { publishOverlayTransport } from '../engine/OverlayTransport';
import { AudioIcon, ExportIcon, ImportIcon, MusicIcon } from '../components/icons';

const CATEGORIES: { id: 'all' | 'favorites' | SoundCategory; labelAr: string; labelEn: string }[] = [
  { id: 'all', labelAr: 'الكل (44+)', labelEn: 'All (44+)' },
  { id: 'favorites', labelAr: 'المفضلة', labelEn: 'Favorites' },
  { id: 'gifts', labelAr: 'الهدايا', labelEn: 'Gifts' },
  { id: 'ringtones', labelAr: 'رنات وموسيقى', labelEn: 'Ringtones' },
  { id: 'follow_share', labelAr: 'المتابعة والمشاركة', labelEn: 'Follow & Share' },
  { id: 'chat_like', labelAr: 'الدردشة والإعجاب', labelEn: 'Chat & Likes' },
  { id: 'wilaya_wheel', labelAr: 'الولايات والعجلة', labelEn: 'Wilaya & Wheel' },
  { id: 'countdown_alerts', labelAr: 'المؤقت والتنبيهات', labelEn: 'Alerts & Timer' },
  { id: 'stingers', labelAr: 'مؤثرات مرحة', labelEn: 'Fun Stingers' },
  { id: 'custom', labelAr: 'ملفاتي المرفوعة', labelEn: 'Custom Uploads' },
];

const TRIGGERS: { id: SoundEventTrigger; labelAr: string; labelEn: string }[] = [
  { id: 'gift_small', labelAr: 'هدية صغيرة (1+ عملة)', labelEn: 'Small Gift (1+)' },
  { id: 'gift_medium', labelAr: 'هدية متوسطة (100+)', labelEn: 'Medium Gift (100+)' },
  { id: 'gift_big', labelAr: 'هدية كبيرة (500+)', labelEn: 'Big Gift (500+)' },
  { id: 'gift_legendary', labelAr: 'هدية أسطورية (1000+)', labelEn: 'Legendary Gift (1000+)' },
  { id: 'gift_named', labelAr: 'هدية باسم محدد', labelEn: 'Specific Gift Name' },
  { id: 'follow', labelAr: 'متابع جديد', labelEn: 'New Follower' },
  { id: 'share', labelAr: 'مشاركة البث', labelEn: 'Stream Share' },
  { id: 'like_milestone', labelAr: 'إنجاز إعجابات', labelEn: 'Like Milestone' },
  { id: 'chat_keyword', labelAr: 'كلمة في الدردشة', labelEn: 'Chat Keyword' },
  { id: 'wilaya_victory', labelAr: 'انتصار ولاية', labelEn: 'Wilaya Victory' },
  { id: 'countdown_end', labelAr: 'نهاية المؤقت', labelEn: 'Countdown End' },
];

export const SoundboardPage: React.FC = () => {
  const { lang, pushToast } = useDznova();
  const isAr = lang === 'ar';

  const [category, setCategory] = useState<'all' | 'favorites' | SoundCategory>('all');
  const [search, setSearch] = useState('');
  const [masterVol, setMasterVol] = useState<number>(() => sharedAudioEngine.getMasterVolume());
  const [config, setConfig] = useState<SoundConfigState>(() => loadSoundConfig());
  const [customSounds, setCustomSounds] = useState<Omit<CustomSoundAsset, 'data'>[]>([]);
  const [assignSoundId, setAssignSoundId] = useState<string | null>(null);
  const [assignTrigger, setAssignTrigger] = useState<SoundEventTrigger>('gift_big');
  const [assignMatch, setAssignMatch] = useState('');
  const [assignCooldown, setAssignCooldown] = useState(2);

  useEffect(() => {
    void listCustomSounds().then(setCustomSounds);
  }, []);

  const persistConfig = (next: SoundConfigState) => {
    setConfig(next);
    saveSoundConfig(next);
  };

  const toggleFavorite = (id: string) => {
    const exists = config.favorites.includes(id);
    persistConfig({
      ...config,
      favorites: exists ? config.favorites.filter((f) => f !== id) : [...config.favorites, id],
    });
  };

  const handlePlay = async (id: string) => {
    await sharedAudioEngine.unlock();
    void playSoundById(id, { volume: masterVol });
    publishOverlayTransport({ kind: 'sound_play', payload: { soundId: id, volume: masterVol } });
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const err = validateAudioUpload(file);
    if (err) {
      pushToast(isAr ? 'ملف غير مدعوم' : 'Upload rejected', err, 'rose');
      return;
    }
    const data = await file.arrayBuffer();
    const asset: CustomSoundAsset = {
      id: `custom_${Date.now()}`,
      name: file.name,
      mimeType: file.type || 'audio/mpeg',
      sizeBytes: file.size,
      createdAt: Date.now(),
      data,
    };
    await saveCustomSound(asset);
    setCustomSounds(await listCustomSounds());
    pushToast(isAr ? 'تم حفظ الرنة المخصصة في IndexedDB' : 'Custom sound saved to IndexedDB', file.name, 'emerald');
    e.target.value = '';
  };

  const handleExportJson = () => {
    const blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'dznova-sound-config.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportJson = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text()) as SoundConfigState;
      if (!Array.isArray(parsed.rules)) throw new Error('Invalid rules');
      persistConfig(parsed);
      pushToast(isAr ? 'تم استيراد إعدادات الأصوات' : 'Sound config imported', undefined, 'emerald');
    } catch {
      pushToast(isAr ? 'ملف JSON غير صالح' : 'Invalid JSON config', undefined, 'rose');
    }
    e.target.value = '';
  };

  const handleSaveAssignment = () => {
    if (!assignSoundId) return;
    const existingIdx = config.rules.findIndex(
      (r) => r.trigger === assignTrigger && (r.matchValue ?? '') === assignMatch.trim(),
    );
    const nextRules: EventSoundRule[] = [...config.rules];
    if (existingIdx >= 0) {
      const cur = nextRules[existingIdx];
      const mergedIds = cur.soundIds.includes(assignSoundId) ? cur.soundIds : [...cur.soundIds, assignSoundId];
      nextRules[existingIdx] = { ...cur, soundIds: mergedIds, cooldownSec: assignCooldown, enabled: true };
    } else {
      nextRules.push({
        id: `rule_${Date.now()}`,
        trigger: assignTrigger,
        matchValue: assignMatch.trim() || undefined,
        soundIds: [assignSoundId],
        volume: masterVol,
        trimStartSec: 0,
        trimEndSec: 0,
        fadeInSec: 0.01,
        fadeOutSec: 0.04,
        cooldownSec: assignCooldown,
        enabled: true,
      });
    }
    persistConfig({ ...config, rules: nextRules });
    setAssignSoundId(null);
    pushToast(isAr ? 'تم ربط الرنة بالحدث بنجاح' : 'Sound assigned to event', assignTrigger, 'emerald');
  };

  const filteredBuiltIn = useMemo(() => {
    if (category === 'custom') return [];
    return BUILT_IN_SOUNDS.filter((s) => {
      if (category === 'favorites' && !config.favorites.includes(s.id)) return false;
      if (category !== 'all' && category !== 'favorites' && s.category !== category) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        return s.nameAr.toLowerCase().includes(q) || s.nameEn.toLowerCase().includes(q);
      }
      return true;
    });
  }, [category, config.favorites, search]);

  return (
    <div className="space-y-6">
      <GlassCard className="flex flex-wrap items-center justify-between gap-4">
        <div className="ice-title-plate">
          <MusicIcon size={40} />
          <div>
            <h1 className="text-xl font-extrabold sm:text-2xl">
              {isAr ? `مكتبة الأصوات والرنات (${BUILT_IN_SOUNDS.length} صوت + رفع مخصص)` : `Sound & Ringtone Studio (${BUILT_IN_SOUNDS.length} Built-in + Custom)`}
            </h1>
            <p className="text-xs opacity-75">
              {isAr
                ? 'محرك صوتي موحد بضاغط احترافي، خفض تلقائي أثناء النطق (Ducking)، ورنات مقامات عربية وحديثة.'
                : 'Unified Web Audio master bus with compressor, TTS ducking, Arabic-maqam & modern ringtones, and IndexedDB uploads.'}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <label className="flex items-center gap-2 text-xs font-bold">
            <span>{Math.round(masterVol * 100)}%</span>
            <input
              type="range"
              min="0.05"
              max="1"
              step="0.05"
              value={masterVol}
              onChange={(e) => {
                const v = Number(e.target.value);
                setMasterVol(v);
                sharedAudioEngine.setMasterVolume(v);
              }}
            />
          </label>
          <GlassButton size="sm" onClick={handleExportJson}>
            <ExportIcon size={16} />
            <span>JSON</span>
          </GlassButton>
          <label className="ice-pill inline-flex cursor-pointer items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-bold">
            <ImportIcon size={16} />
            <span>{isAr ? 'استيراد' : 'Import'}</span>
            <input type="file" accept=".json" onChange={(e) => void handleImportJson(e)} className="hidden" />
          </label>
          <label className="ice-btn-primary inline-flex cursor-pointer items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs">
            <AudioIcon size={16} />
            <span>{isAr ? 'رفع رنة (≤3MB)' : 'Upload MP3/WAV/OGG'}</span>
            <input type="file" accept=".mp3,.wav,.ogg,audio/*" onChange={(e) => void handleUpload(e)} className="hidden" />
          </label>
        </div>
      </GlassCard>

      {/* Category Tabs + Search */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-1.5">
          {CATEGORIES.map((c) => (
            <GlassButton
              key={c.id}
              size="sm"
              variant={category === c.id ? 'primary' : 'secondary'}
              onClick={() => setCategory(c.id)}
            >
              {isAr ? c.labelAr : c.labelEn}
            </GlassButton>
          ))}
        </div>
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={isAr ? 'ابحث عن صوت أو رنة...' : 'Search sounds & ringtones...'}
          className="rounded-xl border border-ice-crystal/25 bg-ice-midnight/65 px-3 py-2 text-xs text-ice-white"
        />
      </div>

      {/* Custom Uploaded Sounds */}
      {(category === 'all' || category === 'custom') && customSounds.length > 0 && (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {customSounds.map((cs) => (
            <GlassCard key={cs.id} interactive className="flex flex-col justify-between gap-3 p-4">
              <div>
                <GlassBadge tone="violet">Custom</GlassBadge>
                <p className="mt-1 truncate text-sm font-extrabold">{cs.name}</p>
                <p className="text-[11px] opacity-70">{Math.round(cs.sizeBytes / 1024)} KB</p>
              </div>
              <div className="flex flex-wrap gap-1.5">
                <GlassButton size="sm" variant="primary" onClick={() => void handlePlay(cs.id)}>
                  {isAr ? 'تشغيل' : 'Play'}
                </GlassButton>
                <GlassButton size="sm" onClick={() => setAssignSoundId(cs.id)}>
                  {isAr ? 'ربط بحدث' : 'Assign'}
                </GlassButton>
                <GlassButton
                  size="sm"
                  variant="danger"
                  onClick={async () => {
                    await deleteCustomSound(cs.id);
                    setCustomSounds(await listCustomSounds());
                  }}
                >
                  ✕
                </GlassButton>
              </div>
            </GlassCard>
          ))}
        </div>
      )}

      {/* 44 Built-In Touch-Friendly Sound Pads */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {filteredBuiltIn.map((sound) => {
          const isFav = config.favorites.includes(sound.id);
          return (
            <GlassCard key={sound.id} interactive className="flex flex-col justify-between gap-3 p-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-sm font-extrabold">{isAr ? sound.nameAr : sound.nameEn}</p>
                  <span className="font-mono text-[10px] opacity-70">{sound.durationLabel}</span>
                </div>
                <button
                  type="button"
                  onClick={() => toggleFavorite(sound.id)}
                  className={`rounded-lg px-2 py-1 text-xs font-bold ${isFav ? 'text-amber-300' : 'opacity-45 hover:opacity-100'}`}
                  aria-label="Favorite"
                >
                  ★
                </button>
              </div>
              <div className="flex gap-2">
                <GlassButton size="sm" variant="primary" className="flex-1" onClick={() => void handlePlay(sound.id)}>
                  <AudioIcon size={16} />
                  <span>{isAr ? 'تشغيل' : 'Play'}</span>
                </GlassButton>
                <GlassButton size="sm" onClick={() => setAssignSoundId(sound.id)}>
                  {isAr ? 'تخصيص' : 'Assign'}
                </GlassButton>
              </div>
            </GlassCard>
          );
        })}
      </div>

      {/* Assign to Event Dialog */}
      {assignSoundId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#050C18]/80 p-4 backdrop-blur-md">
          <GlassCard className="w-full max-w-md space-y-4 p-6">
            <h3 className="text-lg font-extrabold">{isAr ? 'ربط الرنة بحدث البث' : 'Assign Sound to Stream Event'}</h3>
            <label className="block space-y-1 text-xs">
              <span className="font-bold">{isAr ? 'الحدث' : 'Event Trigger'}</span>
              <select
                value={assignTrigger}
                onChange={(e) => setAssignTrigger(e.target.value as SoundEventTrigger)}
                className="w-full rounded-xl border border-ice-crystal/25 bg-ice-midnight/80 px-3 py-2 text-ice-white"
              >
                {TRIGGERS.map((tr) => (
                  <option key={tr.id} value={tr.id}>{isAr ? tr.labelAr : tr.labelEn}</option>
                ))}
              </select>
            </label>
            {(assignTrigger === 'gift_named' || assignTrigger === 'chat_keyword') && (
              <input
                value={assignMatch}
                onChange={(e) => setAssignMatch(e.target.value)}
                placeholder={isAr ? 'اسم الهدية أو الكلمة المفتاحية...' : 'Gift name or keyword...'}
                className="w-full rounded-xl border border-ice-crystal/25 bg-ice-midnight/80 px-3 py-2 text-xs text-ice-white"
              />
            )}
            <label className="block space-y-1 text-xs">
              <span className="font-bold">{isAr ? 'المهلة بين التكرار (ثواني)' : 'Cooldown (seconds)'}</span>
              <input
                type="number"
                value={assignCooldown}
                onChange={(e) => setAssignCooldown(Math.max(0, Number(e.target.value) || 0))}
                className="w-full rounded-xl border border-ice-crystal/25 bg-ice-midnight/80 px-3 py-2 text-ice-white"
              />
            </label>
            <div className="flex justify-end gap-2">
              <GlassButton onClick={() => setAssignSoundId(null)}>{isAr ? 'إلغاء' : 'Cancel'}</GlassButton>
              <GlassButton variant="primary" onClick={handleSaveAssignment}>{isAr ? 'حفظ الربط' : 'Save Assignment'}</GlassButton>
            </div>
          </GlassCard>
        </div>
      )}
    </div>
  );
};
