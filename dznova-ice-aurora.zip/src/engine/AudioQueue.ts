export interface QueuedAudioItem {
  id: string;
  kind: 'tone' | 'tts';
  text?: string;
  lang?: string;
  frequency?: number;
  durationMs?: number;
}

/**
 * Sequential non-overlapping audio & TTS queue safe for OBS & TikTok LIVE Studio browser sources.
 */
export class AudioQueue {
  private queue: QueuedAudioItem[] = [];
  private playing = false;
  private muted = false;

  public setMuted(muted: boolean): void {
    this.muted = muted;
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public getPendingCount(): number {
    return this.queue.length;
  }

  public enqueue(item: QueuedAudioItem): void {
    if (this.muted) return;
    if (this.queue.length >= 25) {
      this.queue.shift();
    }
    this.queue.push(item);
    void this.drain();
  }

  public clear(): void {
    this.queue = [];
    this.playing = false;
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }

  private async drain(): Promise<void> {
    if (this.playing || this.queue.length === 0) return;
    this.playing = true;
    const item = this.queue.shift();
    if (!item) {
      this.playing = false;
      return;
    }

    try {
      if (item.kind === 'tone') {
        await this.playChime(item.frequency ?? 660, item.durationMs ?? 240);
      } else if (item.kind === 'tts' && item.text) {
        await this.speakText(item.text, item.lang ?? 'ar-SA');
      }
    } catch {
      // Audio autoplay restrictions in browser sources are handled gracefully without crashing.
    } finally {
      this.playing = false;
      if (this.queue.length > 0) {
        void this.drain();
      }
    }
  }

  private playChime(freq: number, durationMs: number): Promise<void> {
    return new Promise((resolve) => {
      if (typeof window === 'undefined') {
        resolve();
        return;
      }
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) {
        resolve();
        return;
      }
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.45, ctx.currentTime + durationMs / 1000);
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + durationMs / 1000);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + durationMs / 1000);
      setTimeout(() => {
        void ctx.close().catch(() => undefined);
        resolve();
      }, durationMs + 40);
    });
  }

  private speakText(text: string, lang: string): Promise<void> {
    return new Promise((resolve) => {
      if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
        resolve();
        return;
      }
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      utterance.rate = 1.02;
      utterance.onend = () => resolve();
      utterance.onerror = () => resolve();
      window.speechSynthesis.speak(utterance);
      setTimeout(resolve, 7500);
    });
  }
}

export const sharedAudioQueue = new AudioQueue();
