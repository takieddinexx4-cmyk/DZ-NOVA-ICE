import type { LiveEventPayload, StreamingPlatformId } from '../types/dznova';
import { dispatchLiveEvent } from './OverlayEngine';

const SAMPLE_USERS = [
  'Amine_DZ16',
  'Yasmine_Oran31',
  'Karim_Jijel18',
  'Sami_Constantine25',
  'Nour_Setif19',
  'Rayan_Bejaia06',
];

const SAMPLE_GIFTS = [
  { name: 'Aurora Rose', coins: 10 },
  { name: 'Crystal Crown', coins: 199 },
  { name: 'Sahara Lion', coins: 500 },
  { name: 'Nova Galaxy', coins: 1000 },
];

const SAMPLE_WILAYAS = ['16', '31', '18', '25', '19', '06', '09', '23'];

/**
 * Deterministic & interactive MockLiveSource capable of testing both
 * TikTok LIVE Studio and OBS Studio workflows end-to-end.
 */
export class MockLiveSource {
  private timer: ReturnType<typeof setInterval> | null = null;
  private listeners: Set<(ev: LiveEventPayload) => void> = new Set();

  public subscribe(listener: (ev: LiveEventPayload) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  public emit(event: LiveEventPayload): LiveEventPayload {
    this.listeners.forEach((fn) => fn(event));
    dispatchLiveEvent(event);
    return event;
  }

  public triggerTestGift(targetPlatform: StreamingPlatformId | 'all' = 'all'): LiveEventPayload {
    const user = SAMPLE_USERS[Math.floor(Math.random() * SAMPLE_USERS.length)];
    const gift = SAMPLE_GIFTS[Math.floor(Math.random() * SAMPLE_GIFTS.length)];
    const wilayaCode = SAMPLE_WILAYAS[Math.floor(Math.random() * SAMPLE_WILAYAS.length)];
    return this.emit({
      id: `evt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      type: 'gift',
      source: 'mock_live_source',
      targetPlatform,
      username: user,
      giftName: gift.name,
      coins: gift.coins,
      wilayaCode,
      message: `Sent ${gift.name} (${gift.coins} coins) for Wilaya ${wilayaCode}`,
      timestamp: Date.now(),
    });
  }

  public triggerTestFollow(targetPlatform: StreamingPlatformId | 'all' = 'all'): LiveEventPayload {
    const user = SAMPLE_USERS[Math.floor(Math.random() * SAMPLE_USERS.length)];
    return this.emit({
      id: `evt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      type: 'follow',
      source: 'mock_live_source',
      targetPlatform,
      username: user,
      message: `${user} followed the live stream`,
      timestamp: Date.now(),
    });
  }

  public triggerTestChat(
    message: string,
    targetPlatform: StreamingPlatformId | 'all' = 'all',
    username?: string,
  ): LiveEventPayload {
    const user = username || SAMPLE_USERS[Math.floor(Math.random() * SAMPLE_USERS.length)];
    return this.emit({
      id: `evt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      type: 'chat',
      source: 'mock_live_source',
      targetPlatform,
      username: user,
      message,
      timestamp: Date.now(),
    });
  }

  public startStreamSimulation(targetPlatform: StreamingPlatformId | 'all', intervalMs = 4500): void {
    this.stopStreamSimulation();
    this.timer = setInterval(() => {
      const roll = Math.random();
      if (roll < 0.45) {
        this.triggerTestGift(targetPlatform);
      } else if (roll < 0.75) {
        this.triggerTestChat('!wilaya تحية من الجزائر!', targetPlatform);
      } else {
        this.triggerTestFollow(targetPlatform);
      }
    }, intervalMs);
  }

  public stopStreamSimulation(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  public isRunning(): boolean {
    return this.timer !== null;
  }
}

export const mockLiveSource = new MockLiveSource();
