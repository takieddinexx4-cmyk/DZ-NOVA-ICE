export type Language = 'ar' | 'en' | 'fr';
export type ThemeMode = 'dark' | 'light';

export type StreamingPlatformId = 'tiktok_live_studio' | 'obs_studio';

export type CompatibilityProfileId =
  | 'obs_standard'
  | 'tiktok_standard'
  | 'lightweight'
  | 'high_quality';

export type OverlayType =
  | 'alerts'
  | 'goal'
  | 'wilaya'
  | 'chat'
  | 'wheel'
  | 'countdown'
  | 'leaderboard';

export type RouteId =
  | 'landing'
  | 'register'
  | 'login'
  | 'dashboard'
  | 'streaming-platforms'
  | 'overlays'
  | 'overlay-editor'
  | 'scene-editor'
  | 'alerts'
  | 'chat'
  | 'bot'
  | 'automation'
  | 'tts'
  | 'wilaya-battle'
  | 'analytics'
  | 'billing'
  | 'settings'
  | 'admin'
  | 'support'
  | 'icon-studio';

/**
 * Honest connection states — never conflate URL generation with live verification.
 */
export type PlatformConnectionStage =
  | 'not_configured'
  | 'url_generated'
  | 'overlay_opened'
  | 'browser_source_loaded'
  | 'events_received'
  | 'integration_verified';

export interface PlatformStatusRecord {
  platform: StreamingPlatformId;
  stage: PlatformConnectionStage;
  urlGeneratedAt: number | null;
  overlayOpenedAt: number | null;
  browserSourceLoadedAt: number | null;
  lastHeartbeatAt: number | null;
  eventSourceActive: boolean;
  lastEventAt: number | null;
  lastEventSummary: string | null;
  lastCheckAt: number | null;
  errors: string[];
  activeProfile: CompatibilityProfileId;
  resolution: { width: number; height: number };
}

export interface OverlayTokenRecord {
  id: string;
  token: string;
  overlayType: OverlayType;
  platform: StreamingPlatformId;
  profile: CompatibilityProfileId;
  width: number;
  height: number;
  createdAt: number;
  revoked: boolean;
  revokedAt?: number;
}

export interface SetupWizardState {
  target: 'tiktok_live_studio' | 'obs_studio' | 'both';
  step: number;
  selectedOverlays: OverlayType[];
  resolution: { width: number; height: number; label: string };
  profile: CompatibilityProfileId;
  generatedTokens: Record<string, string>;
  testEventSent: boolean;
  completed: boolean;
  updatedAt: number;
}

export interface LiveEventPayload {
  id: string;
  type: 'gift' | 'follow' | 'chat' | 'share' | 'like' | 'system' | 'wilaya_boost';
  source: 'mock_live_source' | 'tiktok_live_bridge' | 'obs_websocket' | 'manual';
  targetPlatform: StreamingPlatformId | 'all';
  username: string;
  message?: string;
  giftName?: string;
  coins?: number;
  wilayaCode?: string;
  timestamp: number;
}

export interface AlertConfig {
  enabled: boolean;
  minCoins: number;
  durationMs: number;
  soundEnabled: boolean;
  ttsEnabled: boolean;
  accentColor: string;
}

export interface BotCommand {
  id: string;
  trigger: string;
  response: string;
  enabled: boolean;
  cooldownSec: number;
}

export interface AutomationRule {
  id: string;
  name: string;
  triggerType: 'gift' | 'follow' | 'chat_keyword' | 'wilaya_lead';
  conditionValue: string;
  actionType: 'tts' | 'sound' | 'goal_increment' | 'chat_reply';
  actionPayload: string;
  enabled: boolean;
  executions: number;
}

export interface SceneLayer {
  id: string;
  overlayType: OverlayType;
  label: string;
  x: number;
  y: number;
  scale: number;
  visible: boolean;
  zIndex: number;
}

export interface WilayaScore {
  code: string;
  nameAr: string;
  nameEn: string;
  points: number;
}

export interface ObsWebSocketConfig {
  enabled: boolean;
  host: string;
  port: number;
  hasPassword: boolean;
  status: 'disabled' | 'disconnected' | 'connecting' | 'connected' | 'error';
  lastError: string | null;
  lastCheckedAt: number | null;
}

export interface OverlayCustomization {
  accentColor: string;
  scale: number;
  opacity: number;
  fontScale: number;
  profile: CompatibilityProfileId;
  showBadges: boolean;
}
