import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'live.dznova.iceaurora',
  appName: 'DZNOVA',
  webDir: 'dist',
  android: {
    backgroundColor: '#091526',
    allowMixedContent: true,
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1200,
      backgroundColor: '#091526',
      showSpinner: false,
    },
  },
};

export default config;
