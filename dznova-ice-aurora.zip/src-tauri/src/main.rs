#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    dznova_desktop_companion_lib::run()
}
