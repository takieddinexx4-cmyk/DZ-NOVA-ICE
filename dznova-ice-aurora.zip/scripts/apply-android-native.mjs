import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const androidDir = path.join(root, 'android');
if (!fs.existsSync(androidDir)) {
  console.log('android/ directory not found yet — run `npx cap add android` first.');
  process.exit(0);
}

// 1. Copy MainActivity.java with native Android TextToSpeech bridge
const destMain = path.join(androidDir, 'app/src/main/java/live/dznova/iceaurora/MainActivity.java');
fs.mkdirSync(path.dirname(destMain), { recursive: true });
fs.copyFileSync(path.join(root, 'android-native/MainActivity.java'), destMain);

// 2. Ensure minSdkVersion >= 24 in variables.gradle
const varsFile = path.join(androidDir, 'variables.gradle');
if (fs.existsSync(varsFile)) {
  let vars = fs.readFileSync(varsFile, 'utf8');
  vars = vars.replace(/minSdkVersion\s*=\s*\d+/, 'minSdkVersion = 24');
  fs.writeFileSync(varsFile, vars, 'utf8');
}

// 3. Ensure WAKE_LOCK, FOREGROUND_SERVICE, and POST_NOTIFICATIONS permissions in AndroidManifest.xml
const manifestFile = path.join(androidDir, 'app/src/main/AndroidManifest.xml');
if (fs.existsSync(manifestFile)) {
  let xml = fs.readFileSync(manifestFile, 'utf8');
  const perms = [
    '<uses-permission android:name="android.permission.WAKE_LOCK" />',
    '<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />',
    '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
  ];
  for (const p of perms) {
    if (!xml.includes(p)) {
      xml = xml.replace('<uses-permission android:name="android.permission.INTERNET" />', `<uses-permission android:name="android.permission.INTERNET" />\n    ${p}`);
    }
  }
  fs.writeFileSync(manifestFile, xml, 'utf8');
}

// 4. Copy DZNOVA Ice Aurora icon into mipmap folders
const srcIcon = path.join(root, 'public/brand/dznova-icon-512.png');
if (fs.existsSync(srcIcon)) {
  for (const density of ['mipmap-mdpi', 'mipmap-hdpi', 'mipmap-xhdpi', 'mipmap-xxhdpi', 'mipmap-xxxhdpi']) {
    const dir = path.join(androidDir, 'app/src/main/res', density);
    if (fs.existsSync(dir)) {
      fs.copyFileSync(srcIcon, path.join(dir, 'ic_launcher.png'));
      fs.copyFileSync(srcIcon, path.join(dir, 'ic_launcher_round.png'));
      fs.copyFileSync(srcIcon, path.join(dir, 'ic_launcher_foreground.png'));
    }
  }
}

console.log('Applied DZNOVA Android native TTS bridge, minSdk 24, permissions, and Ice Aurora icons.');
