import { describe, expect, it } from 'vitest';
import { chunkTtsText, humanizeUsername, normalizeArabicText, numberToArabicWords } from '../engine/tts/arabicText';
import { rankArabicVoices } from '../engine/tts/WebSpeechProvider';
import { BUILT_IN_SOUNDS, DEFAULT_SOUND_RULES, resolveSoundRuleForEvent } from '../engine/audio/SoundLibrary';
import { AudioQueue } from '../engine/AudioQueue';

describe('DZNOVA v3.1.0 Arabic TTS & Audio Engine', () => {
  it('normalizes Arabic text: strips emojis/URLs, collapses elongations, converts digits, splits usernames, applies dictionary', () => {
    const input = 'مبروووووك هههههه Amine_DZ16 🎉 https://example.com ارسل ١٩٩ عملة لـ DZ';
    const out = normalizeArabicText(input);
    expect(out).not.toContain('https://');
    expect(out).not.toContain('🎉');
    expect(out).not.toContain('هههههه');
    expect(out).toContain('الجزائر');
    expect(out).toContain('مائة وتسعة وتسعون');
    expect(humanizeUsername('Amine_DZ16')).toBe('Amine DZ 16');
    expect(numberToArabicWords(16)).toBe('ستة عشر');
  });

  it('chunks long Arabic text into <= 180 character chunks on sentence boundaries', () => {
    const sentence = 'مرحباً بكم جميعاً في بث دي زاد نوفا المباشر لتحدي الولايات الجزائري. ';
    const longText = sentence.repeat(6);
    const chunks = chunkTtsText(longText, 180);
    expect(chunks.length).toBeGreaterThanOrEqual(3);
    chunks.forEach((c) => expect(c.length).toBeLessThanOrEqual(180));
  });

  it('ranks Arabic voices: ar-DZ > ar-MA/ar-TN > ar-SA/ar-EG > ar-*, preferring Natural/Neural voices', () => {
    const sample = [
      { name: 'Arabic Generic', lang: 'ar', isNatural: false },
      { name: 'Microsoft Hamed', lang: 'ar-SA', isNatural: false },
      { name: 'Microsoft Amina Online (Natural)', lang: 'ar-DZ', isNatural: true },
      { name: 'Google Arabic Morocco', lang: 'ar-MA', isNatural: false },
      { name: 'English US', lang: 'en-US', isNatural: true },
    ];
    const ranked = rankArabicVoices(sample);
    expect(ranked.map((v) => v.lang)).toEqual(['ar-DZ', 'ar-MA', 'ar-SA', 'ar']);
  });

  it('provides at least 40 built-in sounds and resolves event rules by named gift > coin tier > event type', () => {
    expect(BUILT_IN_SOUNDS.length).toBeGreaterThanOrEqual(40);

    const rules = [
      ...DEFAULT_SOUND_RULES,
      {
        id: 'named_lion',
        trigger: 'gift_named' as const,
        matchValue: 'Sahara Lion',
        soundIds: ['ring_hijaz_aurora'],
        volume: 1,
        trimStartSec: 0,
        trimEndSec: 0,
        fadeInSec: 0,
        fadeOutSec: 0,
        cooldownSec: 1,
        enabled: true,
      },
    ];

    expect(resolveSoundRuleForEvent(rules, { type: 'gift', giftName: 'Sahara Lion', coins: 500 })?.id).toBe('named_lion');
    expect(resolveSoundRuleForEvent(rules, { type: 'gift', giftName: 'Galaxy', coins: 1200 })?.trigger).toBe('gift_legendary');
    expect(resolveSoundRuleForEvent(rules, { type: 'gift', giftName: 'Rose', coins: 10 })?.trigger).toBe('gift_small');
    expect(resolveSoundRuleForEvent(rules, { type: 'follow' })?.trigger).toBe('follow');
  });

  it('orders AudioQueue by priority (big gift > small gift > chat) and merges rapid identical events', () => {
    const q = new AudioQueue();
    q.enqueue({ id: '1', kind: 'tts', priority: 1, text: 'Chat msg' }, false);
    q.enqueue({ id: '2', kind: 'sound+tts', priority: 3, mergeKey: 'gift:Amine:Rose', text: 'Rose' }, false);
    q.enqueue({ id: '3', kind: 'sound+tts', priority: 3, mergeKey: 'gift:Amine:Rose', text: 'Rose' }, false);
    q.enqueue({ id: '4', kind: 'sound+tts', priority: 4, text: 'Legendary Lion' }, false);

    const items = q.getQueueItems();
    expect(items.length).toBe(3); // Two identical Rose gifts merged into 1
    expect(items[0].priority).toBe(4);
    expect(items[1].text).toContain('x2');
    expect(items[2].priority).toBe(1);
  });
});
