import React, { useState } from 'react';
import { useDznova } from '../context/DznovaContext';
import { GlassBadge, GlassButton, GlassCard } from '../components/GlassUI';
import { DznovaLogo } from '../components/DznovaLogo';
import { COMPATIBILITY_PROFILES, buildOverlayUrl } from '../engine/OverlayEngine';
import type { CompatibilityProfileId, OverlayType, StreamingPlatformId } from '../types/dznova';
import {
  DashboardIcon,
  DesktopCompanionIcon,
  GiftsIcon,
  LiveStreamIcon,
  ObsStudioIcon,
  OverlayLibraryIcon,
  SceneEditorIcon,
  StreamingPlatformsIcon,
  TikTokLiveStudioIcon,
  WilayaBattleIcon,
} from '../components/icons';
import { t } from '../i18n/translations';

export const LandingPage: React.FC = () => {
  const { lang, navigate, setShowIntroModal, theme } = useDznova();
  const isAr = lang === 'ar';

  return (
    <div className="space-y-8 py-4">
      <GlassCard className="relative overflow-hidden p-8 md:p-12">
        <div className="max-w-3xl space-y-5">
          <GlassBadge tone="cyan">DZNOVA — ICE AURORA EDITION v3.0</GlassBadge>
          <DznovaLogo variant="wordmark" theme={theme} size={56} animated />
          <h1 className="text-3xl font-extrabold leading-tight md:text-5xl">
            {isAr
              ? 'منصتان للبث المباشر. منظومة كريستالية ذكية واحدة.'
              : 'Two Streaming Platforms. One Intelligent Ice Aurora Ecosystem.'}
          </h1>
          <p className="text-base opacity-85 md:text-lg">
            {isAr
              ? 'تحكّم في الأوفرلاي الشفافة، تنبيهات الهدايا، تحدي الولايات الجزائري، النطق الصوتي TTS، والأتمتة في TikTok LIVE Studio و OBS Studio مع تطبيق سطح مكتب Tauri لنظام ويندوز.'
              : 'Manage transparent overlays, alerts, Algerian Wilaya Battle, Arabic/EN/FR TTS, and automation across TikTok LIVE Studio and OBS Studio — plus a Tauri Windows Desktop Companion.'}
          </p>
          <div className="flex flex-wrap gap-3 pt-2">
            <GlassButton size="lg" variant="primary" onClick={() => navigate('streaming-platforms')}>
              <StreamingPlatformsIcon size={22} />
              {isAr ? 'إعداد TikTok LIVE Studio و OBS' : 'Configure TikTok LIVE Studio & OBS'}
            </GlassButton>
            <GlassButton size="lg" onClick={() => navigate('dashboard')}>
              <DashboardIcon size={22} />
              {isAr ? 'فتح لوحة التحكم' : 'Open Control Center'}
            </GlassButton>
            <GlassButton size="lg" variant="ghost" onClick={() => setShowIntroModal(true)}>
              {isAr ? 'عرض مقدمة الشعار المتحركة' : 'Play Animated Logo Intro'}
            </GlassButton>
          </div>
        </div>
      </GlassCard>

      <div className="grid gap-5 md:grid-cols-3">
        <GlassCard interactive className="space-y-3">
          <div className="ice-title-plate">
            <TikTokLiveStudioIcon size={36} />
            <h3 className="text-base font-extrabold">TikTok LIVE Studio</h3>
          </div>
          <p className="text-sm opacity-80">
            {isAr
              ? 'معالج إعداد مخصص، ملفات توافق شفافة، وأدوات تحقق صادقة بدون وعود غير مدعومة.'
              : 'Dedicated setup wizard, transparent compatibility profiles, and honest verification states.'}
          </p>
        </GlassCard>
        <GlassCard interactive className="space-y-3">
          <div className="ice-title-plate">
            <ObsStudioIcon size={36} />
            <h3 className="text-base font-extrabold">OBS Studio + WebSocket</h3>
          </div>
          <p className="text-sm opacity-80">
            {isAr
              ? 'روابط Browser Source قابلة للإلغاء بدقة 1080p/60fps مع دعم OBS WebSocket v5 اختياري وآمن.'
              : 'Revocable 1080p/60fps Browser Sources with optional, securely configured OBS WebSocket v5.'}
          </p>
        </GlassCard>
        <GlassCard interactive className="space-y-3">
          <div className="ice-title-plate">
            <DesktopCompanionIcon size={36} />
            <h3 className="text-base font-extrabold">{isAr ? 'تطبيق سطح المكتب (Tauri)' : 'Windows Desktop Companion'}</h3>
          </div>
          <p className="text-sm opacity-80">
            {isAr
              ? 'تطبيق ويندوز خفيف لتخزين الرموز بأمان، إشعارات سطح المكتب، والتشخيص المحلي.'
              : 'Lightweight Tauri Windows companion for secure token handling, local caching, and diagnostics.'}
          </p>
        </GlassCard>
      </div>
    </div>
  );
};

export const AuthPage: React.FC<{ mode: 'login' | 'register' }> = ({ mode }) => {
  const { lang, login, navigate, theme } = useDznova();
  const isAr = lang === 'ar';
  const [email, setEmail] = useState('creator@dznova.live');
  const [username, setUsername] = useState('DZ_Creator');
  const [tiktok, setTiktok] = useState('@dznova_live');
  const [password, setPassword] = useState('••••••••••');

  return (
    <div className="mx-auto max-w-md py-8">
      <GlassCard className="space-y-5 p-7">
        <div className="flex flex-col items-center gap-2 text-center">
          <DznovaLogo variant="symbol" theme={theme} size={56} animated />
          <h1 className="text-2xl font-extrabold">
            {mode === 'login'
              ? isAr ? 'تسجيل الدخول إلى DZNOVA' : 'Sign In to DZNOVA'
              : isAr ? 'إنشاء حساب DZNOVA جديد' : 'Create Your DZNOVA Account'}
          </h1>
        </div>
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            login(email, username, tiktok);
          }}
        >
          {mode === 'register' && (
            <>
              <input
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder={isAr ? 'اسم المستخدم' : 'Username'}
                className="w-full rounded-xl border border-ice-crystal/25 bg-ice-midnight/60 px-4 py-2.5 text-sm text-ice-white"
                required
              />
              <input
                value={tiktok}
                onChange={(e) => setTiktok(e.target.value)}
                placeholder="@tiktok_username"
                className="w-full rounded-xl border border-ice-crystal/25 bg-ice-midnight/60 px-4 py-2.5 text-sm text-ice-white"
              />
            </>
          )}
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
            className="w-full rounded-xl border border-ice-crystal/25 bg-ice-midnight/60 px-4 py-2.5 text-sm text-ice-white"
            required
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            className="w-full rounded-xl border border-ice-crystal/25 bg-ice-midnight/60 px-4 py-2.5 text-sm text-ice-white"
            required
          />
          <GlassButton type="submit" variant="primary" className="w-full py-3">
            {mode === 'login' ? (isAr ? 'دخول' : 'Sign In') : isAr ? 'إنشاء الحساب' : 'Create Account'}
          </GlassButton>
        </form>
        <div className="text-center text-xs opacity-80">
          {mode === 'login' ? (
            <button type="button" className="underline" onClick={() => navigate('register')}>
              {isAr ? 'ليس لديك حساب؟ أنشئ حساباً جديداً' : 'Need an account? Register'}
            </button>
          ) : (
            <button type="button" className="underline" onClick={() => navigate('login')}>
              {isAr ? 'لديك حساب بالفعل؟ سجّل الدخول' : 'Already have an account? Sign In'}
            </button>
          )}
        </div>
      </GlassCard>
    </div>
  );
};

export const DashboardPage: React.FC = () => {
  const {
    lang,
    session,
    platforms,
    events,
    wilayas,
    simRunning,
    toggleSimulation,
    triggerMockGift,
    triggerMockFollow,
    navigate,
  } = useDznova();
  const isAr = lang === 'ar';

  return (
    <div className="space-y-6">
      <GlassCard className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <DashboardIcon size={44} />
          <div>
            <h1 className="text-2xl font-extrabold">
              {isAr ? `مرحباً، ${session.username}` : `Welcome back, ${session.username}`}
            </h1>
            <p className="text-xs opacity-75">
              {session.tiktokHandle} • {session.plan} • {isAr ? 'محرك MockLiveSource جاهز لاختبار المنصتين' : 'MockLiveSource ready for dual-platform testing'}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <GlassButton variant="primary" onClick={() => triggerMockGift('all')}>
            <GiftsIcon size={18} />
            {isAr ? 'محاكاة هدية' : 'Simulate Gift'}
          </GlassButton>
          <GlassButton onClick={() => triggerMockFollow('all')}>
            {isAr ? 'محاكاة متابعة' : 'Simulate Follow'}
          </GlassButton>
          <GlassButton variant={simRunning ? 'danger' : 'secondary'} onClick={() => toggleSimulation('all')}>
            <LiveStreamIcon size={18} />
            {simRunning ? (isAr ? 'إيقاف البث التجريبي' : 'Stop Live Sim') : isAr ? 'تشغيل بث تجريبي' : 'Start Live Sim'}
          </GlassButton>
        </div>
      </GlassCard>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <GlassCard interactive>
          <p className="text-xs opacity-70">TikTok LIVE Studio</p>
          <p className="mt-1 text-base font-extrabold text-ice-glacier">{platforms.tiktok_live_studio.stage}</p>
          <button type="button" onClick={() => navigate('streaming-platforms')} className="mt-2 text-xs text-ice-crystal underline">
            {isAr ? 'فتح معالج الإعداد ←' : 'Open Setup →'}
          </button>
        </GlassCard>
        <GlassCard interactive>
          <p className="text-xs opacity-70">OBS Studio</p>
          <p className="mt-1 text-base font-extrabold text-ice-nebula">{platforms.obs_studio.stage}</p>
          <button type="button" onClick={() => navigate('streaming-platforms')} className="mt-2 text-xs text-ice-crystal underline">
            {isAr ? 'فتح معالج الإعداد ←' : 'Open Setup →'}
          </button>
        </GlassCard>
        <GlassCard interactive>
          <p className="text-xs opacity-70">{isAr ? 'الأحداث المسجلة' : 'Session Events'}</p>
          <p className="mt-1 font-mono text-2xl font-extrabold">{events.length}</p>
        </GlassCard>
        <GlassCard interactive>
          <p className="text-xs opacity-70">{isAr ? 'الولاية المتصدرة' : 'Leading Wilaya'}</p>
          <p className="mt-1 text-lg font-extrabold text-emerald-300">
            {wilayas[0]?.nameAr} ({wilayas[0]?.points})
          </p>
        </GlassCard>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <GlassCard className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold">{isAr ? 'الخط الزمني للأحداث المباشرة' : 'Recent Live Event Timeline'}</h2>
            <GlassBadge tone="cyan">{events.length}</GlassBadge>
          </div>
          {events.length === 0 ? (
            <p className="py-6 text-center text-sm opacity-70">
              {isAr ? 'اضغط "محاكاة هدية" أو شغّل البث التجريبي لاختبار تدفق الأحداث.' : 'Click Simulate Gift or Start Live Sim to test real-time event flow.'}
            </p>
          ) : (
            <div className="max-h-72 space-y-2 overflow-y-auto">
              {events.slice(0, 12).map((ev) => (
                <div key={ev.id} className="flex items-center justify-between rounded-xl bg-ice-midnight/45 px-3.5 py-2.5 text-xs">
                  <div>
                    <span className="font-bold text-ice-glacier">{ev.username}</span>{' '}
                    <span className="opacity-85">{ev.message ?? ev.giftName ?? ev.type}</span>
                  </div>
                  <GlassBadge tone="violet">{ev.targetPlatform}</GlassBadge>
                </div>
              ))}
            </div>
          )}
        </GlassCard>

        <GlassCard className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <WilayaBattleIcon size={24} />
              <h2 className="text-lg font-bold">{isAr ? 'صدارة تحدي الولايات' : 'Wilaya Battle Top 5'}</h2>
            </div>
            <GlassButton size="sm" onClick={() => navigate('wilaya-battle')}>
              {isAr ? 'إدارة المعركة' : 'Manage Battle'}
            </GlassButton>
          </div>
          <div className="space-y-2">
            {wilayas.slice(0, 5).map((w, idx) => (
              <div key={w.code} className="flex items-center justify-between rounded-xl bg-ice-midnight/45 px-4 py-2.5 text-sm">
                <span className="font-bold">#{idx + 1} • {w.code} — {isAr ? w.nameAr : w.nameEn}</span>
                <span className="font-mono font-extrabold text-ice-glacier">{w.points} pts</span>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
};

export const OverlayLibraryPage: React.FC = () => {
  const { lang, tokens, generateToken, revokeToken, markOverlayOpened, pushToast } = useDznova();
  const isAr = lang === 'ar';
  const [targetPlatform, setTargetPlatform] = useState<StreamingPlatformId>('tiktok_live_studio');
  const [profile, setProfile] = useState<CompatibilityProfileId>('tiktok_standard');
  const baseUrl = typeof window !== 'undefined' ? window.location.href : '';

  const items: { type: OverlayType; titleAr: string; titleEn: string; descAr: string; descEn: string }[] = [
    { type: 'alerts', titleAr: 'تنبيهات الكريستال', titleEn: 'Crystal Alerts', descAr: 'هدايا ومتابعات بشفافية كاملة وطابور صوتي.', descEn: 'Transparent gift & follow alerts with AudioQueue.' },
    { type: 'wilaya', titleAr: 'تحدي الولايات', titleEn: 'Wilaya Battle HUD', descAr: 'ترتيب لحظي للولايات الجزائرية الـ 58.', descEn: 'Real-time scoreboard for Algerian wilayas.' },
    { type: 'chat', titleAr: 'صندوق الدردشة', titleEn: 'Aurora Live Chat', descAr: 'عرض الرسائل الواردة بخط عربي واضح.', descEn: 'Crisp RTL/LTR transparent live chat overlay.' },
    { type: 'goal', titleAr: 'شريط الأهداف', titleEn: 'Stream Goal Bar', descAr: 'تقدم حي لأهداف العملات والهدايا.', descEn: 'Animated coin & follower progress bar.' },
    { type: 'wheel', titleAr: 'عجلة الحظ', titleEn: 'Spin Wheel', descAr: 'دوران تلقائي عند وصول الهدايا.', descEn: 'Auto-spinning interactive reward wheel.' },
    { type: 'countdown', titleAr: 'عدّاد تنازلي', titleEn: 'Countdown Timer', descAr: 'مؤقت بدء البث أو الجولات.', descEn: 'Crystal countdown timer for streams.' },
    { type: 'leaderboard', titleAr: 'لوحة المتصدرين', titleEn: 'Supporters Board', descAr: 'أقوى الداعمين خلال الجلسة.', descEn: 'Top session gifters leaderboard.' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <OverlayLibraryIcon size={40} />
          <div>
            <h1 className="text-2xl font-extrabold">{t(lang, 'navOverlays')}</h1>
            <p className="text-xs opacity-75">
              {isAr ? 'محرك عرض موحد شفاف 1920×1080 بدون WebGL لـ TikTok LIVE Studio و OBS.' : 'Unified zero-WebGL 1920×1080 transparent engine for TikTok LIVE Studio & OBS.'}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <select
            value={targetPlatform}
            onChange={(e) => {
              const p = e.target.value as StreamingPlatformId;
              setTargetPlatform(p);
              setProfile(p === 'obs_studio' ? 'obs_standard' : 'tiktok_standard');
            }}
            className="rounded-xl border border-ice-crystal/25 bg-ice-midnight/75 px-3 py-2 text-xs text-ice-white"
          >
            <option value="tiktok_live_studio">TikTok LIVE Studio</option>
            <option value="obs_studio">OBS Studio</option>
          </select>
          <select
            value={profile}
            onChange={(e) => setProfile(e.target.value as CompatibilityProfileId)}
            className="rounded-xl border border-ice-crystal/25 bg-ice-midnight/75 px-3 py-2 text-xs text-ice-white"
          >
            {Object.values(COMPATIBILITY_PROFILES).map((p) => (
              <option key={p.id} value={p.id}>{isAr ? p.nameAr : p.nameEn}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {items.map((item) => {
          const active = tokens.find((tok) => !tok.revoked && tok.overlayType === item.type && tok.platform === targetPlatform);
          const url = active ? buildOverlayUrl(baseUrl, active) : '';
          return (
            <GlassCard key={item.type} interactive className="flex flex-col justify-between gap-4">
              <div>
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-extrabold">{isAr ? item.titleAr : item.titleEn}</h3>
                  <GlassBadge tone="cyan">{item.type}</GlassBadge>
                </div>
                <p className="mt-1 text-xs opacity-80">{isAr ? item.descAr : item.descEn}</p>
              </div>
              <div className="space-y-2">
                {url && (
                  <input readOnly value={url} className="w-full rounded-lg border border-ice-crystal/20 bg-ice-midnight/60 px-2 py-1.5 font-mono text-[10px] text-ice-glacier" />
                )}
                <div className="flex flex-wrap gap-2">
                  <GlassButton
                    size="sm"
                    variant="primary"
                    onClick={() => {
                      generateToken({ overlayType: item.type, platform: targetPlatform, profile, width: 1920, height: 1080 });
                      pushToast(isAr ? 'تم توليد الرابط الآمن' : 'Secure URL created', item.type, 'cyan');
                    }}
                  >
                    {active ? (isAr ? 'تدوير الرمز' : 'Rotate Token') : isAr ? 'توليد رابط' : 'Generate URL'}
                  </GlassButton>
                  {url && (
                    <>
                      <GlassButton
                        size="sm"
                        onClick={() => {
                          void navigator.clipboard.writeText(url);
                          pushToast(t(lang, 'copied'), undefined, 'emerald');
                        }}
                      >
                        {t(lang, 'copyUrl')}
                      </GlassButton>
                      <GlassButton
                        size="sm"
                        onClick={() => {
                          markOverlayOpened(targetPlatform);
                          window.open(url, '_blank', 'noopener,noreferrer');
                        }}
                      >
                        {t(lang, 'openPreview')}
                      </GlassButton>
                      <GlassButton size="sm" variant="danger" onClick={() => active && revokeToken(active.token)}>
                        {isAr ? 'إلغاء' : 'Revoke'}
                      </GlassButton>
                    </>
                  )}
                </div>
              </div>
            </GlassCard>
          );
        })}
      </div>
    </div>
  );
};

export const OverlayEditorPage: React.FC = () => {
  const { lang, overlayCustom, setOverlayCustom, pushToast } = useDznova();
  const isAr = lang === 'ar';

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <GlassCard className="space-y-4">
        <h1 className="text-2xl font-extrabold">{t(lang, 'navOverlayEditor')}</h1>
        <label className="block text-xs">
          <span className="font-bold">{isAr ? 'اللون الكريستالي المميز' : 'Crystal Accent Color'}</span>
          <input
            type="color"
            value={overlayCustom.accentColor}
            onChange={(e) => setOverlayCustom((p) => ({ ...p, accentColor: e.target.value }))}
            className="mt-1 block h-10 w-24 cursor-pointer rounded-lg border border-ice-crystal/30 bg-transparent"
          />
        </label>
        <label className="block text-xs">
          <span className="font-bold">{isAr ? `الحجم (${Math.round(overlayCustom.scale * 100)}%)` : `Scale (${Math.round(overlayCustom.scale * 100)}%)`}</span>
          <input
            type="range"
            min="0.6"
            max="1.4"
            step="0.05"
            value={overlayCustom.scale}
            onChange={(e) => setOverlayCustom((p) => ({ ...p, scale: Number(e.target.value) }))}
            className="mt-1 w-full"
          />
        </label>
        <label className="block text-xs">
          <span className="font-bold">{isAr ? `الشفافية (${Math.round(overlayCustom.opacity * 100)}%)` : `Opacity (${Math.round(overlayCustom.opacity * 100)}%)`}</span>
          <input
            type="range"
            min="0.4"
            max="1"
            step="0.05"
            value={overlayCustom.opacity}
            onChange={(e) => setOverlayCustom((p) => ({ ...p, opacity: Number(e.target.value) }))}
            className="mt-1 w-full"
          />
        </label>
        <GlassButton
          variant="primary"
          onClick={() => pushToast(isAr ? 'تم حفظ تخصيص الأوفرلاي' : 'Overlay styling saved', undefined, 'emerald')}
        >
          {isAr ? 'حفظ التخصيص' : 'Save Customization'}
        </GlassButton>
      </GlassCard>

      <GlassCard className="flex min-h-[280px] items-center justify-center bg-[#091526]/40">
        <div
          style={{
            transform: `scale(${overlayCustom.scale})`,
            opacity: overlayCustom.opacity,
            borderColor: overlayCustom.accentColor,
          }}
          className="rounded-2xl border-2 bg-[#091526]/85 px-8 py-6 text-center shadow-ice-glow"
        >
          <p className="text-xs font-bold uppercase tracking-[0.22em]" style={{ color: overlayCustom.accentColor }}>
            LIVE PREVIEW
          </p>
          <p className="mt-1 text-2xl font-extrabold text-[#F3FAFF]">Amine_DZ16</p>
          <p className="text-sm text-[#A9E5FF]">Crystal Crown • 199 Coins</p>
        </div>
      </GlassCard>
    </div>
  );
};

export const SceneEditorPage: React.FC = () => {
  const { lang, sceneLayers, setSceneLayers, pushToast } = useDznova();
  const isAr = lang === 'ar';

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <SceneEditorIcon size={38} />
        <div>
          <h1 className="text-2xl font-extrabold">{t(lang, 'navSceneEditor')}</h1>
          <p className="text-xs opacity-75">
            {isAr ? 'ترتيب طبقات المشهد الافتراضي 1920×1080 لـ TikTok LIVE Studio و OBS.' : 'Compose 1920×1080 virtual canvas layers for TikTok LIVE Studio & OBS.'}
          </p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <GlassCard className="space-y-3">
          <h2 className="text-sm font-bold">{isAr ? 'طبقات المشهد' : 'Scene Layers'}</h2>
          {sceneLayers.map((layer) => (
            <div key={layer.id} className="flex items-center justify-between rounded-xl bg-ice-midnight/45 px-3 py-2.5 text-xs">
              <div>
                <p className="font-bold">{layer.label}</p>
                <p className="opacity-65">X:{layer.x} Y:{layer.y} • Z:{layer.zIndex}</p>
              </div>
              <GlassButton
                size="sm"
                variant={layer.visible ? 'primary' : 'secondary'}
                onClick={() =>
                  setSceneLayers((prev) =>
                    prev.map((l) => (l.id === layer.id ? { ...l, visible: !l.visible } : l)),
                  )
                }
              >
                {layer.visible ? (isAr ? 'مرئي' : 'Visible') : isAr ? 'مخفي' : 'Hidden'}
              </GlassButton>
            </div>
          ))}
          <GlassButton
            variant="primary"
            className="w-full"
            onClick={() => pushToast(isAr ? 'تم حفظ تخطيط المشهد' : 'Scene layout saved', undefined, 'emerald')}
          >
            {isAr ? 'حفظ المشهد' : 'Save Scene'}
          </GlassButton>
        </GlassCard>

        <GlassCard className="lg:col-span-2">
          <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-ice-crystal/30 bg-[#091526]/80">
            {sceneLayers
              .filter((l) => l.visible)
              .map((l) => (
                <div
                  key={l.id}
                  style={{
                    left: `${(l.x / 1920) * 100}%`,
                    top: `${(l.y / 1080) * 100}%`,
                    zIndex: l.zIndex,
                  }}
                  className="absolute rounded-lg border border-ice-glacier/60 bg-ice-glacier/20 px-3 py-1.5 text-[11px] font-bold text-ice-white"
                >
                  {l.label}
                </div>
              ))}
            <span className="absolute bottom-2 right-3 font-mono text-[10px] opacity-60">1920 × 1080 Canvas</span>
          </div>
        </GlassCard>
      </div>
    </div>
  );
};
