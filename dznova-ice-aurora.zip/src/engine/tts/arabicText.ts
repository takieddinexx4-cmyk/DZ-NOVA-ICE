export interface PronunciationEntry {
  from: string;
  to: string;
}

export const DEFAULT_PRONUNCIATION_DICT: PronunciationEntry[] = [
  { from: 'DZ', to: 'الجزائر' },
  { from: 'DZNOVA', to: 'دي زاد نوفا' },
  { from: 'OBS', to: 'أو بي إس' },
  { from: 'Algiers', to: 'الجزائر العاصمة' },
  { from: 'Oran', to: 'وهران' },
  { from: 'Jijel', to: 'جيجل' },
  { from: 'Constantine', to: 'قسنطينة' },
  { from: 'Setif', to: 'سطيف' },
  { from: 'Bejaia', to: 'بجاية' },
  { from: 'Annaba', to: 'عنابة' },
  { from: 'Blida', to: 'البليدة' },
  { from: 'Biskra', to: 'بسكرة' },
  { from: 'Aurora Rose', to: 'وردة أورورا' },
  { from: 'Crystal Crown', to: 'تاج الكريستال' },
  { from: 'Sahara Lion', to: 'أسد الصحراء' },
  { from: 'Nova Galaxy', to: 'مجرة نوفا' },
];

const ARABIC_INDIC_MAP: Record<string, string> = {
  '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
  '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9',
  '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
  '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9',
};

const ONES = [
  '', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة',
  'عشرة', 'أحد عشر', 'اثنا عشر', 'ثلاثة عشر', 'أربعة عشر', 'خمسة عشر',
  'ستة عشر', 'سبعة عشر', 'ثمانية عشر', 'تسعة عشر',
];

const TENS = [
  '', '', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون',
];

const HUNDREDS = [
  '', 'مائة', 'مائتان', 'ثلاثمائة', 'أربعمائة', 'خمسمائة', 'ستمائة', 'سبعمائة', 'ثمانمائة', 'تسعمائة',
];

export function numberToArabicWords(n: number): string {
  if (!Number.isFinite(n) || n < 0) return String(n);
  const num = Math.floor(n);
  if (num === 0) return 'صفر';
  if (num < 20) return ONES[num];
  if (num < 100) {
    const t = Math.floor(num / 10);
    const o = num % 10;
    return o === 0 ? TENS[t] : `${ONES[o]} و${TENS[t]}`;
  }
  if (num < 1000) {
    const h = Math.floor(num / 100);
    const rem = num % 100;
    return rem === 0 ? HUNDREDS[h] : `${HUNDREDS[h]} و${numberToArabicWords(rem)}`;
  }
  if (num < 1000000) {
    const th = Math.floor(num / 1000);
    const rem = num % 1000;
    let thWord = '';
    if (th === 1) thWord = 'ألف';
    else if (th === 2) thWord = 'ألفان';
    else if (th >= 3 && th <= 10) thWord = `${ONES[th]} آلاف`;
    else thWord = `${numberToArabicWords(th)} ألف`;
    return rem === 0 ? thWord : `${thWord} و${numberToArabicWords(rem)}`;
  }
  return String(num);
}

/**
 * Split mixed Latin usernames like "Amine_DZ16" into readable parts: "Amine DZ 16".
 */
export function humanizeUsername(raw: string): string {
  return raw
    .replace(/^@+/, '')
    .replace(/[_.-]+/g, ' ')
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/([A-Za-z])(\d)/g, '$1 $2')
    .replace(/(\d)([A-Za-z])/g, '$1 $2')
    .replace(/\s+/g, ' ')
    .trim();
}

export function normalizeArabicText(
  input: string,
  options?: {
    dictionary?: PronunciationEntry[];
    maxLength?: number;
    convertNumbers?: boolean;
  },
): string {
  const maxLength = options?.maxLength ?? 360;
  const convertNumbers = options?.convertNumbers ?? true;
  const dict = options?.dictionary ?? DEFAULT_PRONUNCIATION_DICT;

  let text = input || '';

  // 1. Strip URLs
  text = text.replace(/https?:\/\/\S+|www\.\S+/gi, ' ');

  // 2. Strip emojis & pictographs while keeping Arabic, Latin, digits, and punctuation
  text = text.replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{200D}]/gu, ' ');

  // 3. Convert Arabic-Indic / Persian digits to Western ASCII digits
  text = text.replace(/[٠-٩۰-۹]/g, (ch) => ARABIC_INDIC_MAP[ch] ?? ch);

  // 4. Split mixed usernames (e.g. Amine_DZ16 -> Amine DZ 16)
  text = text.replace(/\b[A-Za-z][A-Za-z0-9_.-]{2,}\b/g, (token) => humanizeUsername(token));

  // 5. Collapse elongated repeated letters ("هههههه" -> "هه", "مبروووووك" -> "مبروك")
  text = text.replace(/([\u0621-\u064A])\1{2,}/g, '$1$1');
  text = text.replace(/([A-Za-z])\1{2,}/g, '$1$1');

  // 6. Normalize Alef / Yaa / Tatweel variants (preserve readable pronunciation)
  text = text
    .replace(/\u0640+/g, '') // remove tatweel ـ
    .replace(/[إأآٱ]/g, 'ا')
    .replace(/ى(?=\s|$|[،.!؟])/g, 'ي')
    .replace(/ة(?=\s|$|[،.!؟])/g, 'ه');

  // 7. Apply user-editable pronunciation dictionary (word-boundary safe)
  for (const entry of dict) {
    if (!entry.from.trim() || !entry.to.trim()) continue;
    const escaped = entry.from.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const re = new RegExp(`(?<![A-Za-z0-9\\u0621-\\u064A])${escaped}(?![A-Za-z0-9\\u0621-\\u064A])`, 'gi');
    text = text.replace(re, entry.to);
  }

  // 8. Convert standalone numbers to spoken Arabic words when enabled
  if (convertNumbers) {
    text = text.replace(/\b(\d{1,6})\b/g, (_, digits: string) => {
      const n = Number(digits);
      return Number.isFinite(n) ? numberToArabicWords(n) : digits;
    });
  }

  // 9. Clean whitespace and cap length cleanly on word boundary
  text = text.replace(/\s+/g, ' ').trim();
  if (text.length > maxLength) {
    text = text.slice(0, maxLength).replace(/\s+\S*$/, '').trim();
  }
  return text;
}

/**
 * Split long TTS text into sentence/clause chunks (<= maxChunkChars) so Web Speech never cuts off.
 */
export function chunkTtsText(text: string, maxChunkChars = 180): string[] {
  const cleaned = text.replace(/\s+/g, ' ').trim();
  if (!cleaned) return [];
  if (cleaned.length <= maxChunkChars) return [cleaned];

  const sentences = cleaned.split(/(?<=[.!؟،,;:])\s+/);
  const chunks: string[] = [];
  let current = '';

  for (const sentence of sentences) {
    if (!sentence) continue;
    if (sentence.length > maxChunkChars) {
      if (current) {
        chunks.push(current.trim());
        current = '';
      }
      const words = sentence.split(' ');
      let part = '';
      for (const word of words) {
        if ((part + ' ' + word).trim().length > maxChunkChars) {
          if (part) chunks.push(part.trim());
          part = word;
        } else {
          part = (part + ' ' + word).trim();
        }
      }
      if (part) chunks.push(part.trim());
    } else if ((current + ' ' + sentence).trim().length > maxChunkChars) {
      if (current) chunks.push(current.trim());
      current = sentence;
    } else {
      current = (current + ' ' + sentence).trim();
    }
  }
  if (current) chunks.push(current.trim());
  return chunks;
}
