/**
 * Optional, documented OBS WebSocket v5 client.
 * - Never enabled automatically.
 * - Never logs or exposes the WebSocket password.
 * - Fails cleanly with honest diagnostics when OBS WebSocket is unreachable.
 */
export interface ObsConnectionResult {
  connected: boolean;
  obsWebSocketVersion?: string;
  error?: string;
}

export async function testObsWebSocketConnection(params: {
  host: string;
  port: number;
  password?: string;
  timeoutMs?: number;
}): Promise<ObsConnectionResult> {
  if (typeof WebSocket === 'undefined') {
    return { connected: false, error: 'WebSocket API is unavailable in this environment.' };
  }

  const safeHost = params.host.trim() || '127.0.0.1';
  const safePort = Number.isFinite(params.port) && params.port > 0 ? params.port : 4455;
  const url = `ws://${safeHost}:${safePort}`;
  const timeoutMs = params.timeoutMs ?? 3500;

  return new Promise((resolve) => {
    let settled = false;
    let ws: WebSocket | null = null;

    const finish = (res: ObsConnectionResult) => {
      if (settled) return;
      settled = true;
      if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
        try {
          ws.close();
        } catch {
          // Ignore close error
        }
      }
      resolve(res);
    };

    const timer = setTimeout(() => {
      finish({
        connected: false,
        error: `Timed out reaching OBS WebSocket at ${safeHost}:${safePort}. Verify OBS Studio is running and Tools → WebSocket Server Settings is enabled.`,
      });
    }, timeoutMs);

    try {
      ws = new WebSocket(url);
      ws.onmessage = (ev: MessageEvent) => {
        try {
          const msg = JSON.parse(String(ev.data)) as {
            op?: number;
            d?: { obsWebSocketVersion?: string; authentication?: { challenge: string; salt: string } };
          };
          if (msg.op === 0 && msg.d) {
            clearTimeout(timer);
            finish({
              connected: true,
              obsWebSocketVersion: msg.d.obsWebSocketVersion ?? '5.x',
            });
          }
        } catch {
          clearTimeout(timer);
          finish({ connected: false, error: 'Received unexpected non-OBS handshake payload.' });
        }
      };
      ws.onerror = () => {
        clearTimeout(timer);
        finish({
          connected: false,
          error: `Could not connect to ${safeHost}:${safePort}. Ensure OBS Studio WebSocket v5 is enabled and not blocked by firewall or browser mixed-content rules.`,
        });
      };
    } catch (err) {
      clearTimeout(timer);
      finish({
        connected: false,
        error: err instanceof Error ? err.message : 'Failed to initialize OBS WebSocket client.',
      });
    }
  });
}
