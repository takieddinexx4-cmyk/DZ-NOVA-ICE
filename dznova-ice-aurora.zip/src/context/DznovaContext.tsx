import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type {
  AlertConfig,
  AutomationRule,
  BotCommand,
  CompatibilityProfileId,
  Language,
  LiveEventPayload,
  ObsWebSocketConfig,
  OverlayCustomization,
  OverlayTokenRecord,
  OverlayType,
  PlatformStatusRecord,
  RouteId,
  SceneLayer,
  SetupWizardState,
  StreamingPlatformId,
  ThemeMode,
  WilayaScore,
} from '../types/dznova';
import {
  STORAGE_PLATFORM_STATUS_KEY,
  STORAGE_SETUP_WIZARD_KEY,
  STORAGE_TOKENS_KEY,
  broadcastOverlayMessage,
  computeHonestStage,
  createInitialPlatformStatus,
  createOverlayTokenRecord,
  revokeOverlayToken,
  subscribeOverlayBus,
} from '../engine/OverlayEngine';
import { mockLiveSource } from '../engine/MockLiveSource';
import { sharedAudioQueue } from '../engine/AudioQueue';

export interface ToastNotice {
  id: string;
  title: string;
  detail?: string;
  tone: 'cyan' | 'emerald' | 'amber' | 'rose';
}

export interface UserSession {
  signedIn: boolean;
  username: string;
  email: string;
  tiktokHandle: string;
  plan: 'Starter' | 'Aurora Pro' | 'Studio Elite';
}

interface DznovaContextValue {
  route: RouteId;
  navigate: (next: RouteId) => void;
  lang: Language;
  setLang: (lang: Language) => void;
  theme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;
  lowEffects: boolean;
  setLowEffects: (enabled: boolean) => void;
  session: UserSession;
  login: (email: string, username: string, tiktokHandle?: string) => void;
  logout: () => void;
  tokens: OverlayTokenRecord[];
  generateToken: (params: {
    overlayType: OverlayType;
    platform: StreamingPlatformId;
    profile: CompatibilityProfileId;
    width: number;
    height: number;
  }) => OverlayTokenRecord;
  revokeToken: (token: string) => void;
  platforms: Record<StreamingPlatformId, PlatformStatusRecord>;
  markOverlayOpened: (platform: StreamingPlatformId) => void;
  updatePlatformProfile: (platform: StreamingPlatformId, profile: CompatibilityProfileId) => void;
  updatePlatformResolution: (platform: StreamingPlatformId, width: number, height: number) => void;
  runPlatformCheck: (platform: StreamingPlatformId) => void;
  wizard: SetupWizardState;
  updateWizard: (patch: Partial<SetupWizardState>) => void;
  resetWizard: () => void;
  obsWs: ObsWebSocketConfig;
  setObsWs: React.Dispatch<React.SetStateAction<ObsWebSocketConfig>>;
  events: LiveEventPayload[];
  triggerMockGift: (platform?: StreamingPlatformId | 'all') => void;
  triggerMockFollow: (platform?: StreamingPlatformId | 'all') => void;
  triggerMockChat: (msg: string, platform?: StreamingPlatformId | 'all', user?: string) => void;
  simRunning: boolean;
  toggleSimulation: (platform?: StreamingPlatformId | 'all') => void;
  wilayas: WilayaScore[];
  boostWilaya: (code: string, points: number) => void;
  resetWilayas: () => void;
  alertConfig: AlertConfig;
  setAlertConfig: React.Dispatch<React.SetStateAction<AlertConfig>>;
  botCommands: BotCommand[];
  setBotCommands: React.Dispatch<React.SetStateAction<BotCommand[]>>;
  automationRules: AutomationRule[];
  setAutomationRules: React.Dispatch<React.SetStateAction<AutomationRule[]>>;
  sceneLayers: SceneLayer[];
  setSceneLayers: React.Dispatch<React.SetStateAction<SceneLayer[]>>;
  overlayCustom: OverlayCustomization;
  setOverlayCustom: React.Dispatch<React.SetStateAction<OverlayCustomization>>;
  toasts: ToastNotice[];
  pushToast: (title: string, detail?: string, tone?: ToastNotice['tone']) => void;
  showIntroModal: boolean;
  setShowIntroModal: (v: boolean) => void;
}

const DEFAULT_WILAYAS: WilayaScore[] = [
  { code: '16', nameAr: 'الجزائر العاصمة', nameEn: 'Algiers', points: 1420 },
  { code: '31', nameAr: 'وهران', nameEn: 'Oran', points: 1290 },
  { code: '18', nameAr: 'جيجل', nameEn: 'Jijel', points: 1180 },
  { code: '25', nameAr: 'قسنطينة', nameEn: 'Constantine', points: 960 },
  { code: '19', nameAr: 'سطيف', nameEn: 'Setif', points: 880 },
  { code: '06', nameAr: 'بجاية', nameEn: 'Bejaia', points: 790 },
  { code: '23', nameAr: 'عنابة', nameEn: 'Annaba', points: 640 },
  { code: '09', nameAr: 'البليدة', nameEn: 'Blida', points: 520 },
];

const DEFAULT_WIZARD: SetupWizardState = {
  target: 'both',
  step: 1,
  selectedOverlays: ['alerts', 'wilaya', 'chat'],
  resolution: { width: 1920, height: 1080, label: '1080p Full HD (1920x1080)' },
  profile: 'tiktok_standard',
  generatedTokens: {},
  testEventSent: false,
  completed: false,
  updatedAt: Date.now(),
};

const ROUTE_PATHS: Record<RouteId, string> = {
  landing: '/',
  register: '/register',
  login: '/login',
  dashboard: '/app/dashboard',
  'streaming-platforms': '/app/streaming-platforms',
  overlays: '/app/overlays',
  'overlay-editor': '/app/overlay-editor',
  'scene-editor': '/app/scene-editor',
  alerts: '/app/alerts',
  chat: '/app/chat',
  bot: '/app/bot',
  automation: '/app/automation',
  tts: '/app/tts',
  'wilaya-battle': '/app/wilaya-battle',
  analytics: '/app/analytics',
  billing: '/app/billing',
  settings: '/app/settings',
  admin: '/app/admin',
  support: '/app/support',
  'icon-studio': '/app/icon-studio',
};

function resolveRouteFromHash(): RouteId {
  if (typeof window === 'undefined') return 'dashboard';
  const raw = window.location.hash.replace(/^#\/?/, '').split('?')[0];
  if (!raw || raw === '') return 'landing';
  const normalized = `/${raw}`;
  const found = (Object.entries(ROUTE_PATHS) as [RouteId, string][]).find(
    ([id, path]) => path === normalized || id === raw,
  );
  return found ? found[0] : 'dashboard';
}

function safeLoad<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

const DznovaContext = createContext<DznovaContextValue | null>(null);

export const DznovaProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [route, setRoute] = useState<RouteId>(() => resolveRouteFromHash());
  const [lang, setLang] = useState<Language>(() => safeLoad<Language>('dznova_lang', 'ar'));
  const [theme, setTheme] = useState<ThemeMode>(() => safeLoad<ThemeMode>('dznova_theme', 'dark'));
  const [lowEffects, setLowEffects] = useState<boolean>(() => safeLoad<boolean>('dznova_low_effects', false));
  const [showIntroModal, setShowIntroModal] = useState<boolean>(false);
  const [toasts, setToasts] = useState<ToastNotice[]>([]);

  const [session, setSession] = useState<UserSession>(() =>
    safeLoad<UserSession>('dznova_session', {
      signedIn: true,
      username: 'DZ_Creator',
      email: 'creator@dznova.live',
      tiktokHandle: '@dznova_live',
      plan: 'Aurora Pro',
    }),
  );

  const [tokens, setTokens] = useState<OverlayTokenRecord[]>(() =>
    safeLoad<OverlayTokenRecord[]>(STORAGE_TOKENS_KEY, []),
  );

  const [platforms, setPlatforms] = useState<Record<StreamingPlatformId, PlatformStatusRecord>>(() =>
    safeLoad<Record<StreamingPlatformId, PlatformStatusRecord>>(STORAGE_PLATFORM_STATUS_KEY, {
      tiktok_live_studio: createInitialPlatformStatus('tiktok_live_studio'),
      obs_studio: createInitialPlatformStatus('obs_studio'),
    }),
  );

  const [wizard, setWizard] = useState<SetupWizardState>(() =>
    safeLoad<SetupWizardState>(STORAGE_SETUP_WIZARD_KEY, DEFAULT_WIZARD),
  );

  const [obsWs, setObsWs] = useState<ObsWebSocketConfig>({
    enabled: false,
    host: '127.0.0.1',
    port: 4455,
    hasPassword: false,
    status: 'disabled',
    lastError: null,
    lastCheckedAt: null,
  });

  const [events, setEvents] = useState<LiveEventPayload[]>([]);
  const [simRunning, setSimRunning] = useState<boolean>(false);
  const [wilayas, setWilayas] = useState<WilayaScore[]>(DEFAULT_WILAYAS);

  const [alertConfig, setAlertConfig] = useState<AlertConfig>({
    enabled: true,
    minCoins: 10,
    durationMs: 4500,
    soundEnabled: true,
    ttsEnabled: true,
    accentColor: '#58DDF5',
  });

  const [botCommands, setBotCommands] = useState<BotCommand[]>([
    { id: 'cmd1', trigger: '!wilaya', response: 'أرسل هدية مع رقم ولايتك لدعمها في تحدي الولايات!', enabled: true, cooldownSec: 5 },
    { id: 'cmd2', trigger: '!obs', response: 'البث يعمل بمنظومة DZNOVA Ice Aurora المتوافقة مع OBS و TikTok LIVE Studio.', enabled: true, cooldownSec: 10 },
    { id: 'cmd3', trigger: '!tiktok', response: 'تابع الحساب وفعّل الجرس للمشاركة في الجولات المباشرة!', enabled: true, cooldownSec: 10 },
  ]);

  const [automationRules, setAutomationRules] = useState<AutomationRule[]>([
    {
      id: 'rule1',
      name: 'Gift → Chime & TTS',
      triggerType: 'gift',
      conditionValue: '>= 100 coins',
      actionType: 'tts',
      actionPayload: 'شكراً على الهدية الكريستالية!',
      enabled: true,
      executions: 0,
    },
    {
      id: 'rule2',
      name: 'Follow → Welcome Sound',
      triggerType: 'follow',
      conditionValue: 'Any follower',
      actionType: 'sound',
      actionPayload: 'crystal_chime',
      enabled: true,
      executions: 0,
    },
  ]);

  const [sceneLayers, setSceneLayers] = useState<SceneLayer[]>([
    { id: 'lay1', overlayType: 'alerts', label: 'Ice Alerts Banner', x: 560, y: 80, scale: 1, visible: true, zIndex: 30 },
    { id: 'lay2', overlayType: 'wilaya', label: 'Wilaya Battle HUD', x: 60, y: 140, scale: 1, visible: true, zIndex: 20 },
    { id: 'lay3', overlayType: 'chat', label: 'Aurora Live Chat', x: 1400, y: 380, scale: 1, visible: true, zIndex: 15 },
    { id: 'lay4', overlayType: 'goal', label: 'Stream Goal Bar', x: 560, y: 940, scale: 1, visible: true, zIndex: 25 },
  ]);

  const [overlayCustom, setOverlayCustom] = useState<OverlayCustomization>({
    accentColor: '#58DDF5',
    scale: 1,
    opacity: 0.92,
    fontScale: 1,
    profile: 'obs_standard',
    showBadges: true,
  });

  const pushToast = useCallback((title: string, detail?: string, tone: ToastNotice['tone'] = 'cyan') => {
    const id = `t_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    setToasts((prev) => [...prev.slice(-3), { id, title, detail, tone }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((item) => item.id !== id));
    }, 3800);
  }, []);

  const navigate = useCallback((next: RouteId) => {
    setRoute(next);
    if (typeof window !== 'undefined') {
      const targetHash = `#${ROUTE_PATHS[next]}`;
      if (window.location.hash !== targetHash) {
        window.location.hash = targetHash;
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, []);

  useEffect(() => {
    const onHashChange = () => setRoute(resolveRouteFromHash());
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    window.localStorage.setItem('dznova_lang', JSON.stringify(lang));
  }, [lang]);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    window.localStorage.setItem('dznova_theme', JSON.stringify(theme));
  }, [theme]);

  useEffect(() => {
    document.documentElement.classList.toggle('low-effects', lowEffects);
    window.localStorage.setItem('dznova_low_effects', JSON.stringify(lowEffects));
  }, [lowEffects]);

  useEffect(() => {
    window.localStorage.setItem(STORAGE_TOKENS_KEY, JSON.stringify(tokens));
  }, [tokens]);

  useEffect(() => {
    window.localStorage.setItem(STORAGE_PLATFORM_STATUS_KEY, JSON.stringify(platforms));
  }, [platforms]);

  useEffect(() => {
    window.localStorage.setItem(STORAGE_SETUP_WIZARD_KEY, JSON.stringify(wizard));
  }, [wizard]);

  useEffect(() => {
    window.localStorage.setItem('dznova_session', JSON.stringify(session));
  }, [session]);

  // Listen to real heartbeats from mounted transparent browser-source overlays
  useEffect(() => {
    return subscribeOverlayBus((msg) => {
      if (msg.kind === 'heartbeat' && msg.payload && typeof msg.payload === 'object') {
        const hb = msg.payload as { platform?: StreamingPlatformId; overlayType?: string; ts?: number };
        if (hb.platform === 'obs_studio' || hb.platform === 'tiktok_live_studio') {
          const target = hb.platform;
          setPlatforms((prev) => {
            const current = prev[target];
            const now = Date.now();
            const updated: PlatformStatusRecord = {
              ...current,
              browserSourceLoadedAt: current.browserSourceLoadedAt ?? now,
              lastHeartbeatAt: now,
              lastCheckAt: now,
            };
            updated.stage = computeHonestStage(updated);
            return { ...prev, [target]: updated };
          });
        }
      }
    });
  }, []);

  const handleIncomingEvent = useCallback(
    (ev: LiveEventPayload) => {
      setEvents((prev) => [ev, ...prev].slice(0, 60));

      if (ev.type === 'gift' && ev.wilayaCode) {
        const add = ev.coins ?? 50;
        setWilayas((prev) =>
          prev
            .map((w) => (w.code === ev.wilayaCode ? { ...w, points: w.points + add } : w))
            .sort((a, b) => b.points - a.points),
        );
      }

      if (ev.type === 'gift' && alertConfig.enabled && alertConfig.soundEnabled) {
        sharedAudioQueue.enqueue({ id: ev.id, kind: 'tone', frequency: 680, durationMs: 220 });
      }

      const targets: StreamingPlatformId[] =
        ev.targetPlatform === 'all' ? ['tiktok_live_studio', 'obs_studio'] : [ev.targetPlatform];

      setPlatforms((prev) => {
        const next = { ...prev };
        targets.forEach((plat) => {
          const cur = prev[plat];
          const updated: PlatformStatusRecord = {
            ...cur,
            eventSourceActive: true,
            lastEventAt: ev.timestamp,
            lastEventSummary: `${ev.type.toUpperCase()} • ${ev.username}${ev.giftName ? ` (${ev.giftName})` : ''}`,
            lastCheckAt: Date.now(),
          };
          updated.stage = computeHonestStage(updated);
          next[plat] = updated;
        });
        return next;
      });

      setAutomationRules((prev) =>
        prev.map((r) =>
          r.enabled && r.triggerType === ev.type ? { ...r, executions: r.executions + 1 } : r,
        ),
      );
    },
    [alertConfig.enabled, alertConfig.soundEnabled],
  );

  useEffect(() => {
    return mockLiveSource.subscribe(handleIncomingEvent);
  }, [handleIncomingEvent]);

  const generateToken = useCallback(
    (params: {
      overlayType: OverlayType;
      platform: StreamingPlatformId;
      profile: CompatibilityProfileId;
      width: number;
      height: number;
    }) => {
      const rec = createOverlayTokenRecord(params);
      setTokens((prev) => [rec, ...prev]);
      setPlatforms((prev) => {
        const cur = prev[params.platform];
        const updated: PlatformStatusRecord = {
          ...cur,
          urlGeneratedAt: Date.now(),
          activeProfile: params.profile,
          resolution: { width: params.width, height: params.height },
          lastCheckAt: Date.now(),
        };
        updated.stage = computeHonestStage(updated);
        return { ...prev, [params.platform]: updated };
      });
      return rec;
    },
    [],
  );

  const revokeToken = useCallback(
    (token: string) => {
      setTokens((prev) => revokeOverlayToken(prev, token));
      broadcastOverlayMessage({ kind: 'token_revoked', payload: { token } });
      pushToast(
        lang === 'ar' ? 'تم إلغاء الرمز الأمني' : 'Overlay token revoked',
        lang === 'ar'
          ? 'تم تعطيل الرابط السابق فوراً في جميع مصادر المتصفح.'
          : 'The previous URL is immediately invalidated across active Browser Sources.',
        'amber',
      );
    },
    [lang, pushToast],
  );

  const markOverlayOpened = useCallback((platform: StreamingPlatformId) => {
    setPlatforms((prev) => {
      const cur = prev[platform];
      const updated: PlatformStatusRecord = {
        ...cur,
        overlayOpenedAt: Date.now(),
        lastCheckAt: Date.now(),
      };
      updated.stage = computeHonestStage(updated);
      return { ...prev, [platform]: updated };
    });
  }, []);

  const updatePlatformProfile = useCallback(
    (platform: StreamingPlatformId, profile: CompatibilityProfileId) => {
      setPlatforms((prev) => ({
        ...prev,
        [platform]: { ...prev[platform], activeProfile: profile, lastCheckAt: Date.now() },
      }));
    },
    [],
  );

  const updatePlatformResolution = useCallback(
    (platform: StreamingPlatformId, width: number, height: number) => {
      setPlatforms((prev) => ({
        ...prev,
        [platform]: { ...prev[platform], resolution: { width, height }, lastCheckAt: Date.now() },
      }));
    },
    [],
  );

  const runPlatformCheck = useCallback(
    (platform: StreamingPlatformId) => {
      setPlatforms((prev) => {
        const cur = prev[platform];
        const staleHeartbeat =
          cur.lastHeartbeatAt !== null && Date.now() - cur.lastHeartbeatAt > 20000;
        const errors: string[] = [];
        if (!cur.urlGeneratedAt) {
          errors.push('No Browser Source URL has been generated yet.');
        } else if (!cur.lastHeartbeatAt || staleHeartbeat) {
          errors.push(
            'No live Browser Source heartbeat detected in the last 20s. Open the URL in your streaming app or preview window to verify loading.',
          );
        }
        const updated: PlatformStatusRecord = {
          ...cur,
          browserSourceLoadedAt: staleHeartbeat ? null : cur.browserSourceLoadedAt,
          lastCheckAt: Date.now(),
          errors,
        };
        updated.stage = computeHonestStage(updated);
        return { ...prev, [platform]: updated };
      });
      pushToast(
        lang === 'ar' ? 'تم فحص حالة التكامل' : 'Platform diagnostic check complete',
        undefined,
        'cyan',
      );
    },
    [lang, pushToast],
  );

  const updateWizard = useCallback((patch: Partial<SetupWizardState>) => {
    setWizard((prev) => ({ ...prev, ...patch, updatedAt: Date.now() }));
  }, []);

  const resetWizard = useCallback(() => {
    setWizard({ ...DEFAULT_WIZARD, updatedAt: Date.now() });
  }, []);

  const login = useCallback((email: string, username: string, tiktokHandle = '@dznova_live') => {
    setSession({ signedIn: true, email, username, tiktokHandle, plan: 'Aurora Pro' });
    navigate('dashboard');
  }, [navigate]);

  const logout = useCallback(() => {
    setSession((prev) => ({ ...prev, signedIn: false }));
    navigate('login');
  }, [navigate]);

  const triggerMockGift = useCallback((platform: StreamingPlatformId | 'all' = 'all') => {
    mockLiveSource.triggerTestGift(platform);
  }, []);

  const triggerMockFollow = useCallback((platform: StreamingPlatformId | 'all' = 'all') => {
    mockLiveSource.triggerTestFollow(platform);
  }, []);

  const triggerMockChat = useCallback(
    (msg: string, platform: StreamingPlatformId | 'all' = 'all', user?: string) => {
      mockLiveSource.triggerTestChat(msg, platform, user);
    },
    [],
  );

  const toggleSimulation = useCallback((platform: StreamingPlatformId | 'all' = 'all') => {
    if (mockLiveSource.isRunning()) {
      mockLiveSource.stopStreamSimulation();
      setSimRunning(false);
    } else {
      mockLiveSource.startStreamSimulation(platform, 4200);
      setSimRunning(true);
    }
  }, []);

  const boostWilaya = useCallback((code: string, points: number) => {
    setWilayas((prev) =>
      prev
        .map((w) => (w.code === code ? { ...w, points: w.points + points } : w))
        .sort((a, b) => b.points - a.points),
    );
    mockLiveSource.emit({
      id: `wb_${Date.now()}`,
      type: 'gift',
      source: 'manual',
      targetPlatform: 'all',
      username: 'StudioHost',
      giftName: 'Wilaya Boost',
      coins: points,
      wilayaCode: code,
      timestamp: Date.now(),
    });
  }, []);

  const resetWilayas = useCallback(() => {
    setWilayas(DEFAULT_WILAYAS.map((w) => ({ ...w, points: 0 })));
  }, []);

  return (
    <DznovaContext.Provider
      value={{
        route,
        navigate,
        lang,
        setLang,
        theme,
        setTheme,
        lowEffects,
        setLowEffects,
        session,
        login,
        logout,
        tokens,
        generateToken,
        revokeToken,
        platforms,
        markOverlayOpened,
        updatePlatformProfile,
        updatePlatformResolution,
        runPlatformCheck,
        wizard,
        updateWizard,
        resetWizard,
        obsWs,
        setObsWs,
        events,
        triggerMockGift,
        triggerMockFollow,
        triggerMockChat,
        simRunning,
        toggleSimulation,
        wilayas,
        boostWilaya,
        resetWilayas,
        alertConfig,
        setAlertConfig,
        botCommands,
        setBotCommands,
        automationRules,
        setAutomationRules,
        sceneLayers,
        setSceneLayers,
        overlayCustom,
        setOverlayCustom,
        toasts,
        pushToast,
        showIntroModal,
        setShowIntroModal,
      }}
    >
      {children}
    </DznovaContext.Provider>
  );
};

export function useDznova(): DznovaContextValue {
  const ctx = useContext(DznovaContext);
  if (!ctx) throw new Error('useDznova must be used within DznovaProvider');
  return ctx;
}
