import React, { useEffect, useState } from 'react';
import { DznovaProvider, useDznova } from './context/DznovaContext';
import { IceAuroraBackground } from './components/IceAuroraBackground';
import { DznovaLogo } from './components/DznovaLogo';
import { GlassButton } from './components/GlassUI';
import { OverlayRenderer } from './overlays/OverlayRenderer';
import { StreamingPlatformsPage } from './pages/StreamingPlatformsPage';
import {
  AuthPage,
  DashboardPage,
  LandingPage,
  OverlayEditorPage,
  OverlayLibraryPage,
  SceneEditorPage,
} from './pages/CoreWorkspacePages';
import {
  AdminPanelPage,
  AlertsPage,
  AnalyticsPage,
  AutomationPage,
  BillingPage,
  BotPage,
  ChatPage,
  IconStudioPage,
  SettingsPage,
  SupportPage,
  TtsPage,
  WilayaBattlePage,
} from './pages/InteractiveFeaturePages';
import type { OverlayType, RouteId } from './types/dznova';
import {
  AdminPanelIcon,
  AlertsIcon,
  AnalyticsIcon,
  AutomationIcon,
  BillingIcon,
  ChatbotIcon,
  ChatIcon,
  DarkModeIcon,
  DashboardIcon,
  LightModeIcon,
  OverlayLibraryIcon,
  PerformanceIcon,
  SceneEditorIcon,
  SettingsIcon,
  StreamingPlatformsIcon,
  SupportIcon,
  ThemeSelectorIcon,
  TtsIcon,
  WilayaBattleIcon,
} from './components/icons';
import { t } from './i18n/translations';

const NAV_ITEMS: { id: RouteId; labelKey: string; Icon: React.FC<{ size?: number; active?: boolean }> }[] = [
  { id: 'dashboard', labelKey: 'navDashboard', Icon: DashboardIcon },
  { id: 'streaming-platforms', labelKey: 'navStreamingPlatforms', Icon: StreamingPlatformsIcon },
  { id: 'overlays', labelKey: 'navOverlays', Icon: OverlayLibraryIcon },
  { id: 'overlay-editor', labelKey: 'navOverlayEditor', Icon: ThemeSelectorIcon },
  { id: 'scene-editor', labelKey: 'navSceneEditor', Icon: SceneEditorIcon },
  { id: 'alerts', labelKey: 'navAlerts', Icon: AlertsIcon },
  { id: 'chat', labelKey: 'navChat', Icon: ChatIcon },
  { id: 'bot', labelKey: 'navBot', Icon: ChatbotIcon },
  { id: 'automation', labelKey: 'navAutomation', Icon: AutomationIcon },
  { id: 'tts', labelKey: 'navTts', Icon: TtsIcon },
  { id: 'wilaya-battle', labelKey: 'navWilayaBattle', Icon: WilayaBattleIcon },
  { id: 'analytics', labelKey: 'navAnalytics', Icon: AnalyticsIcon },
  { id: 'billing', labelKey: 'navBilling', Icon: BillingIcon },
  { id: 'settings', labelKey: 'navSettings', Icon: SettingsIcon },
  { id: 'admin', labelKey: 'navAdmin', Icon: AdminPanelIcon },
  { id: 'support', labelKey: 'navSupport', Icon: SupportIcon },
  { id: 'icon-studio', labelKey: 'navIconStudio', Icon: PerformanceIcon },
];

const AppShell: React.FC = () => {
  const {
    route,
    navigate,
    lang,
    setLang,
    theme,
    setTheme,
    lowEffects,
    setLowEffects,
    toasts,
    showIntroModal,
    setShowIntroModal,
  } = useDznova();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const renderPage = () => {
    switch (route) {
      case 'landing':
        return <LandingPage />;
      case 'login':
        return <AuthPage mode="login" />;
      case 'register':
        return <AuthPage mode="register" />;
      case 'dashboard':
        return <DashboardPage />;
      case 'streaming-platforms':
        return <StreamingPlatformsPage />;
      case 'overlays':
        return <OverlayLibraryPage />;
      case 'overlay-editor':
        return <OverlayEditorPage />;
      case 'scene-editor':
        return <SceneEditorPage />;
      case 'alerts':
        return <AlertsPage />;
      case 'chat':
        return <ChatPage />;
      case 'bot':
        return <BotPage />;
      case 'automation':
        return <AutomationPage />;
      case 'tts':
        return <TtsPage />;
      case 'wilaya-battle':
        return <WilayaBattlePage />;
      case 'analytics':
        return <AnalyticsPage />;
      case 'billing':
        return <BillingPage />;
      case 'settings':
        return <SettingsPage />;
      case 'admin':
        return <AdminPanelPage />;
      case 'support':
        return <SupportPage />;
      case 'icon-studio':
        return <IconStudioPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <div className="min-h-screen">
      <IceAuroraBackground lowEffects={lowEffects} theme={theme} />

      {/* Top Liquid Glass Header */}
      <header className="ice-glass sticky top-0 z-30 border-b border-ice-crystal/20 px-4 py-3">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setMobileMenuOpen((v) => !v)}
              className="ice-glass rounded-xl px-3 py-1.5 text-xs font-bold lg:hidden"
            >
              {mobileMenuOpen ? '✕' : '☰'}
            </button>
            <button type="button" onClick={() => navigate('landing')}>
              <DznovaLogo variant="compact" theme={theme} size={36} />
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <GlassButton size="sm" onClick={() => setLang(lang === 'ar' ? 'en' : lang === 'en' ? 'fr' : 'ar')}>
              {lang.toUpperCase()}
            </GlassButton>
            <GlassButton size="sm" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
              {theme === 'dark' ? <LightModeIcon size={18} /> : <DarkModeIcon size={18} />}
            </GlassButton>
            <GlassButton size="sm" variant={lowEffects ? 'primary' : 'secondary'} onClick={() => setLowEffects(!lowEffects)}>
              {t(lang, 'lowEffects')}
            </GlassButton>
            <GlassButton size="sm" variant="primary" onClick={() => navigate('streaming-platforms')}>
              {t(lang, 'navStreamingPlatforms')}
            </GlassButton>
          </div>
        </div>
      </header>

      {/* Main Content Layout */}
      <div className="mx-auto flex max-w-7xl gap-5 px-4 py-6">
        <aside
          className={`${
            mobileMenuOpen ? 'fixed inset-y-16 start-4 z-40 block w-64 overflow-y-auto' : 'hidden'
          } ice-glass shrink-0 rounded-2xl p-3 lg:sticky lg:top-20 lg:block lg:h-[calc(100vh-6.5rem)] lg:w-60 lg:overflow-y-auto`}
        >
          <nav className="space-y-1">
            {NAV_ITEMS.map(({ id, labelKey, Icon }) => {
              const active = route === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => {
                    navigate(id);
                    setMobileMenuOpen(false);
                  }}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2 text-xs font-bold transition ${
                    active
                      ? 'bg-gradient-to-r from-ice-glacier/25 to-ice-nebula/25 text-ice-glacier border border-ice-glacier/40'
                      : 'hover:bg-ice-crystal/10 opacity-85'
                  }`}
                >
                  <Icon size={22} active={active} />
                  <span>{t(lang, labelKey)}</span>
                </button>
              );
            })}
          </nav>
        </aside>

        <main className="min-w-0 flex-1">{renderPage()}</main>
      </div>

      {/* Floating Notifications */}
      <div className="fixed bottom-4 end-4 z-50 flex flex-col gap-2">
        {toasts.map((toast) => (
          <div key={toast.id} className="ice-glass max-w-xs rounded-2xl border-ice-glacier/45 px-4 py-3 text-xs shadow-ice-glow">
            <p className="font-bold text-ice-glacier">{toast.title}</p>
            {toast.detail && <p className="mt-0.5 opacity-80">{toast.detail}</p>}
          </div>
        ))}
      </div>

      {/* Animated Logo Introduction Modal */}
      {showIntroModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#091526]/85 p-4 backdrop-blur-md"
          onClick={() => setShowIntroModal(false)}
        >
          <div className="ice-glass flex max-w-md flex-col items-center gap-5 rounded-3xl p-10 text-center" onClick={(e) => e.stopPropagation()}>
            <DznovaLogo variant="wordmark" theme="dark" size={78} animated />
            <p className="text-sm text-ice-silver">
              Two Streaming Platforms. One Intelligent Ice Aurora Ecosystem.
            </p>
            <GlassButton variant="primary" onClick={() => setShowIntroModal(false)}>
              {lang === 'ar' ? 'إغلاق' : 'Close'}
            </GlassButton>
          </div>
        </div>
      )}
    </div>
  );
};

export const App: React.FC = () => {
  const [overlayMatch, setOverlayMatch] = useState<{ type: OverlayType; qs: string } | null>(null);

  useEffect(() => {
    const parseOverlayHash = () => {
      const h = window.location.hash;
      const m = h.match(/^#overlay\/(alerts|goal|wilaya|chat|wheel|countdown|leaderboard)(?:\?(.*))?$/);
      if (m) {
        setOverlayMatch({ type: m[1] as OverlayType, qs: m[2] ?? '' });
      } else {
        setOverlayMatch(null);
      }
    };
    parseOverlayHash();
    window.addEventListener('hashchange', parseOverlayHash);
    return () => window.removeEventListener('hashchange', parseOverlayHash);
  }, []);

  if (overlayMatch) {
    return <OverlayRenderer overlayType={overlayMatch.type} queryString={overlayMatch.qs} />;
  }

  return (
    <DznovaProvider>
      <AppShell />
    </DznovaProvider>
  );
};

export default App;
