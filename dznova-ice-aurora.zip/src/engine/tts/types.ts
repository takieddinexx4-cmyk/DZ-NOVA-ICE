export type TtsProviderId = 'web_speech' | 'cloud_neural' | 'native_android';

export type VoicePresetId =
  | 'woman'
  | 'young_woman'
  | 'girl'
  | 'child_boy'
  | 'man'
  | 'deep_man'
  | 'announcer';

export type TtsEventKind =
  | 'gift'
  | 'follow'
  | 'share'
  | 'chat'
  | 'wilaya_win'
  | 'automation';

export type ArabicDialect = 'msa' | 'dz';

export interface TtsVoiceInfo {
  id: string;
  name: string;
  lang: string;
  gender?: 'female' | 'male' | 'neutral';
  isNatural?: boolean;
  provider: TtsProviderId;
}

export interface VoicePresetSpec {
  id: VoicePresetId;
  nameAr: string;
  nameEn: string;
  nameFr: string;
  targetGender: 'female' | 'male' | 'neutral';
  pitch: number;
  rate: number;
  /** True when WebSpeech approximates child/girl voices via pitch shifting rather than a real child voice */
  approximatedOnWebSpeech: boolean;
  noteAr: string;
  noteEn: string;
}

export interface TtsSpeakProfile {
  lang: string;
  voiceId?: string;
  presetId?: VoicePresetId;
  pitch: number;
  rate: number;
  volume: number;
}

export interface TtsProvider {
  id: TtsProviderId;
  isAvailable(): boolean;
  listVoices(): Promise<TtsVoiceInfo[]>;
  speak(text: string, profile: TtsSpeakProfile): Promise<void>;
  cancel(): void;
}

export interface EventTtsRule {
  eventKind: TtsEventKind;
  enabled: boolean;
  presetId: VoicePresetId;
  volume: number;
  rate: number;
  templateArMsa: string;
  templateArDz: string;
  templateEn: string;
  templateFr: string;
}

export interface TtsSettings {
  preferredProvider: TtsProviderId;
  cloudProxyUrl: string;
  selectedPreset: VoicePresetId;
  selectedVoiceId: string;
  lang: string;
  dialect: ArabicDialect;
  rate: number;
  pitch: number;
  volume: number;
  userCooldownSec: number;
  minGiftCoins: number;
  maxLength: number;
  chatReadMode: 'all' | 'commands' | 'off';
  blockedWords: string[];
  dictionary: { from: string; to: string }[];
  eventRules: Record<TtsEventKind, EventTtsRule>;
}

export interface TtsDiagnostics {
  activeProvider: TtsProviderId;
  voicesCount: number;
  arabicVoicesCount: number;
  bestArabicVoice: string | null;
  hasArabicVoice: boolean;
  isNeuralActive: boolean;
  lastError: string | null;
  checkedAt: number;
}

export const VOICE_PRESETS: Record<VoicePresetId, VoicePresetSpec> = {
  woman: {
    id: 'woman',
    nameAr: 'امرأة',
    nameEn: 'Woman',
    nameFr: 'Femme',
    targetGender: 'female',
    pitch: 1.04,
    rate: 0.98,
    approximatedOnWebSpeech: false,
    noteAr: 'صوت نسائي طبيعي متوازن',
    noteEn: 'Balanced female voice',
  },
  young_woman: {
    id: 'young_woman',
    nameAr: 'شابة',
    nameEn: 'Young Woman',
    nameFr: 'Jeune Femme',
    targetGender: 'female',
    pitch: 1.18,
    rate: 1.06,
    approximatedOnWebSpeech: true,
    noteAr: 'نبرة شابة حيوية (تقريبية عبر طبقة الصوت في المتصفح)',
    noteEn: 'Bright younger tone (pitch-approximated in browser)',
  },
  girl: {
    id: 'girl',
    nameAr: 'بنت',
    nameEn: 'Girl',
    nameFr: 'Fille',
    targetGender: 'female',
    pitch: 1.42,
    rate: 1.08,
    approximatedOnWebSpeech: true,
    noteAr: 'تقريبي عبر رفع طبقة الصوت — ليس صوت طفلة حقيقي إلا مع مزود سحابي',
    noteEn: 'Approximated via pitch shift unless using a neural voice',
  },
  child_boy: {
    id: 'child_boy',
    nameAr: 'طفل (ولد)',
    nameEn: 'Child (Boy)',
    nameFr: 'Enfant (Garçon)',
    targetGender: 'male',
    pitch: 1.52,
    rate: 1.1,
    approximatedOnWebSpeech: true,
    noteAr: 'تقريبي عبر رفع طبقة الصوت في المتصفح',
    noteEn: 'Approximated via pitch shift in browser',
  },
  man: {
    id: 'man',
    nameAr: 'رجل',
    nameEn: 'Man',
    nameFr: 'Homme',
    targetGender: 'male',
    pitch: 0.92,
    rate: 0.98,
    approximatedOnWebSpeech: false,
    noteAr: 'صوت رجولي واضح ومعتدل',
    noteEn: 'Clear standard male voice',
  },
  deep_man: {
    id: 'deep_man',
    nameAr: 'رجل عميق',
    nameEn: 'Deep Man',
    nameFr: 'Voix Grave',
    targetGender: 'male',
    pitch: 0.72,
    rate: 0.92,
    approximatedOnWebSpeech: true,
    noteAr: 'نبرة عميقة وقوية (تقريبية عبر خفض طبقة الصوت)',
    noteEn: 'Deep resonant tone (pitch-shifted)',
  },
  announcer: {
    id: 'announcer',
    nameAr: 'معلّق بث',
    nameEn: 'Announcer',
    nameFr: 'Animateur',
    targetGender: 'male',
    pitch: 0.88,
    rate: 1.08,
    approximatedOnWebSpeech: false,
    noteAr: 'أداء سريع وواضح مناسب لتنبيهات الهدايا',
    noteEn: 'Energetic announcer cadence for stream alerts',
  },
};
