import type {
  CompatibilityProfileId,
  LiveEventPayload,
  OverlayTokenRecord,
  OverlayType,
  PlatformConnectionStage,
  PlatformStatusRecord,
  StreamingPlatformId,
} from '../types/dznova';

export const CHANNEL_NAME = 'dznova_ice_aurora_bus_v3';
export const STORAGE_TOKENS_KEY = 'dznova_overlay_tokens_v3';
export const STORAGE_LAST_EVENT_KEY = 'dznova_last_event_v3';
export const STORAGE_HEARTBEAT_KEY = 'dznova_overlay_heartbeat_v3';
export const STORAGE_PLATFORM_STATUS_KEY = 'dznova_platform_status_v3';
export const STORAGE_SETUP_WIZARD_KEY = 'dznova_setup_wizard_v3';

export interface CompatibilityProfileSpec {
  id: CompatibilityProfileId;
  nameAr: string;
  nameEn: string;
  targetFps: number;
  useBackdropBlur: boolean;
  useParticles: boolean;
  useSpecularShimmer: boolean;
  recommendedFor: StreamingPlatformId | 'both';
  notesEn: string;
  notesAr: string;
}

export const COMPATIBILITY_PROFILES: Record<CompatibilityProfileId, CompatibilityProfileSpec> = {
  obs_standard: {
    id: 'obs_standard',
    nameAr: 'معيار OBS Studio القياسي',
    nameEn: 'OBS Standard',
    targetFps: 60,
    useBackdropBlur: true,
    useParticles: true,
    useSpecularShimmer: true,
    recommendedFor: 'obs_studio',
    notesEn: 'Optimized for OBS CEF Browser Source with hardware acceleration and full alpha transparency.',
    notesAr: 'مُحسّن لمصدر المتصفح CEF في OBS مع شفافية كاملة ومعدل 60 إطاراً.',
  },
  tiktok_standard: {
    id: 'tiktok_standard',
    nameAr: 'معيار TikTok LIVE Studio القياسي',
    nameEn: 'TikTok LIVE Studio Standard',
    targetFps: 60,
    useBackdropBlur: false,
    useParticles: true,
    useSpecularShimmer: false,
    recommendedFor: 'tiktok_live_studio',
    notesEn: 'Uses conservative CSS translucency for maximum compatibility with TikTok LIVE Studio webpage/browser sources.',
    notesAr: 'يستخدم شفافية CSS متوافقة تماماً مع متصفح TikTok LIVE Studio لتجنب تقطّع الإطارات.',
  },
  lightweight: {
    id: 'lightweight',
    nameAr: 'الوضع الخفيف (أجهزة ضعيفة)',
    nameEn: 'Lightweight Mode',
    targetFps: 30,
    useBackdropBlur: false,
    useParticles: false,
    useSpecularShimmer: false,
    recommendedFor: 'both',
    notesEn: 'Disables blur filters and particles for minimal CPU/GPU footprint during heavy gaming streams.',
    notesAr: 'يعطّل الضبابية والجزيئات لتقليل استهلاك المعالج أثناء بث الألعاب.',
  },
  high_quality: {
    id: 'high_quality',
    nameAr: 'الجودة العالية (Ice Aurora الكامل)',
    nameEn: 'High Quality Mode',
    targetFps: 60,
    useBackdropBlur: true,
    useParticles: true,
    useSpecularShimmer: true,
    recommendedFor: 'obs_studio',
    notesEn: 'Enables full Ice Aurora refraction, crystal shimmer, and layered specular shadows.',
    notesAr: 'يفعّل كافة انعكاسات الكريستال والضبابية الزجاجية بأعلى جودة بصرية.',
  },
};

export function generateSecureToken(): string {
  const bytes = new Uint8Array(16);
  if (typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function') {
    crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < bytes.length; i += 1) {
      bytes[i] = Math.floor(Math.random() * 256);
    }
  }
  const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
  return `dzn_${hex}`;
}

export function createOverlayTokenRecord(params: {
  overlayType: OverlayType;
  platform: StreamingPlatformId;
  profile: CompatibilityProfileId;
  width: number;
  height: number;
}): OverlayTokenRecord {
  return {
    id: `tok_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    token: generateSecureToken(),
    overlayType: params.overlayType,
    platform: params.platform,
    profile: params.profile,
    width: params.width,
    height: params.height,
    createdAt: Date.now(),
    revoked: false,
  };
}

export function revokeOverlayToken(
  records: OverlayTokenRecord[],
  tokenToRevoke: string,
): OverlayTokenRecord[] {
  return records.map((rec) =>
    rec.token === tokenToRevoke
      ? { ...rec, revoked: true, revokedAt: Date.now() }
      : rec,
  );
}

export function isTokenValid(records: OverlayTokenRecord[], token: string | null): boolean {
  if (!token || !token.startsWith('dzn_')) return false;
  if (records.length === 0) {
    // Allow standalone preview tokens opened in a fresh isolated Browser Source context when no local revocation exists
    return token.length >= 20;
  }
  const match = records.find((r) => r.token === token);
  if (!match) return token.length >= 20;
  return !match.revoked;
}

export function buildOverlayUrl(
  baseUrl: string,
  record: Pick<OverlayTokenRecord, 'overlayType' | 'token' | 'platform' | 'profile' | 'width' | 'height'>,
): string {
  const cleanBase = baseUrl.split('#')[0].split('?')[0];
  const params = new URLSearchParams({
    token: record.token,
    platform: record.platform,
    profile: record.profile,
    w: String(record.width),
    h: String(record.height),
  });
  return `${cleanBase}#overlay/${record.overlayType}?${params.toString()}`;
}

/**
 * Pure honest state computation:
 * - Copying/generating a URL ONLY advances to `url_generated`, NEVER to connected/verified.
 * - Opening a preview advances to `overlay_opened`.
 * - Receiving a live heartbeat from an actual mounted overlay advances to `browser_source_loaded`.
 * - Receiving an event advances to `events_received` (or `integration_verified` if browser source is ALSO loaded).
 */
export function computeHonestStage(status: PlatformStatusRecord): PlatformConnectionStage {
  const hasHeartbeat = Boolean(status.browserSourceLoadedAt && status.lastHeartbeatAt);
  const hasEvents = Boolean(status.eventSourceActive && status.lastEventAt);

  if (hasHeartbeat && hasEvents) return 'integration_verified';
  if (hasEvents) return 'events_received';
  if (hasHeartbeat) return 'browser_source_loaded';
  if (status.overlayOpenedAt) return 'overlay_opened';
  if (status.urlGeneratedAt) return 'url_generated';
  return 'not_configured';
}

export function createInitialPlatformStatus(platform: StreamingPlatformId): PlatformStatusRecord {
  return {
    platform,
    stage: 'not_configured',
    urlGeneratedAt: null,
    overlayOpenedAt: null,
    browserSourceLoadedAt: null,
    lastHeartbeatAt: null,
    eventSourceActive: false,
    lastEventAt: null,
    lastEventSummary: null,
    lastCheckAt: null,
    errors: [],
    activeProfile: platform === 'obs_studio' ? 'obs_standard' : 'tiktok_standard',
    resolution: { width: 1920, height: 1080 },
  };
}

export function broadcastOverlayMessage(message: {
  kind: 'event' | 'heartbeat' | 'token_revoked' | 'config_update' | 'goal_update' | 'countdown_update' | 'wheel_spin' | 'wilaya_update' | 'leaderboard_update' | 'sound_play';
  payload: unknown;
}): void {
  if (typeof window === 'undefined') return;
  try {
    if ('BroadcastChannel' in window) {
      const ch = new BroadcastChannel(CHANNEL_NAME);
      ch.postMessage(message);
      ch.close();
    }
  } catch {
    // Fallback to localStorage below
  }
  try {
    const key =
      message.kind === 'heartbeat' ? STORAGE_HEARTBEAT_KEY : STORAGE_LAST_EVENT_KEY;
    window.localStorage.setItem(key, JSON.stringify({ ...message, ts: Date.now() }));
  } catch {
    // Ignore storage quota issues in private mode
  }
}

export function subscribeOverlayBus(
  onMessage: (message: { kind: string; payload: unknown }) => void,
): () => void {
  if (typeof window === 'undefined') return () => undefined;
  let channel: BroadcastChannel | null = null;

  if ('BroadcastChannel' in window) {
    channel = new BroadcastChannel(CHANNEL_NAME);
    channel.onmessage = (ev: MessageEvent) => {
      if (ev.data && typeof ev.data === 'object') {
        onMessage(ev.data as { kind: string; payload: unknown });
      }
    };
  }

  const onStorage = (ev: StorageEvent) => {
    if (
      (ev.key === STORAGE_LAST_EVENT_KEY || ev.key === STORAGE_HEARTBEAT_KEY) &&
      ev.newValue
    ) {
      try {
        const parsed = JSON.parse(ev.newValue) as { kind: string; payload: unknown };
        onMessage(parsed);
      } catch {
        // Ignore malformed payloads
      }
    }
  };

  window.addEventListener('storage', onStorage);
  return () => {
    window.removeEventListener('storage', onStorage);
    if (channel) channel.close();
  };
}

export function dispatchLiveEvent(event: LiveEventPayload): void {
  broadcastOverlayMessage({ kind: 'event', payload: event });
}
