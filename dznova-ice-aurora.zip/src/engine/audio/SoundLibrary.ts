import { sharedAudioEngine, type SynthNote, type SynthRecipe } from './AudioEngine';
import { getCustomSound } from './SoundDatabase';

export type SoundCategory =
  | 'gifts'
  | 'follow_share'
  | 'chat_like'
  | 'wilaya_wheel'
  | 'countdown_alerts'
  | 'ringtones'
  | 'stingers'
  | 'custom';

export type SoundEventTrigger =
  | 'gift_small'
  | 'gift_medium'
  | 'gift_big'
  | 'gift_legendary'
  | 'gift_named'
  | 'follow'
  | 'share'
  | 'like_milestone'
  | 'chat_keyword'
  | 'wilaya_victory'
  | 'countdown_end';

export interface BuiltInSound {
  id: string;
  nameAr: string;
  nameEn: string;
  category: Exclude<SoundCategory, 'custom'>;
  durationLabel: string;
  recipe: SynthRecipe;
}

export interface EventSoundRule {
  id: string;
  trigger: SoundEventTrigger;
  matchValue?: string; // e.g. specific gift name or chat keyword
  minCoins?: number;
  soundIds: string[]; // supports random-from-playlist when > 1
  volume: number;
  trimStartSec: number;
  trimEndSec: number;
  fadeInSec: number;
  fadeOutSec: number;
  cooldownSec: number;
  enabled: boolean;
}

export interface SoundConfigState {
  favorites: string[];
  rules: EventSoundRule[];
}

export const SOUND_CONFIG_STORAGE_KEY = 'dznova_sound_config_v31';

// Helper to build musical melodies cleanly from MIDI-like frequencies
function seq(
  freqs: number[],
  step: number,
  dur: number,
  wave: OscillatorType = 'triangle',
  fmRatio?: number,
  fmDepth?: number,
): SynthNote[] {
  return freqs.map((freq, idx) => ({
    freq,
    startSec: idx * step,
    durSec: dur,
    wave,
    fmRatio,
    fmDepth,
    gain: 0.24,
  }));
}

/**
 * 44 distinct built-in synthesized sounds & melodies (100% offline, zero copyrighted assets).
 */
export const BUILT_IN_SOUNDS: BuiltInSound[] = [
  // --- GIFTS (Small / Medium / Big / Legendary) ---
  { id: 'gift_crystal_drop', nameAr: 'قطرة كريستال (هدية صغيرة)', nameEn: 'Crystal Drop (Small Gift)', category: 'gifts', durationLabel: '0.4s', recipe: { notes: seq([880, 1318], 0.08, 0.22, 'sine', 2, 120), useReverb: true } },
  { id: 'gift_rose_chime', nameAr: 'رنة الوردة', nameEn: 'Rose Chime', category: 'gifts', durationLabel: '0.5s', recipe: { notes: seq([659, 784, 1046], 0.09, 0.24, 'triangle', 2, 60), useReverb: true } },
  { id: 'gift_coin_sparkle', nameAr: 'بريق العملات', nameEn: 'Coin Sparkle', category: 'gifts', durationLabel: '0.5s', recipe: { notes: seq([987, 1318, 1568], 0.07, 0.2, 'sine', 3, 90) } },
  { id: 'gift_frost_bell', nameAr: 'جرس الجليد', nameEn: 'Frost Bell', category: 'gifts', durationLabel: '0.7s', recipe: { notes: seq([587, 880, 1175], 0.11, 0.35, 'sine', 2.5, 180), useReverb: true } },
  { id: 'gift_aurora_arp', nameAr: 'أربيجيو أورورا (هدية متوسطة)', nameEn: 'Aurora Arpeggio (Medium)', category: 'gifts', durationLabel: '1.0s', recipe: { notes: seq([523, 659, 784, 1046, 1318], 0.1, 0.3, 'triangle', 2, 80), useReverb: true, useDelay: true } },
  { id: 'gift_prism_chord', nameAr: 'وتر المنشور الزجاجي', nameEn: 'Prism Glass Chord', category: 'gifts', durationLabel: '1.1s', recipe: { notes: [{ freq: 440, startSec: 0, durSec: 0.7, wave: 'sine' }, { freq: 554, startSec: 0.06, durSec: 0.7, wave: 'triangle' }, { freq: 659, startSec: 0.12, durSec: 0.7, wave: 'sine' }, { freq: 880, startSec: 0.18, durSec: 0.7, wave: 'triangle', fmRatio: 2, fmDepth: 90 }], useReverb: true } },
  { id: 'gift_sapphire_fanfare', nameAr: 'موسيقى الياقوت (هدية كبيرة)', nameEn: 'Sapphire Fanfare (Big)', category: 'gifts', durationLabel: '1.5s', recipe: { notes: seq([523, 659, 784, 1046, 988, 1046, 1318], 0.12, 0.32, 'sawtooth', 1.5, 60), useReverb: true, noiseBurstAt: [0, 0.72] } },
  { id: 'gift_sahara_lion', nameAr: 'زئير أسد الصحراء (أسطورية)', nameEn: 'Sahara Lion (Legendary)', category: 'gifts', durationLabel: '2.2s', recipe: { notes: seq([220, 293, 330, 440, 587, 659, 880, 1175], 0.16, 0.45, 'sawtooth', 2, 140), useReverb: true, useDelay: true, noiseBurstAt: [0, 0.64, 1.28] } },
  { id: 'gift_nova_supernova', nameAr: 'انفجار نوفا الأسطوري', nameEn: 'Nova Supernova (Legendary)', category: 'gifts', durationLabel: '2.4s', recipe: { notes: seq([261, 329, 392, 523, 659, 784, 1046, 1318, 1568], 0.15, 0.5, 'triangle', 3, 210), useReverb: true, useDelay: true, noiseBurstAt: [0.1, 0.9] } },
  { id: 'gift_diamond_cascade', nameAr: 'شلال الألماس', nameEn: 'Diamond Cascade', category: 'gifts', durationLabel: '1.4s', recipe: { notes: seq([1568, 1318, 1046, 1318, 1568, 1760], 0.11, 0.28, 'sine', 2, 160), useReverb: true, useDelay: true } },

  // --- FOLLOW & SHARE ---
  { id: 'follow_ice_bloom', nameAr: 'تفتّح الجليد (متابعة)', nameEn: 'Ice Bloom (Follow)', category: 'follow_share', durationLabel: '0.7s', recipe: { notes: seq([523, 659, 987], 0.11, 0.3, 'sine', 2, 40), useReverb: true } },
  { id: 'follow_crystal_wave', nameAr: 'موجة الترحيب', nameEn: 'Crystal Welcome Wave', category: 'follow_share', durationLabel: '0.8s', recipe: { notes: seq([440, 554, 659, 880], 0.09, 0.25, 'triangle'), useReverb: true } },
  { id: 'follow_soft_pop', nameAr: 'فقاعة ناعمة', nameEn: 'Soft Glass Pop', category: 'follow_share', durationLabel: '0.4s', recipe: { notes: seq([480, 720], 0.06, 0.16, 'sine') } },
  { id: 'share_aurora_whoosh', nameAr: 'انطلاقة المشاركة', nameEn: 'Aurora Share Boost', category: 'follow_share', durationLabel: '0.8s', recipe: { notes: seq([392, 587, 784, 1175], 0.08, 0.22, 'triangle', 1.5, 90), noiseBurstAt: [0.02] } },
  { id: 'share_double_chime', nameAr: 'رنة المشاركة المزدوجة', nameEn: 'Double Share Chime', category: 'follow_share', durationLabel: '0.6s', recipe: { notes: seq([740, 987, 740, 1108], 0.09, 0.18, 'sine'), useDelay: true } },

  // --- CHAT, LIKE MILESTONE & LEVEL UP ---
  { id: 'like_milestone_1k', nameAr: 'إنجاز الإعجابات', nameEn: 'Like Milestone Spark', category: 'chat_like', durationLabel: '0.9s', recipe: { notes: seq([587, 740, 880, 1175], 0.1, 0.26, 'sine', 2, 70), useReverb: true } },
  { id: 'like_heart_pulse', nameAr: 'نبضة القلوب', nameEn: 'Heart Pulse', category: 'chat_like', durationLabel: '0.5s', recipe: { notes: seq([330, 440, 659], 0.08, 0.18, 'triangle') } },
  { id: 'chat_mention_ping', nameAr: 'إشارة الدردشة', nameEn: 'Chat Mention Ping', category: 'chat_like', durationLabel: '0.3s', recipe: { notes: seq([1046, 1318], 0.07, 0.14, 'sine') } },
  { id: 'chat_crystal_tap', nameAr: 'نقرة زجاجية', nameEn: 'Crystal Glass Tap', category: 'chat_like', durationLabel: '0.25s', recipe: { notes: seq([1480], 0, 0.14, 'sine', 3, 120) } },
  { id: 'levelup_hero', nameAr: 'ترقية المستوى البطل', nameEn: 'Hero Level-Up', category: 'chat_like', durationLabel: '1.2s', recipe: { notes: seq([440, 554, 659, 880, 1108], 0.11, 0.28, 'triangle', 2, 60), useReverb: true } },
  { id: 'levelup_cyber', nameAr: 'ترقية رقمية سريعة', nameEn: 'Cyber Level-Up', category: 'chat_like', durationLabel: '0.9s', recipe: { notes: seq([523, 659, 784, 1046], 0.08, 0.2, 'square'), useDelay: true } },

  // --- WILAYA VICTORY & WHEEL ---
  { id: 'wilaya_victory_anthem', nameAr: 'انتصار الولاية الجزائري', nameEn: 'Wilaya Victory Anthem', category: 'wilaya_wheel', durationLabel: '2.0s', recipe: { notes: seq([440, 554, 587, 740, 880, 740, 880, 1175], 0.16, 0.36, 'triangle', 2, 100), useReverb: true, noiseBurstAt: [0, 0.64, 1.12] } },
  { id: 'wilaya_lead_change', nameAr: 'تغيير صدارة الولايات', nameEn: 'Wilaya Lead Change', category: 'wilaya_wheel', durationLabel: '1.1s', recipe: { notes: seq([392, 494, 587, 784], 0.12, 0.3, 'sawtooth'), useReverb: true } },
  { id: 'wilaya_drum_rally', nameAr: 'قرع طبول الولاية', nameEn: 'Wilaya Drum Rally', category: 'wilaya_wheel', durationLabel: '1.2s', recipe: { notes: seq([140, 160, 140, 180, 220], 0.14, 0.18, 'triangle'), noiseBurstAt: [0, 0.28, 0.56, 0.84] } },
  { id: 'wheel_spin_ticks', nameAr: 'دوران عجلة الحظ', nameEn: 'Wheel Spin Ticks', category: 'wilaya_wheel', durationLabel: '1.4s', recipe: { notes: seq([800, 850, 900, 950, 1000, 950, 900, 850], 0.14, 0.06, 'square') } },
  { id: 'wheel_win_jackpot', nameAr: 'فوز عجلة الحظ', nameEn: 'Wheel Win Jackpot', category: 'wilaya_wheel', durationLabel: '1.6s', recipe: { notes: seq([523, 659, 784, 1046, 1318, 1568], 0.13, 0.36, 'triangle', 2.5, 130), useReverb: true, useDelay: true } },

  // --- COUNTDOWN & ALERTS ---
  { id: 'countdown_tick_soft', nameAr: 'تكة عداد ناعمة', nameEn: 'Countdown Soft Tick', category: 'countdown_alerts', durationLabel: '0.2s', recipe: { notes: seq([920], 0, 0.08, 'sine') } },
  { id: 'countdown_tick_urgent', nameAr: 'تكة الثواني الأخيرة', nameEn: 'Final Seconds Tick', category: 'countdown_alerts', durationLabel: '0.25s', recipe: { notes: seq([1240], 0, 0.1, 'triangle') } },
  { id: 'countdown_end_gong', nameAr: 'نهاية المؤقت (جرس)', nameEn: 'Countdown End Gong', category: 'countdown_alerts', durationLabel: '1.8s', recipe: { notes: [{ freq: 220, startSec: 0, durSec: 1.3, wave: 'sine', fmRatio: 2.4, fmDepth: 190 }, { freq: 440, startSec: 0, durSec: 1.1, wave: 'triangle' }], useReverb: true } },
  { id: 'alert_soft_aurora', nameAr: 'تنبيه أورورا هادئ', nameEn: 'Soft Aurora Notice', category: 'countdown_alerts', durationLabel: '0.8s', recipe: { notes: seq([587, 880], 0.14, 0.32, 'sine'), useReverb: true } },
  { id: 'alert_urgent_pulse', nameAr: 'تنبيه عاجل قوي', nameEn: 'Urgent Alert Pulse', category: 'countdown_alerts', durationLabel: '0.9s', recipe: { notes: seq([740, 540, 740, 987], 0.12, 0.18, 'square') } },
  { id: 'alert_glass_doorbell', nameAr: 'جرس الاستوديو', nameEn: 'Studio Doorbell', category: 'countdown_alerts', durationLabel: '0.9s', recipe: { notes: seq([659, 523], 0.24, 0.45, 'sine', 2, 70), useReverb: true } },

  // --- RINGTONE MELODIES (2-6s: Arabic Maqam-Inspired & Modern) ---
  { id: 'ring_hijaz_aurora', nameAr: 'رنة مقام حجاز كريستالية', nameEn: 'Hijaz Maqam Crystal Ringtone', category: 'ringtones', durationLabel: '3.6s', recipe: { notes: seq([293.6, 311.1, 370.0, 392.0, 440.0, 466.2, 554.4, 587.3, 554.4, 466.2, 440.0, 392.0, 370.0, 311.1, 293.6], 0.21, 0.34, 'triangle', 2, 55), useReverb: true, useDelay: true } },
  { id: 'ring_andalusi_night', nameAr: 'رنة أندلسية جزائرية', nameEn: 'Andalusi Night Melody', category: 'ringtones', durationLabel: '4.2s', recipe: { notes: seq([329.6, 349.2, 415.3, 440.0, 493.9, 523.3, 493.9, 440.0, 415.3, 349.2, 329.6, 440.0, 523.3, 659.3], 0.26, 0.4, 'sine', 2, 85), useReverb: true, useDelay: true } },
  { id: 'ring_sahara_breeze', nameAr: 'رنة نسيم الصحراء', nameEn: 'Sahara Breeze Ringtone', category: 'ringtones', durationLabel: '3.4s', recipe: { notes: seq([293.6, 349.2, 392.0, 440.0, 523.3, 440.0, 392.0, 349.2, 293.6, 440.0, 587.3], 0.26, 0.42, 'triangle', 1.5, 45), useReverb: true } },
  { id: 'ring_ice_palace', nameAr: 'رنة قصر الجليد الحديثة', nameEn: 'Ice Palace Modern Ringtone', category: 'ringtones', durationLabel: '3.2s', recipe: { notes: seq([523.3, 659.3, 784.0, 1046.5, 784.0, 659.3, 587.3, 784.0, 987.8, 1174.7], 0.24, 0.36, 'sine', 3, 110), useReverb: true, useDelay: true } },
  { id: 'ring_nebula_dream', nameAr: 'رنة حلم السديم', nameEn: 'Nebula Dream Melody', category: 'ringtones', durationLabel: '3.8s', recipe: { notes: seq([392.0, 493.9, 587.3, 784.0, 659.3, 587.3, 493.9, 587.3, 784.0, 987.8, 784.0], 0.28, 0.45, 'sine', 2, 65), useReverb: true, useDelay: true } },
  { id: 'ring_electro_pulse', nameAr: 'رنة إلكترونية حماسية', nameEn: 'Electro Pulse Ringtone', category: 'ringtones', durationLabel: '2.8s', recipe: { notes: seq([440, 440, 523, 659, 587, 523, 440, 659, 784, 880], 0.22, 0.24, 'sawtooth'), useDelay: true, noiseBurstAt: [0, 0.44, 0.88, 1.32, 1.76] } },

  // --- FUN STINGERS ---
  { id: 'stinger_hype_horn', nameAr: 'بوق الحماس', nameEn: 'Hype Airhorn', category: 'stingers', durationLabel: '0.7s', recipe: { notes: [{ freq: 340, startSec: 0, durSec: 0.52, wave: 'sawtooth' }, { freq: 425, startSec: 0.02, durSec: 0.5, wave: 'sawtooth' }] } },
  { id: 'stinger_laser_zap', nameAr: 'شعاع ليزر', nameEn: 'Aurora Laser Zap', category: 'stingers', durationLabel: '0.4s', recipe: { notes: seq([1300, 920, 610, 320], 0.06, 0.09, 'sawtooth') } },
  { id: 'stinger_comedy_boing', nameAr: 'قفزة مرحة', nameEn: 'Playful Boing', category: 'stingers', durationLabel: '0.5s', recipe: { notes: seq([240, 360, 520, 410], 0.08, 0.14, 'sine', 2, 140) } },
  { id: 'stinger_drum_ba_dum', nameAr: 'طبلة الكوميديا', nameEn: 'Rimshot Stinger', category: 'stingers', durationLabel: '0.8s', recipe: { notes: seq([160, 120, 220], 0.16, 0.16, 'triangle'), noiseBurstAt: [0.46] } },
  { id: 'stinger_power_up', nameAr: 'شحن الطاقة', nameEn: 'Power Charge Up', category: 'stingers', durationLabel: '0.9s', recipe: { notes: seq([261, 329, 392, 523, 659, 784, 1046], 0.08, 0.16, 'triangle', 2, 90) } },
  { id: 'stinger_applause_spark', nameAr: 'تصفيق الكريستال', nameEn: 'Crystal Sparkle Cheer', category: 'stingers', durationLabel: '1.1s', recipe: { notes: seq([784, 987, 1175, 1568], 0.12, 0.25, 'sine', 2.5, 100), noiseBurstAt: [0.05, 0.18, 0.31, 0.44, 0.58], useReverb: true } },
];

export const DEFAULT_SOUND_RULES: EventSoundRule[] = [
  { id: 'r_gift_small', trigger: 'gift_small', minCoins: 1, soundIds: ['gift_crystal_drop', 'gift_rose_chime'], volume: 0.75, trimStartSec: 0, trimEndSec: 0, fadeInSec: 0.01, fadeOutSec: 0.03, cooldownSec: 1, enabled: true },
  { id: 'r_gift_medium', trigger: 'gift_medium', minCoins: 100, soundIds: ['gift_aurora_arp', 'gift_prism_chord'], volume: 0.85, trimStartSec: 0, trimEndSec: 0, fadeInSec: 0.01, fadeOutSec: 0.04, cooldownSec: 1, enabled: true },
  { id: 'r_gift_big', trigger: 'gift_big', minCoins: 500, soundIds: ['gift_sapphire_fanfare', 'ring_hijaz_aurora'], volume: 0.92, trimStartSec: 0, trimEndSec: 0, fadeInSec: 0.01, fadeOutSec: 0.05, cooldownSec: 1, enabled: true },
  { id: 'r_gift_legendary', trigger: 'gift_legendary', minCoins: 1000, soundIds: ['gift_nova_supernova', 'gift_sahara_lion'], volume: 1.0, trimStartSec: 0, trimEndSec: 0, fadeInSec: 0.01, fadeOutSec: 0.06, cooldownSec: 1, enabled: true },
  { id: 'r_follow', trigger: 'follow', soundIds: ['follow_ice_bloom'], volume: 0.75, trimStartSec: 0, trimEndSec: 0, fadeInSec: 0.01, fadeOutSec: 0.03, cooldownSec: 2, enabled: true },
  { id: 'r_share', trigger: 'share', soundIds: ['share_aurora_whoosh'], volume: 0.75, trimStartSec: 0, trimEndSec: 0, fadeInSec: 0.01, fadeOutSec: 0.03, cooldownSec: 2, enabled: true },
  { id: 'r_like', trigger: 'like_milestone', soundIds: ['like_milestone_1k'], volume: 0.7, trimStartSec: 0, trimEndSec: 0, fadeInSec: 0.01, fadeOutSec: 0.03, cooldownSec: 3, enabled: true },
  { id: 'r_wilaya', trigger: 'wilaya_victory', soundIds: ['wilaya_victory_anthem'], volume: 0.9, trimStartSec: 0, trimEndSec: 0, fadeInSec: 0.01, fadeOutSec: 0.04, cooldownSec: 3, enabled: true },
  { id: 'r_countdown', trigger: 'countdown_end', soundIds: ['countdown_end_gong'], volume: 0.9, trimStartSec: 0, trimEndSec: 0, fadeInSec: 0.01, fadeOutSec: 0.05, cooldownSec: 2, enabled: true },
];

export function loadSoundConfig(): SoundConfigState {
  if (typeof window === 'undefined') {
    return { favorites: ['ring_hijaz_aurora', 'gift_aurora_arp'], rules: DEFAULT_SOUND_RULES };
  }
  try {
    const raw = window.localStorage.getItem(SOUND_CONFIG_STORAGE_KEY);
    if (!raw) return { favorites: ['ring_hijaz_aurora', 'gift_aurora_arp'], rules: DEFAULT_SOUND_RULES };
    const parsed = JSON.parse(raw) as Partial<SoundConfigState>;
    return {
      favorites: parsed.favorites ?? [],
      rules: parsed.rules && parsed.rules.length > 0 ? parsed.rules : DEFAULT_SOUND_RULES,
    };
  } catch {
    return { favorites: [], rules: DEFAULT_SOUND_RULES };
  }
}

export function saveSoundConfig(cfg: SoundConfigState): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(SOUND_CONFIG_STORAGE_KEY, JSON.stringify(cfg));
  } catch {
    // Ignore storage quota
  }
}

/**
 * Resolve the best sound rule for an incoming event (named gift > coin tier > generic trigger).
 */
export function resolveSoundRuleForEvent(
  rules: EventSoundRule[],
  event: { type: string; coins?: number; giftName?: string; message?: string },
): EventSoundRule | null {
  const active = rules.filter((r) => r.enabled && r.soundIds.length > 0);

  if (event.type === 'gift') {
    if (event.giftName) {
      const named = active.find(
        (r) =>
          r.trigger === 'gift_named' &&
          r.matchValue &&
          r.matchValue.toLowerCase() === event.giftName?.toLowerCase(),
      );
      if (named) return named;
    }
    const coins = event.coins ?? 1;
    const tierOrder: SoundEventTrigger[] = ['gift_legendary', 'gift_big', 'gift_medium', 'gift_small'];
    const tierThresholds: Record<string, number> = {
      gift_legendary: 1000,
      gift_big: 500,
      gift_medium: 100,
      gift_small: 1,
    };
    for (const tier of tierOrder) {
      const rule = active.find((r) => r.trigger === tier);
      if (rule && coins >= (rule.minCoins ?? tierThresholds[tier])) {
        return rule;
      }
    }
    return null;
  }

  if (event.type === 'chat' && event.message) {
    const lower = event.message.toLowerCase();
    return (
      active.find(
        (r) => r.trigger === 'chat_keyword' && r.matchValue && lower.includes(r.matchValue.toLowerCase()),
      ) ?? null
    );
  }

  const map: Record<string, SoundEventTrigger> = {
    follow: 'follow',
    share: 'share',
    like: 'like_milestone',
    wilaya_boost: 'wilaya_victory',
  };
  const trig = map[event.type];
  if (!trig) return null;
  return active.find((r) => r.trigger === trig) ?? null;
}

export async function playSoundById(
  soundId: string,
  options?: {
    volume?: number;
    trimStartSec?: number;
    trimEndSec?: number;
    fadeInSec?: number;
    fadeOutSec?: number;
  },
): Promise<void> {
  const builtIn = BUILT_IN_SOUNDS.find((s) => s.id === soundId);
  if (builtIn) {
    await sharedAudioEngine.playRecipe(builtIn.recipe, options?.volume ?? 0.78);
    return;
  }
  const custom = await getCustomSound(soundId);
  if (custom) {
    await sharedAudioEngine.playArrayBuffer(custom.data.slice(0), {
      volume: options?.volume ?? 0.85,
      trimStartSec: options?.trimStartSec,
      trimEndSec: options?.trimEndSec,
      fadeInSec: options?.fadeInSec,
      fadeOutSec: options?.fadeOutSec,
      isSfx: true,
    });
  }
}
