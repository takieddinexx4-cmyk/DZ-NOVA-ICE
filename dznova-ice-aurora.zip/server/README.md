# DZNOVA Serverless Relay & Cloud Neural TTS Proxy (`/server`)

Deploy this lightweight Cloudflare Worker to enable:
1. **Cross-process Overlay Relay** so OBS Studio & TikTok LIVE Studio receive live alerts, sound triggers, and voice settings from a separate browser or Android phone.
2. **Secure Cloud Neural Arabic TTS** (Azure Speech `ar-DZ-AminaNeural` / `ar-DZ-IsmaelNeural`, Google Cloud TTS, or ElevenLabs) with API keys stored strictly in Worker secrets — never in frontend code.

## Deploy in 3 Commands
```bash
cd server
npx wrangler secret put TTS_PROVIDER        # e.g. azure
npx wrangler secret put AZURE_SPEECH_KEY    # your Azure Speech key
npx wrangler secret put AZURE_SPEECH_REGION # e.g. westeurope
npx wrangler deploy
```
Then paste the deployed Worker URL (e.g. `https://dznova-ice-aurora-relay.<you>.workers.dev`) into **DZNOVA → Settings / TTS / Streaming Platforms**.
