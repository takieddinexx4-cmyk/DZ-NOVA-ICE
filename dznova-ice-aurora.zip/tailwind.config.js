/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        ice: {
          white: '#F3FAFF',
          crystal: '#A9E5FF',
          glacier: '#58DDF5',
          aurora: '#408DFF',
          nebula: '#9477FF',
          silver: '#D8E7F2',
          midnight: '#091526',
          deep: '#101D35',
        },
      },
      fontFamily: {
        arabic: ['Cairo', 'Tajawal', 'system-ui', 'sans-serif'],
        latin: ['Plus Jakarta Sans', 'Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'monospace'],
      },
      boxShadow: {
        'ice-glass': '0 12px 40px -8px rgba(9, 21, 38, 0.55), inset 0 1px 0 rgba(243, 250, 255, 0.25)',
        'ice-glow': '0 0 28px rgba(88, 221, 245, 0.28), 0 0 56px rgba(148, 119, 255, 0.16)',
      },
    },
  },
  plugins: [],
};
