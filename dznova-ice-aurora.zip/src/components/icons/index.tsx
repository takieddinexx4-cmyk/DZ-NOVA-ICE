import React from 'react';
import { IconShell, type DzIconProps } from './IconBase';

export const StreamingPlatformsIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="sp" from="#408DFF" via="#58DDF5" to="#9477FF" {...props}>
    <rect x="10" y="13" width="13" height="10" rx="3" fill="#F3FAFF" fillOpacity="0.92"/><rect x="25" y="25" width="13" height="10" rx="3" fill="#A9E5FF" fillOpacity="0.9"/><path d="M23 18H29V25M25 30H19V23" stroke="#F3FAFF" strokeWidth="2.2" strokeLinecap="round"/>
  </IconShell>
);

export const TikTokLiveStudioIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="ttls" from="#091526" via="#58DDF5" to="#9477FF" {...props}>
    <path d="M27 12V28.5C27 32 24.2 35 20.5 35C16.8 35 14 32 14 28.5C14 25 16.8 22.5 20.5 22.5H21.5" stroke="#F3FAFF" strokeWidth="3.2" strokeLinecap="round"/><path d="M27 14C29 17.5 32 19.5 35.5 20" stroke="#58DDF5" strokeWidth="3.2" strokeLinecap="round"/><circle cx="34" cy="31" r="4" fill="#9477FF" stroke="#F3FAFF" strokeWidth="1.6"/>
  </IconShell>
);

export const ObsStudioIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="obs" from="#101D35" via="#408DFF" to="#58DDF5" {...props}>
    <circle cx="24" cy="24" r="12.5" stroke="#F3FAFF" strokeWidth="2.2" fill="#091526" fillOpacity="0.35"/><circle cx="24" cy="17.5" r="4" fill="#58DDF5"/><circle cx="18.2" cy="27.5" r="4" fill="#F3FAFF"/><circle cx="29.8" cy="27.5" r="4" fill="#A9E5FF"/>
  </IconShell>
);

export const OverlayLibraryIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="ovl" from="#58DDF5" via="#408DFF" to="#6E56CF" {...props}>
    <rect x="11" y="12" width="18" height="13" rx="3" fill="#F3FAFF" fillOpacity="0.92"/><rect x="19" y="21" width="18" height="14" rx="3" fill="#A9E5FF" fillOpacity="0.65" stroke="#F3FAFF" strokeWidth="1.5"/>
  </IconShell>
);

export const SceneEditorIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="scn" from="#408DFF" via="#9477FF" to="#58DDF5" {...props}>
    <rect x="10" y="12" width="28" height="24" rx="4" fill="#091526" fillOpacity="0.3" stroke="#F3FAFF" strokeWidth="2"/><rect x="14" y="16" width="10" height="8" rx="2" fill="#58DDF5"/><rect x="26" y="16" width="8" height="16" rx="2" fill="#F3FAFF" fillOpacity="0.88"/><rect x="14" y="26" width="10" height="6" rx="2" fill="#A9E5FF"/>
  </IconShell>
);

export const ChatIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="cht" from="#58DDF5" via="#408DFF" to="#3B82F6" {...props}>
    <path d="M11 16C11 13.2 13.2 11 16 11H32C34.8 11 37 13.2 37 16V27C37 29.8 34.8 32 32 32H21L13 37V32H16C13.2 32 11 29.8 11 27V16Z" fill="#F3FAFF" fillOpacity="0.92"/><circle cx="19" cy="21.5" r="2" fill="#408DFF"/><circle cx="24" cy="21.5" r="2" fill="#408DFF"/><circle cx="29" cy="21.5" r="2" fill="#408DFF"/>
  </IconShell>
);

export const GiftsIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="gft" from="#9477FF" via="#58DDF5" to="#408DFF" {...props}>
    <rect x="12" y="20" width="24" height="15" rx="3" fill="#F3FAFF" fillOpacity="0.92"/><rect x="10" y="16" width="28" height="6" rx="2" fill="#A9E5FF"/><path d="M24 16V35" stroke="#408DFF" strokeWidth="3"/><path d="M24 16C20 11 15 11.5 16 15C16.5 16.5 21 16 24 16ZM24 16C28 11 33 11.5 32 15C31.5 16.5 27 16 24 16Z" fill="#F3FAFF"/>
  </IconShell>
);

export const FollowersIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="flw" from="#408DFF" via="#58DDF5" to="#60A5FA" {...props}>
    <circle cx="21" cy="18" r="5.5" fill="#F3FAFF"/><path d="M11 35C11 29.5 15.5 26 21 26C26.5 26 31 29.5 31 35" fill="#F3FAFF" fillOpacity="0.9"/><path d="M33 18V26M29 22H37" stroke="#A9E5FF" strokeWidth="2.8" strokeLinecap="round"/>
  </IconShell>
);

export const AnalyticsIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="anl" from="#408DFF" via="#9477FF" to="#58DDF5" {...props}>
    <rect x="12" y="25" width="5" height="11" rx="2" fill="#A9E5FF"/><rect x="21.5" y="19" width="5" height="17" rx="2" fill="#F3FAFF"/><rect x="31" y="13" width="5" height="23" rx="2" fill="#58DDF5"/>
  </IconShell>
);

export const AudioIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="aud" from="#58DDF5" via="#408DFF" to="#9477FF" {...props}>
    <path d="M12 20H18L26 13V35L18 28H12V20Z" fill="#F3FAFF"/><path d="M30 18C32.5 20 32.5 28 30 30M34 14C38 18 38 30 34 34" stroke="#A9E5FF" strokeWidth="2.4" strokeLinecap="round"/>
  </IconShell>
);

export const TtsIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="tts" from="#9477FF" via="#408DFF" to="#58DDF5" {...props}>
    <rect x="11" y="13" width="18" height="14" rx="4" fill="#F3FAFF"/><path d="M16 19H24M16 23H21" stroke="#408DFF" strokeWidth="2" strokeLinecap="round"/><path d="M32 18V30M36 21V27M28 22V26" stroke="#A9E5FF" strokeWidth="2.5" strokeLinecap="round"/>
  </IconShell>
);

export const AutomationIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="aut" from="#58DDF5" via="#9477FF" to="#408DFF" {...props}>
    <path d="M26 10L14 26H24L22 38L34 22H24L26 10Z" fill="#F3FAFF"/>
  </IconShell>
);

export const WilayaBattleIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="wlb" from="#10B981" via="#58DDF5" to="#408DFF" {...props}>
    <path d="M24 10L36 16V26C36 32.5 30.8 36.8 24 39C17.2 36.8 12 32.5 12 26V16L24 10Z" fill="#F3FAFF" fillOpacity="0.9"/><path d="M24 17L26 22H31L27 25L28.5 30L24 27L19.5 30L21 25L17 22H22L24 17Z" fill="#091526"/>
  </IconShell>
);

export const GoalsIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="gls" from="#408DFF" via="#58DDF5" to="#38BDF8" {...props}>
    <circle cx="24" cy="24" r="13" stroke="#F3FAFF" strokeWidth="2.5"/><circle cx="24" cy="24" r="8" stroke="#A9E5FF" strokeWidth="2.5"/><circle cx="24" cy="24" r="3.5" fill="#F3FAFF"/>
  </IconShell>
);

export const LeaderboardsIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="ldb" from="#9477FF" via="#408DFF" to="#58DDF5" {...props}>
    <rect x="10" y="24" width="8" height="12" rx="2" fill="#A9E5FF"/><rect x="20" y="16" width="8" height="20" rx="2" fill="#F3FAFF"/><rect x="30" y="21" width="8" height="15" rx="2" fill="#58DDF5"/><path d="M21 13L24 10L27 13" stroke="#F3FAFF" strokeWidth="2" strokeLinecap="round"/>
  </IconShell>
);

export const SettingsIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="set" from="#64748B" via="#408DFF" to="#101D35" {...props}>
    <circle cx="24" cy="24" r="6" stroke="#F3FAFF" strokeWidth="3"/><path d="M24 10V14M24 34V38M10 24H14M34 24H38M14 14L17 17M31 31L34 34M34 14L31 17M17 31L14 34" stroke="#A9E5FF" strokeWidth="2.8" strokeLinecap="round"/>
  </IconShell>
);

export const IntegrationsIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="int" from="#58DDF5" via="#408DFF" to="#9477FF" {...props}>
    <rect x="11" y="11" width="11" height="11" rx="3" fill="#F3FAFF"/><rect x="26" y="26" width="11" height="11" rx="3" fill="#F3FAFF"/><path d="M22 16.5H28C30 16.5 31.5 18 31.5 20V26M26 31.5H20C18 31.5 16.5 30 16.5 28V22" stroke="#A9E5FF" strokeWidth="2.4" strokeLinecap="round"/>
  </IconShell>
);

export const CloudSyncIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="cls" from="#A9E5FF" via="#58DDF5" to="#408DFF" {...props}>
    <path d="M16 32H33C36 32 38 29.8 38 27C38 24.4 36.1 22.3 33.6 22C33 17.5 29.2 14 24.5 14C20.3 14 16.8 16.9 15.8 20.8C12.5 21.3 10 24 10 27.2C10 30 12.6 32 16 32Z" fill="#F3FAFF" fillOpacity="0.92"/><path d="M21 25L24 22L27 25M24 22V29" stroke="#408DFF" strokeWidth="2.2" strokeLinecap="round"/>
  </IconShell>
);

export const NotificationsIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="ntf" from="#9477FF" via="#58DDF5" to="#408DFF" {...props}>
    <path d="M16 28V22C16 17.6 19.6 14 24 14C28.4 14 32 17.6 32 22V28L35 31H13L16 28Z" fill="#F3FAFF"/><circle cx="24" cy="34.5" r="2.5" fill="#A9E5FF"/>
  </IconShell>
);

export const SecurityIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="sec" from="#408DFF" via="#101D35" to="#58DDF5" {...props}>
    <rect x="14" y="22" width="20" height="14" rx="4" fill="#F3FAFF"/><path d="M18 22V17C18 13.7 20.7 11 24 11C27.3 11 30 13.7 30 17V22" stroke="#A9E5FF" strokeWidth="3" strokeLinecap="round"/><circle cx="24" cy="29" r="2.2" fill="#408DFF"/>
  </IconShell>
);

export const DashboardIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="dsh" from="#408DFF" via="#58DDF5" to="#9477FF" {...props}>
    <rect x="11" y="11" width="11" height="14" rx="3" fill="#F3FAFF"/><rect x="26" y="11" width="11" height="9" rx="3" fill="#A9E5FF"/><rect x="26" y="24" width="11" height="13" rx="3" fill="#F3FAFF"/><rect x="11" y="29" width="11" height="8" rx="3" fill="#A9E5FF"/>
  </IconShell>
);

export const LiveStreamIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="lvs" from="#EC4899" via="#9477FF" to="#408DFF" {...props}>
    <circle cx="24" cy="24" r="5" fill="#F3FAFF"/><path d="M16 17C12.8 20.8 12.8 27.2 16 31M32 17C35.2 20.8 35.2 27.2 32 31" stroke="#A9E5FF" strokeWidth="2.6" strokeLinecap="round"/>
  </IconShell>
);

export const AlertsIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="alr" from="#F59E0B" via="#9477FF" to="#408DFF" {...props}>
    <path d="M24 11L37 34H11L24 11Z" fill="#F3FAFF" fillOpacity="0.92"/><path d="M24 19V26" stroke="#091526" strokeWidth="2.8" strokeLinecap="round"/><circle cx="24" cy="30.2" r="1.6" fill="#091526"/>
  </IconShell>
);

export const PollsIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="pol" from="#58DDF5" via="#408DFF" to="#9477FF" {...props}>
    <rect x="11" y="13" width="26" height="5" rx="2.5" fill="#F3FAFF"/><rect x="11" y="21.5" width="18" height="5" rx="2.5" fill="#A9E5FF"/><rect x="11" y="30" width="22" height="5" rx="2.5" fill="#F3FAFF" fillOpacity="0.8"/>
  </IconShell>
);

export const QuizIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="quz" from="#9477FF" via="#408DFF" to="#58DDF5" {...props}>
    <path d="M19 18C19 15 21.2 13 24.2 13C27.2 13 29.2 14.8 29.2 17.5C29.2 20.5 25 21.5 24 24.5V26" stroke="#F3FAFF" strokeWidth="3.2" strokeLinecap="round"/><circle cx="24" cy="32.5" r="2.3" fill="#A9E5FF"/>
  </IconShell>
);

export const GiveawayIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="gvy" from="#58DDF5" via="#9477FF" to="#EC4899" {...props}>
    <path d="M24 11L27.5 19.5L37 20.5L29.8 26.5L32 36L24 31L16 36L18.2 26.5L11 20.5L20.5 19.5L24 11Z" fill="#F3FAFF"/>
  </IconShell>
);

export const WheelIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="whl" from="#408DFF" via="#9477FF" to="#58DDF5" {...props}>
    <circle cx="24" cy="24" r="13" fill="#F3FAFF" fillOpacity="0.2" stroke="#F3FAFF" strokeWidth="2.5"/><path d="M24 11V37M11 24H37M15 15L33 33M33 15L15 33" stroke="#A9E5FF" strokeWidth="1.8"/><circle cx="24" cy="24" r="3.5" fill="#F3FAFF"/>
  </IconShell>
);

export const CountdownIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="cnt" from="#58DDF5" via="#408DFF" to="#101D35" {...props}>
    <circle cx="24" cy="26" r="11" stroke="#F3FAFF" strokeWidth="2.8"/><path d="M20 11H28M24 26V20M24 26L28.5 28.5" stroke="#A9E5FF" strokeWidth="2.6" strokeLinecap="round"/>
  </IconShell>
);

export const ChatbotIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="bot" from="#408DFF" via="#58DDF5" to="#9477FF" {...props}>
    <rect x="12" y="16" width="24" height="18" rx="6" fill="#F3FAFF"/><path d="M24 11V16" stroke="#A9E5FF" strokeWidth="2.8" strokeLinecap="round"/><circle cx="19.5" cy="24.5" r="2.2" fill="#408DFF"/><circle cx="28.5" cy="24.5" r="2.2" fill="#408DFF"/><path d="M19.5 30H28.5" stroke="#408DFF" strokeWidth="2" strokeLinecap="round"/>
  </IconShell>
);

export const ProfileIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="prf" from="#9477FF" via="#408DFF" to="#58DDF5" {...props}>
    <circle cx="24" cy="18" r="6" fill="#F3FAFF"/><path d="M13 36C13 30 17.8 26.5 24 26.5C30.2 26.5 35 30 35 36" fill="#A9E5FF"/>
  </IconShell>
);

export const StorageIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="stg" from="#408DFF" via="#64748B" to="#58DDF5" {...props}>
    <ellipse cx="24" cy="15" rx="12" ry="4.5" fill="#F3FAFF"/><path d="M12 15V33C12 35.5 17.4 37.5 24 37.5C30.6 37.5 36 35.5 36 33V15" stroke="#A9E5FF" strokeWidth="2.5"/><path d="M12 24C12 26.5 17.4 28.5 24 28.5C30.6 28.5 36 26.5 36 24" stroke="#A9E5FF" strokeWidth="2"/>
  </IconShell>
);

export const PerformanceIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="perf" from="#58DDF5" via="#10B981" to="#408DFF" {...props}>
    <path d="M12 31C12 22.7 17.4 16 24 16C30.6 16 36 22.7 36 31" stroke="#F3FAFF" strokeWidth="3" strokeLinecap="round"/><path d="M24 30L31 21" stroke="#A9E5FF" strokeWidth="3" strokeLinecap="round"/><circle cx="24" cy="30" r="3" fill="#F3FAFF"/>
  </IconShell>
);

export const AppearanceIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="app" from="#9477FF" via="#58DDF5" to="#408DFF" {...props}>
    <circle cx="24" cy="24" r="12" fill="#F3FAFF" fillOpacity="0.9"/><circle cx="19" cy="20" r="2.2" fill="#408DFF"/><circle cx="25" cy="17.5" r="2.2" fill="#9477FF"/><circle cx="30" cy="22" r="2.2" fill="#58DDF5"/>
  </IconShell>
);

export const LanguageIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="lng" from="#408DFF" via="#58DDF5" to="#9477FF" {...props}>
    <circle cx="24" cy="24" r="12" stroke="#F3FAFF" strokeWidth="2.4"/><ellipse cx="24" cy="24" rx="5.5" ry="12" stroke="#A9E5FF" strokeWidth="2"/><path d="M12 24H36" stroke="#A9E5FF" strokeWidth="2"/>
  </IconShell>
);

export const SupportIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="sup" from="#58DDF5" via="#408DFF" to="#9477FF" {...props}>
    <circle cx="24" cy="24" r="12" stroke="#F3FAFF" strokeWidth="2.6"/><circle cx="24" cy="24" r="5" stroke="#A9E5FF" strokeWidth="2.4"/><path d="M15.5 15.5L20.5 20.5M27.5 27.5L32.5 32.5M32.5 15.5L27.5 20.5M20.5 27.5L15.5 32.5" stroke="#F3FAFF" strokeWidth="2.2"/>
  </IconShell>
);

export const GamingIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="gam" from="#9477FF" via="#408DFF" to="#58DDF5" {...props}>
    <rect x="10" y="18" width="28" height="14" rx="7" fill="#F3FAFF"/><path d="M17 22V28M14 25H20" stroke="#408DFF" strokeWidth="2.2" strokeLinecap="round"/><circle cx="30" cy="23.5" r="1.7" fill="#9477FF"/><circle cx="33" cy="26.5" r="1.7" fill="#408DFF"/>
  </IconShell>
);

export const MicrophoneIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="mic" from="#408DFF" via="#9477FF" to="#58DDF5" {...props}>
    <rect x="19" y="11" width="10" height="16" rx="5" fill="#F3FAFF"/><path d="M14 23C14 28.5 18.5 32.5 24 32.5C29.5 32.5 34 28.5 34 23M24 32.5V37M19 37H29" stroke="#A9E5FF" strokeWidth="2.5" strokeLinecap="round"/>
  </IconShell>
);

export const CameraIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="cam" from="#58DDF5" via="#408DFF" to="#101D35" {...props}>
    <rect x="10" y="16" width="28" height="19" rx="5" fill="#F3FAFF"/><circle cx="24" cy="25.5" r="5" fill="#408DFF"/><rect x="18" y="12" width="12" height="4" rx="2" fill="#A9E5FF"/>
  </IconShell>
);

export const MusicIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="mus" from="#9477FF" via="#58DDF5" to="#408DFF" {...props}>
    <path d="M20 32V15L34 12V29" stroke="#F3FAFF" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round"/><circle cx="17" cy="32" r="4" fill="#A9E5FF"/><circle cx="31" cy="29" r="4" fill="#F3FAFF"/>
  </IconShell>
);

export const StatisticsIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="sta" from="#408DFF" via="#58DDF5" to="#10B981" {...props}>
    <path d="M11 32L19 23L25 27L36 14" stroke="#F3FAFF" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/><circle cx="36" cy="14" r="3" fill="#A9E5FF"/>
  </IconShell>
);

export const LiveControlsIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="lvc" from="#58DDF5" via="#408DFF" to="#9477FF" {...props}>
    <path d="M14 14V34M24 14V34M34 14V34" stroke="#A9E5FF" strokeWidth="2.5" strokeLinecap="round"/><circle cx="14" cy="20" r="3.5" fill="#F3FAFF"/><circle cx="24" cy="29" r="3.5" fill="#F3FAFF"/><circle cx="34" cy="18" r="3.5" fill="#F3FAFF"/>
  </IconShell>
);

export const DesktopCompanionIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="dsk" from="#101D35" via="#408DFF" to="#9477FF" {...props}>
    <rect x="10" y="12" width="28" height="19" rx="3.5" fill="#F3FAFF" fillOpacity="0.92"/><path d="M19 36H29M24 31V36" stroke="#A9E5FF" strokeWidth="2.8" strokeLinecap="round"/><rect x="14" y="16" width="20" height="11" rx="2" fill="#408DFF" fillOpacity="0.45"/>
  </IconShell>
);

export const ExportIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="exp" from="#58DDF5" via="#408DFF" to="#9477FF" {...props}>
    <path d="M24 28V12M18 18L24 12L30 18" stroke="#F3FAFF" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round"/><path d="M12 28V33C12 34.7 13.3 36 15 36H33C34.7 36 36 34.7 36 33V28" stroke="#A9E5FF" strokeWidth="2.6" strokeLinecap="round"/>
  </IconShell>
);

export const ImportIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="imp" from="#408DFF" via="#58DDF5" to="#10B981" {...props}>
    <path d="M24 12V28M18 22L24 28L30 22" stroke="#F3FAFF" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round"/><path d="M12 28V33C12 34.7 13.3 36 15 36H33C34.7 36 36 34.7 36 33V28" stroke="#A9E5FF" strokeWidth="2.6" strokeLinecap="round"/>
  </IconShell>
);

export const SearchIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="src" from="#58DDF5" via="#408DFF" to="#9477FF" {...props}>
    <circle cx="22" cy="22" r="9" stroke="#F3FAFF" strokeWidth="3"/><path d="M29 29L36 36" stroke="#A9E5FF" strokeWidth="3.2" strokeLinecap="round"/>
  </IconShell>
);

export const HelpIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="hlp" from="#408DFF" via="#9477FF" to="#58DDF5" {...props}>
    <circle cx="24" cy="24" r="12" stroke="#F3FAFF" strokeWidth="2.4"/><path d="M20.5 19.5C20.5 17.5 22 16 24 16C26 16 27.5 17.4 27.5 19.2C27.5 21.5 24 22 24 25" stroke="#A9E5FF" strokeWidth="2.4" strokeLinecap="round"/><circle cx="24" cy="30" r="1.8" fill="#F3FAFF"/>
  </IconShell>
);

export const ThemeSelectorIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="thm" from="#9477FF" via="#408DFF" to="#58DDF5" {...props}>
    <circle cx="24" cy="24" r="11" stroke="#F3FAFF" strokeWidth="2.5"/><path d="M24 13A11 11 0 0 1 24 35Z" fill="#F3FAFF"/>
  </IconShell>
);

export const LightModeIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="lgt" from="#58DDF5" via="#A9E5FF" to="#408DFF" {...props}>
    <circle cx="24" cy="24" r="6" fill="#F3FAFF"/><path d="M24 10V14M24 34V38M10 24H14M34 24H38M14 14L17 17M31 31L34 34M34 14L31 17M17 31L14 34" stroke="#F3FAFF" strokeWidth="2.4" strokeLinecap="round"/>
  </IconShell>
);

export const DarkModeIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="drk" from="#091526" via="#408DFF" to="#9477FF" {...props}>
    <path d="M31 28.5A10.5 10.5 0 1 1 19.5 14A8.5 8.5 0 0 0 31 28.5Z" fill="#F3FAFF"/><circle cx="32" cy="16" r="2" fill="#A9E5FF"/>
  </IconShell>
);

export const AccountManagementIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="acc" from="#408DFF" via="#9477FF" to="#58DDF5" {...props}>
    <rect x="10" y="13" width="28" height="22" rx="4" fill="#F3FAFF" fillOpacity="0.92"/><circle cx="19" cy="23" r="3.5" fill="#408DFF"/><path d="M26 20H34M26 25H32" stroke="#408DFF" strokeWidth="2.2" strokeLinecap="round"/>
  </IconShell>
);

export const BillingIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="bil" from="#9477FF" via="#408DFF" to="#58DDF5" {...props}>
    <rect x="10" y="15" width="28" height="19" rx="4" fill="#F3FAFF"/><rect x="10" y="20" width="28" height="4" fill="#408DFF"/><rect x="14" y="28" width="9" height="3" rx="1.5" fill="#9477FF"/>
  </IconShell>
);

export const AdminPanelIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="adm" from="#101D35" via="#9477FF" to="#58DDF5" {...props}>
    <path d="M24 10L36 15V24C36 31 30.8 36 24 38.5C17.2 36 12 31 12 24V15L24 10Z" fill="#F3FAFF" fillOpacity="0.92"/><path d="M19 24L22.5 27.5L30 20" stroke="#408DFF" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round"/>
  </IconShell>
);

export const DiagnosticsIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="dgn" from="#58DDF5" via="#10B981" to="#408DFF" {...props}>
    <path d="M10 25H16L20 15L26 33L30 23H38" stroke="#F3FAFF" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
  </IconShell>
);

export const SetupWizardIcon: React.FC<DzIconProps> = (props) => (
  <IconShell id="wiz" from="#9477FF" via="#58DDF5" to="#408DFF" {...props}>
    <path d="M13 35L31 17" stroke="#F3FAFF" strokeWidth="3.2" strokeLinecap="round"/><path d="M31 11L32.5 14.5L36 16L32.5 17.5L31 21L29.5 17.5L26 16L29.5 14.5Z" fill="#A9E5FF"/><circle cx="20" cy="16" r="2" fill="#F3FAFF"/>
  </IconShell>
);

export const ICON_REGISTRY = [
  { id: 'sp', name: 'StreamingPlatforms', Component: StreamingPlatformsIcon },
  { id: 'ttls', name: 'TikTokLiveStudio', Component: TikTokLiveStudioIcon },
  { id: 'obs', name: 'ObsStudio', Component: ObsStudioIcon },
  { id: 'ovl', name: 'OverlayLibrary', Component: OverlayLibraryIcon },
  { id: 'scn', name: 'SceneEditor', Component: SceneEditorIcon },
  { id: 'cht', name: 'Chat', Component: ChatIcon },
  { id: 'gft', name: 'Gifts', Component: GiftsIcon },
  { id: 'flw', name: 'Followers', Component: FollowersIcon },
  { id: 'anl', name: 'Analytics', Component: AnalyticsIcon },
  { id: 'aud', name: 'Audio', Component: AudioIcon },
  { id: 'tts', name: 'Tts', Component: TtsIcon },
  { id: 'aut', name: 'Automation', Component: AutomationIcon },
  { id: 'wlb', name: 'WilayaBattle', Component: WilayaBattleIcon },
  { id: 'gls', name: 'Goals', Component: GoalsIcon },
  { id: 'ldb', name: 'Leaderboards', Component: LeaderboardsIcon },
  { id: 'set', name: 'Settings', Component: SettingsIcon },
  { id: 'int', name: 'Integrations', Component: IntegrationsIcon },
  { id: 'cls', name: 'CloudSync', Component: CloudSyncIcon },
  { id: 'ntf', name: 'Notifications', Component: NotificationsIcon },
  { id: 'sec', name: 'Security', Component: SecurityIcon },
  { id: 'dsh', name: 'Dashboard', Component: DashboardIcon },
  { id: 'lvs', name: 'LiveStream', Component: LiveStreamIcon },
  { id: 'alr', name: 'Alerts', Component: AlertsIcon },
  { id: 'pol', name: 'Polls', Component: PollsIcon },
  { id: 'quz', name: 'Quiz', Component: QuizIcon },
  { id: 'gvy', name: 'Giveaway', Component: GiveawayIcon },
  { id: 'whl', name: 'Wheel', Component: WheelIcon },
  { id: 'cnt', name: 'Countdown', Component: CountdownIcon },
  { id: 'bot', name: 'Chatbot', Component: ChatbotIcon },
  { id: 'prf', name: 'Profile', Component: ProfileIcon },
  { id: 'stg', name: 'Storage', Component: StorageIcon },
  { id: 'perf', name: 'Performance', Component: PerformanceIcon },
  { id: 'app', name: 'Appearance', Component: AppearanceIcon },
  { id: 'lng', name: 'Language', Component: LanguageIcon },
  { id: 'sup', name: 'Support', Component: SupportIcon },
  { id: 'gam', name: 'Gaming', Component: GamingIcon },
  { id: 'mic', name: 'Microphone', Component: MicrophoneIcon },
  { id: 'cam', name: 'Camera', Component: CameraIcon },
  { id: 'mus', name: 'Music', Component: MusicIcon },
  { id: 'sta', name: 'Statistics', Component: StatisticsIcon },
  { id: 'lvc', name: 'LiveControls', Component: LiveControlsIcon },
  { id: 'dsk', name: 'DesktopCompanion', Component: DesktopCompanionIcon },
  { id: 'exp', name: 'Export', Component: ExportIcon },
  { id: 'imp', name: 'Import', Component: ImportIcon },
  { id: 'src', name: 'Search', Component: SearchIcon },
  { id: 'hlp', name: 'Help', Component: HelpIcon },
  { id: 'thm', name: 'ThemeSelector', Component: ThemeSelectorIcon },
  { id: 'lgt', name: 'LightMode', Component: LightModeIcon },
  { id: 'drk', name: 'DarkMode', Component: DarkModeIcon },
  { id: 'acc', name: 'AccountManagement', Component: AccountManagementIcon },
  { id: 'bil', name: 'Billing', Component: BillingIcon },
  { id: 'adm', name: 'AdminPanel', Component: AdminPanelIcon },
  { id: 'dgn', name: 'Diagnostics', Component: DiagnosticsIcon },
  { id: 'wiz', name: 'SetupWizard', Component: SetupWizardIcon },
] as const;
