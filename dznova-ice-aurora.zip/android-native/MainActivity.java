package live.dznova.iceaurora;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends BridgeActivity implements TextToSpeech.OnInitListener {
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Keep audio queue active while controlling a live stream
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        tts = new TextToSpeech(this, this);

        WebView webView = getBridge().getWebView();
        if (webView != null) {
            webView.addJavascriptInterface(new DznovaTtsBridge(), "DznovaAndroidTTS");
        }
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true;
            tts.setLanguage(new Locale("ar", "DZ"));
        }
    }

    @Override
    public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    private class DznovaTtsBridge {
        @JavascriptInterface
        public String listVoices() {
            JSONArray arr = new JSONArray();
            if (!ttsReady || tts == null) return arr.toString();
            try {
                Set<Voice> voices = tts.getVoices();
                if (voices != null) {
                    for (Voice v : voices) {
                        JSONObject obj = new JSONObject();
                        obj.put("id", v.getName());
                        obj.put("name", v.getName());
                        obj.put("lang", v.getLocale().toLanguageTag());
                        arr.put(obj);
                    }
                }
            } catch (Exception ignored) {
            }
            return arr.toString();
        }

        @JavascriptInterface
        public void speak(String text, String lang, float rate, float pitch, String voiceId) {
            if (!ttsReady || tts == null || text == null || text.trim().isEmpty()) return;
            runOnUiThread(() -> {
                try {
                    tts.setSpeechRate(Math.max(0.5f, Math.min(2.0f, rate)));
                    tts.setPitch(Math.max(0.5f, Math.min(2.0f, pitch)));
                    if (voiceId != null && !voiceId.isEmpty() && tts.getVoices() != null) {
                        for (Voice v : tts.getVoices()) {
                            if (v.getName().equals(voiceId)) {
                                tts.setVoice(v);
                                break;
                            }
                        }
                    } else if (lang != null && !lang.isEmpty()) {
                        tts.setLanguage(Locale.forLanguageTag(lang));
                    }
                    tts.speak(text, TextToSpeech.QUEUE_ADD, null, "dznova_" + System.currentTimeMillis());
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void stop() {
            if (tts != null) {
                tts.stop();
            }
        }
    }
}
