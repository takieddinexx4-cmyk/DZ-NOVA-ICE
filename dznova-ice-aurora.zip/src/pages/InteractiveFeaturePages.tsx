import React, { useState } from 'react';
import { useDznova } from '../context/DznovaContext';
import { GlassBadge, GlassButton, GlassCard } from '../components/GlassUI';
import { DznovaLogo } from '../components/DznovaLogo';
import {
  type DesktopDiagnostics,
  isTauriDesktop,
  runDesktopDiagnostics,
  sendNativeNotification,
} from '../services/desktopCompanion';
import {
  AdminPanelIcon,
  AlertsIcon,
  AnalyticsIcon,
  AutomationIcon,
  BillingIcon,
  ChatbotIcon,
  ChatIcon,
  DesktopCompanionIcon,
  ICON_REGISTRY,
  SettingsIcon,
  SupportIcon,
  WilayaBattleIcon,
} from '../components/icons';
import { t } from '../i18n/translations';

export const AlertsPage: React.FC = () => {
  const { lang, alertConfig, setAlertConfig, triggerMockGift, triggerMockFollow } = useDznova();
  const isAr = lang === 'ar';
  return (
    <GlassCard className="space-y-5">
      <div className="flex items-center gap-3">
        <AlertsIcon size={38} />
        <h1 className="text-2xl font-extrabold">{t(lang, 'navAlerts')}</h1>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="flex items-center justify-between rounded-xl bg-ice-midnight/45 p-4 text-sm">
          <span>{isAr ? 'تفعيل التنبيهات' : 'Enable Alerts'}</span>
          <input type="checkbox" checked={alertConfig.enabled} onChange={(e) => setAlertConfig((p) => ({ ...p, enabled: e.target.checked }))} />
        </label>
        <label className="flex items-center justify-between rounded-xl bg-ice-midnight/45 p-4 text-sm">
          <span>{isAr ? 'تفعيل صوت الكريستال' : 'Enable Crystal Chime'}</span>
          <input type="checkbox" checked={alertConfig.soundEnabled} onChange={(e) => setAlertConfig((p) => ({ ...p, soundEnabled: e.target.checked }))} />
        </label>
      </div>
      <div className="flex flex-wrap gap-3">
        <GlassButton variant="primary" onClick={() => triggerMockGift('all')}>
          {isAr ? 'اختبار تنبيه هدية' : 'Test Gift Alert'}
        </GlassButton>
        <GlassButton onClick={() => triggerMockFollow('all')}>
          {isAr ? 'اختبار تنبيه متابعة' : 'Test Follow Alert'}
        </GlassButton>
      </div>
    </GlassCard>
  );
};

export const ChatPage: React.FC = () => {
  const { lang, events, triggerMockChat } = useDznova();
  const isAr = lang === 'ar';
  const [msg, setMsg] = useState('');
  return (
    <GlassCard className="space-y-4">
      <div className="flex items-center gap-3">
        <ChatIcon size={36} />
        <h1 className="text-2xl font-extrabold">{t(lang, 'navChat')}</h1>
      </div>
      <form
        className="flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          if (!msg.trim()) return;
          triggerMockChat(msg.trim(), 'all', 'Host');
          setMsg('');
        }}
      >
        <input
          value={msg}
          onChange={(e) => setMsg(e.target.value)}
          placeholder={isAr ? 'اكتب رسالة أو أمر مثل !wilaya...' : 'Send a message or !wilaya command...'}
          className="flex-1 rounded-xl border border-ice-crystal/25 bg-ice-midnight/60 px-4 py-2 text-sm text-ice-white"
        />
        <GlassButton type="submit" variant="primary">{isAr ? 'إرسال' : 'Send'}</GlassButton>
      </form>
      <div className="max-h-80 space-y-2 overflow-y-auto">
        {events.map((ev) => (
          <div key={ev.id} className="rounded-xl bg-ice-midnight/45 px-4 py-2.5 text-sm">
            <span className="font-bold text-ice-glacier">{ev.username}: </span>
            <span>{ev.message ?? ev.giftName ?? ev.type}</span>
          </div>
        ))}
      </div>
    </GlassCard>
  );
};

export const BotPage: React.FC = () => {
  const { lang, botCommands, setBotCommands, triggerMockChat } = useDznova();
  const isAr = lang === 'ar';
  const [trigger, setTrigger] = useState('!dz');
  const [response, setResponse] = useState('مرحباً بكم في بث DZNOVA!');
  return (
    <GlassCard className="space-y-4">
      <div className="flex items-center gap-3">
        <ChatbotIcon size={36} />
        <h1 className="text-2xl font-extrabold">{t(lang, 'navBot')}</h1>
      </div>
      <div className="grid gap-2 sm:grid-cols-3">
        <input value={trigger} onChange={(e) => setTrigger(e.target.value)} className="rounded-xl border border-ice-crystal/25 bg-ice-midnight/60 px-3 py-2 text-sm text-ice-white" />
        <input value={response} onChange={(e) => setResponse(e.target.value)} className="rounded-xl border border-ice-crystal/25 bg-ice-midnight/60 px-3 py-2 text-sm text-ice-white sm:col-span-2" />
      </div>
      <GlassButton
        variant="primary"
        onClick={() => {
          setBotCommands((prev) => [
            ...prev,
            { id: `cmd_${Date.now()}`, trigger, response, enabled: true, cooldownSec: 5 },
          ]);
        }}
      >
        {isAr ? 'إضافة أمر بوت' : 'Add Bot Command'}
      </GlassButton>
      <div className="space-y-2">
        {botCommands.map((cmd) => (
          <div key={cmd.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-ice-midnight/45 p-3 text-sm">
            <div>
              <span className="font-mono font-bold text-ice-glacier">{cmd.trigger}</span> — <span>{cmd.response}</span>
            </div>
            <div className="flex gap-2">
              <GlassButton size="sm" onClick={() => triggerMockChat(`[BOT] ${cmd.response}`, 'all', 'DZNOVA_Bot')}>
                {isAr ? 'اختبار' : 'Test'}
              </GlassButton>
              <GlassButton size="sm" variant="danger" onClick={() => setBotCommands((p) => p.filter((c) => c.id !== cmd.id))}>
                {isAr ? 'حذف' : 'Delete'}
              </GlassButton>
            </div>
          </div>
        ))}
      </div>
    </GlassCard>
  );
};

export const AutomationPage: React.FC = () => {
  const { lang, automationRules, setAutomationRules, triggerMockGift } = useDznova();
  const isAr = lang === 'ar';
  return (
    <GlassCard className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <AutomationIcon size={36} />
          <h1 className="text-2xl font-extrabold">{t(lang, 'navAutomation')}</h1>
        </div>
        <GlassButton variant="primary" onClick={() => triggerMockGift('all')}>
          {isAr ? 'اختبار القواعد' : 'Trigger Test Event'}
        </GlassButton>
      </div>
      <div className="space-y-3">
        {automationRules.map((rule) => (
          <div key={rule.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-ice-midnight/45 p-4 text-sm">
            <div>
              <p className="font-bold">{rule.name}</p>
              <p className="text-xs opacity-75">
                {rule.triggerType} ({rule.conditionValue}) → {rule.actionType}: {rule.actionPayload}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <GlassBadge tone="cyan">{rule.executions} runs</GlassBadge>
              <GlassButton
                size="sm"
                variant={rule.enabled ? 'primary' : 'secondary'}
                onClick={() =>
                  setAutomationRules((prev) =>
                    prev.map((r) => (r.id === rule.id ? { ...r, enabled: !r.enabled } : r)),
                  )
                }
              >
                {rule.enabled ? (isAr ? 'مُفعّل' : 'Active') : isAr ? 'متوقف' : 'Paused'}
              </GlassButton>
            </div>
          </div>
        ))}
      </div>
    </GlassCard>
  );
};

export const WilayaBattlePage: React.FC = () => {
  const { lang, wilayas, boostWilaya, resetWilayas } = useDznova();
  const isAr = lang === 'ar';
  return (
    <GlassCard className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <WilayaBattleIcon size={40} />
          <h1 className="text-2xl font-extrabold">{t(lang, 'navWilayaBattle')}</h1>
        </div>
        <GlassButton variant="danger" size="sm" onClick={resetWilayas}>
          {isAr ? 'تصفير الجولة' : 'Reset Round'}
        </GlassButton>
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        {wilayas.map((w, idx) => (
          <div key={w.code} className="flex items-center justify-between rounded-xl bg-ice-midnight/45 p-4">
            <div>
              <p className="font-bold">#{idx + 1} • {w.code} — {isAr ? w.nameAr : w.nameEn}</p>
              <p className="font-mono text-sm text-ice-glacier">{w.points} pts</p>
            </div>
            <GlassButton size="sm" variant="primary" onClick={() => boostWilaya(w.code, 100)}>
              +100
            </GlassButton>
          </div>
        ))}
      </div>
    </GlassCard>
  );
};

export const AnalyticsPage: React.FC = () => {
  const { lang, events, wilayas } = useDznova();
  const isAr = lang === 'ar';
  const totalCoins = events.reduce((sum, e) => sum + (e.coins ?? 0), 0);
  const bars = wilayas.slice(0, 6);
  const maxPts = Math.max(1, ...bars.map((b) => b.points));

  return (
    <GlassCard className="space-y-5">
      <div className="flex items-center gap-3">
        <AnalyticsIcon size={38} />
        <h1 className="text-2xl font-extrabold">{t(lang, 'navAnalytics')}</h1>
      </div>
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-xl bg-ice-midnight/45 p-4">
          <p className="text-xs opacity-70">{isAr ? 'إجمالي الأحداث' : 'Total Events'}</p>
          <p className="font-mono text-2xl font-extrabold text-ice-glacier">{events.length}</p>
        </div>
        <div className="rounded-xl bg-ice-midnight/45 p-4">
          <p className="text-xs opacity-70">{isAr ? 'إجمالي العملات' : 'Session Coins'}</p>
          <p className="font-mono text-2xl font-extrabold text-ice-nebula">{totalCoins}</p>
        </div>
        <div className="rounded-xl bg-ice-midnight/45 p-4">
          <p className="text-xs opacity-70">{isAr ? 'الولايات النشطة' : 'Active Wilayas'}</p>
          <p className="font-mono text-2xl font-extrabold text-emerald-300">{wilayas.length}</p>
        </div>
      </div>
      <div className="space-y-2">
        {bars.map((b) => (
          <div key={b.code} className="space-y-1">
            <div className="flex justify-between text-xs">
              <span>{isAr ? b.nameAr : b.nameEn}</span>
              <span className="font-mono">{b.points}</span>
            </div>
            <div className="h-3 w-full overflow-hidden rounded-full bg-ice-midnight/70">
              <div
                className="h-full rounded-full bg-gradient-to-r from-ice-glacier to-ice-nebula"
                style={{ width: `${(b.points / maxPts) * 100}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </GlassCard>
  );
};

export const BillingPage: React.FC = () => {
  const { lang, session, pushToast } = useDznova();
  const isAr = lang === 'ar';
  const plans = [
    { name: 'Starter', price: '0 DZD / $0', desc: isAr ? 'أوفرلاي أساسية لـ OBS و TikTok LIVE Studio' : 'Core overlays for OBS & TikTok LIVE Studio' },
    { name: 'Aurora Pro', price: '1,900 DZD / $9', desc: isAr ? 'جميع الأوفرلاي + TTS + تحدي الولايات + الأتمتة' : 'All overlays + TTS + Wilaya Battle + Automation' },
    { name: 'Studio Elite', price: '4,500 DZD / $19', desc: isAr ? 'حسابات متعددة + مزامنة سحابية + أولوية دعم' : 'Multi-channel + Cloud Sync + Priority Support' },
  ];
  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <BillingIcon size={38} />
        <h1 className="text-2xl font-extrabold">{t(lang, 'navBilling')}</h1>
      </div>
      <div className="grid gap-5 md:grid-cols-3">
        {plans.map((p) => (
          <GlassCard key={p.name} interactive className="flex flex-col justify-between gap-4">
            <div>
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-extrabold">{p.name}</h3>
                {session.plan === p.name && <GlassBadge tone="emerald">{isAr ? 'خطتك الحالية' : 'Current'}</GlassBadge>}
              </div>
              <p className="mt-2 font-mono text-2xl font-extrabold text-ice-glacier">{p.price}</p>
              <p className="mt-2 text-xs opacity-80">{p.desc}</p>
            </div>
            <GlassButton
              variant={session.plan === p.name ? 'secondary' : 'primary'}
              onClick={() => pushToast(isAr ? `تم اختيار خطة ${p.name}` : `Selected ${p.name}`, undefined, 'cyan')}
            >
              {session.plan === p.name ? (isAr ? 'مُفعّلة' : 'Active') : isAr ? 'اختيار الخطة' : 'Select Plan'}
            </GlassButton>
          </GlassCard>
        ))}
      </div>
    </div>
  );
};

export const SettingsPage: React.FC = () => {
  const { lang, setLang, theme, setTheme, lowEffects, setLowEffects, pushToast } = useDznova();
  const isAr = lang === 'ar';
  const [diag, setDiag] = useState<DesktopDiagnostics | null>(null);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <SettingsIcon size={38} />
        <h1 className="text-2xl font-extrabold">{t(lang, 'navSettings')}</h1>
      </div>
      <div className="grid gap-5 md:grid-cols-2">
        <GlassCard className="space-y-4">
          <h2 className="text-lg font-bold">{isAr ? 'المظهر واللغة والأداء' : 'Appearance, Language & Performance'}</h2>
          <div className="flex flex-wrap gap-2">
            {(['ar', 'en', 'fr'] as const).map((l) => (
              <GlassButton key={l} size="sm" variant={lang === l ? 'primary' : 'secondary'} onClick={() => setLang(l)}>
                {l.toUpperCase()}
              </GlassButton>
            ))}
          </div>
          <div className="flex flex-wrap gap-2">
            <GlassButton size="sm" variant={theme === 'dark' ? 'primary' : 'secondary'} onClick={() => setTheme('dark')}>
              {t(lang, 'themeDark')}
            </GlassButton>
            <GlassButton size="sm" variant={theme === 'light' ? 'primary' : 'secondary'} onClick={() => setTheme('light')}>
              {t(lang, 'themeLight')}
            </GlassButton>
          </div>
          <label className="flex items-center justify-between rounded-xl bg-ice-midnight/45 p-3 text-sm">
            <span>{t(lang, 'lowEffects')}</span>
            <input type="checkbox" checked={lowEffects} onChange={(e) => setLowEffects(e.target.checked)} />
          </label>
        </GlassCard>

        <GlassCard className="space-y-4">
          <div className="flex items-center gap-2">
            <DesktopCompanionIcon size={28} />
            <h2 className="text-lg font-bold">{isAr ? 'تطبيق سطح المكتب (Tauri Windows)' : 'Tauri Desktop Companion'}</h2>
          </div>
          <GlassBadge tone={isTauriDesktop() ? 'emerald' : 'cyan'}>
            {isTauriDesktop() ? 'Running inside Tauri Desktop' : 'Web Platform Mode (Standalone Ready)'}
          </GlassBadge>
          <div className="flex flex-wrap gap-2">
            <GlassButton
              size="sm"
              variant="primary"
              onClick={async () => {
                const res = await runDesktopDiagnostics();
                setDiag(res);
                pushToast(isAr ? 'اكتمل تشخيص النظام' : 'System diagnostics complete', res.runtime, 'cyan');
              }}
            >
              {isAr ? 'فحص التشخيص' : 'Run Diagnostics'}
            </GlassButton>
            <GlassButton
              size="sm"
              onClick={async () => {
                await sendNativeNotification('DZNOVA Ice Aurora', 'Desktop notification test successful.');
                pushToast(isAr ? 'تم إرسال إشعار اختباري' : 'Test notification dispatched', undefined, 'emerald');
              }}
            >
              {isAr ? 'اختبار الإشعار' : 'Test Notification'}
            </GlassButton>
          </div>
          {diag && (
            <pre className="overflow-x-auto rounded-xl bg-ice-midnight/60 p-3 font-mono text-[11px] text-ice-glacier">
              {JSON.stringify(diag, null, 2)}
            </pre>
          )}
        </GlassCard>
      </div>
    </div>
  );
};

export const AdminPanelPage: React.FC = () => {
  const { lang, tokens, revokeToken, platforms } = useDznova();
  const isAr = lang === 'ar';
  return (
    <GlassCard className="space-y-4">
      <div className="flex items-center gap-3">
        <AdminPanelIcon size={38} />
        <h1 className="text-2xl font-extrabold">{t(lang, 'navAdmin')}</h1>
      </div>
      <p className="text-xs opacity-75">
        {isAr ? `الرموز النشطة: ${tokens.filter((x) => !x.revoked).length} • TikTok: ${platforms.tiktok_live_studio.stage} • OBS: ${platforms.obs_studio.stage}` : `Active tokens: ${tokens.filter((x) => !x.revoked).length} • TikTok: ${platforms.tiktok_live_studio.stage} • OBS: ${platforms.obs_studio.stage}`}
      </p>
      <div className="space-y-2">
        {tokens.length === 0 ? (
          <p className="text-xs opacity-70">{isAr ? 'لا توجد رموز مولّدة بعد.' : 'No overlay tokens generated yet.'}</p>
        ) : (
          tokens.map((tok) => (
            <div key={tok.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-ice-midnight/45 p-3 text-xs">
              <span className="font-mono">{tok.overlayType} • {tok.platform} • {tok.token.slice(0, 14)}...</span>
              <div className="flex items-center gap-2">
                <GlassBadge tone={tok.revoked ? 'rose' : 'emerald'}>{tok.revoked ? 'Revoked' : 'Active'}</GlassBadge>
                {!tok.revoked && (
                  <GlassButton size="sm" variant="danger" onClick={() => revokeToken(tok.token)}>
                    {isAr ? 'إلغاء' : 'Revoke'}
                  </GlassButton>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </GlassCard>
  );
};

export const SupportPage: React.FC = () => {
  const { lang, pushToast } = useDznova();
  const isAr = lang === 'ar';
  const [subject, setSubject] = useState('');
  return (
    <GlassCard className="space-y-4">
      <div className="flex items-center gap-3">
        <SupportIcon size={38} />
        <h1 className="text-2xl font-extrabold">{t(lang, 'navSupport')}</h1>
      </div>
      <div className="grid gap-3 md:grid-cols-2 text-xs">
        <div className="rounded-xl bg-ice-midnight/45 p-4">
          <p className="font-bold text-ice-glacier">TikTok LIVE Studio Transparency</p>
          <p className="mt-1 opacity-80">
            {isAr ? 'استخدم ملف التوافق TikTok LIVE Studio Standard إذا لاحظت بطئاً في الضبابية.' : 'Switch to the TikTok LIVE Studio Standard profile if backdrop blur slows down rendering.'}
          </p>
        </div>
        <div className="rounded-xl bg-ice-midnight/45 p-4">
          <p className="font-bold text-ice-glacier">OBS Studio Browser Source</p>
          <p className="mt-1 opacity-80">
            {isAr ? 'تأكد من ضبط الأبعاد 1920×1080 وتحديث ذاكرة المصدر عند تدوير الرمز الأمني.' : 'Set 1920×1080 and refresh Browser Source cache after rotating a revoked token.'}
          </p>
        </div>
      </div>
      <form
        className="flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          if (!subject.trim()) return;
          pushToast(isAr ? 'تم استلام تذكرة الدعم' : 'Support ticket logged', subject, 'emerald');
          setSubject('');
        }}
      >
        <input
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          placeholder={isAr ? 'صف مشكلتك التقنية...' : 'Describe your issue...'}
          className="flex-1 rounded-xl border border-ice-crystal/25 bg-ice-midnight/60 px-4 py-2 text-sm text-ice-white"
        />
        <GlassButton type="submit" variant="primary">{isAr ? 'إرسال' : 'Submit'}</GlassButton>
      </form>
    </GlassCard>
  );
};

export const IconStudioPage: React.FC = () => {
  const { lang, theme, setShowIntroModal } = useDznova();
  const isAr = lang === 'ar';
  const [query, setQuery] = useState('');
  const filtered = ICON_REGISTRY.filter((i) => i.name.toLowerCase().includes(query.toLowerCase()));

  return (
    <div className="space-y-6">
      <GlassCard className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold">
            {isAr ? `استوديو الهوية والـ ${ICON_REGISTRY.length} أيقونة ثلاثية الأبعاد` : `Ice Aurora Brand & ${ICON_REGISTRY.length} Original 3D Icons`}
          </h1>
          <p className="text-xs opacity-75">
            {isAr ? 'مجموعة أيقونات أصلية بتصميم زجاجي كريستالي ثلاثي الأبعاد بدون أي إيموجي.' : 'Original multi-layer crystal glass React SVG icons with zero emoji.'}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={isAr ? 'بحث في الأيقونات...' : 'Filter icons...'}
            className="rounded-xl border border-ice-crystal/25 bg-ice-midnight/60 px-3 py-2 text-xs text-ice-white"
          />
          <GlassButton variant="primary" size="sm" onClick={() => setShowIntroModal(true)}>
            {isAr ? 'تشغيل مقدمة الشعار' : 'Play Logo Intro'}
          </GlassButton>
        </div>
      </GlassCard>

      <GlassCard className="flex flex-wrap items-center justify-around gap-6">
        <DznovaLogo variant="wordmark" theme={theme} size={48} />
        <DznovaLogo variant="symbol" theme={theme} size={48} />
        <DznovaLogo variant="compact" theme={theme} size={36} />
        <DznovaLogo variant="monochrome" theme={theme} size={44} />
      </GlassCard>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-9">
        {filtered.map(({ id, name, Component }) => (
          <GlassCard key={id} interactive className="flex flex-col items-center gap-2 p-3 text-center">
            <Component size={40} />
            <span className="text-[10px] font-semibold opacity-85">{name}</span>
          </GlassCard>
        ))}
      </div>
    </div>
  );
};
