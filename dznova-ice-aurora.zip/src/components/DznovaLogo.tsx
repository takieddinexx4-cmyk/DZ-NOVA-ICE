import React from 'react';

export interface DznovaLogoProps {
  variant?: 'wordmark' | 'symbol' | 'compact' | 'monochrome';
  theme?: 'dark' | 'light';
  size?: number;
  animated?: boolean;
  className?: string;
}

export const DznovaLogo: React.FC<DznovaLogoProps> = ({
  variant = 'wordmark',
  theme = 'dark',
  size = 40,
  animated = false,
  className = '',
}) => {
  const isMono = variant === 'monochrome';
  const strokeMain = isMono ? 'currentColor' : theme === 'dark' ? '#F3FAFF' : '#091526';
  const accentGradId = `dzn-grad-${variant}-${theme}`;
  const glassGradId = `dzn-glass-${variant}-${theme}`;

  const symbol = (
    <svg
      width={size}
      height={size}
      viewBox="0 0 120 120"
      fill="none"
      className={`${animated ? 'animate-crystal-float' : ''} shrink-0`}
      aria-label="DZNOVA Emblem"
    >
      <defs>
        <linearGradient id={accentGradId} x1="12" y1="8" x2="108" y2="112" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#58DDF5" />
          <stop offset="52%" stopColor="#408DFF" />
          <stop offset="100%" stopColor="#9477FF" />
        </linearGradient>
        <linearGradient id={glassGradId} x1="10" y1="10" x2="110" y2="110" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor={theme === 'dark' ? '#A9E5FF' : '#408DFF'} stopOpacity="0.28" />
          <stop offset="100%" stopColor="#9477FF" stopOpacity="0.24" />
        </linearGradient>
      </defs>
      <rect
        x="8"
        y="8"
        width="104"
        height="104"
        rx="28"
        fill={isMono ? 'none' : theme === 'dark' ? '#091526' : '#F3FAFF'}
        stroke={isMono ? 'currentColor' : `url(#${accentGradId})`}
        strokeWidth="3"
      />
      {!isMono && (
        <>
          <rect x="10" y="10" width="100" height="100" rx="26" fill={`url(#${glassGradId})`} />
          <polygon
            points="60,18 102,60 60,102 18,60"
            fill="#A9E5FF"
            fillOpacity="0.12"
            stroke="#A9E5FF"
            strokeOpacity="0.48"
            strokeWidth="1.5"
          />
        </>
      )}
      {/* D + Z + Streaming Waves + Nova Star */}
      <path
        d="M28 36H45C54.5 36 61 42.5 61 52V68C61 77.5 54.5 84 45 84H28V36Z"
        stroke={strokeMain}
        strokeWidth="7"
        strokeLinejoin="round"
      />
      <path
        d="M64 38H92L66 82H94"
        stroke={isMono ? 'currentColor' : `url(#${accentGradId})`}
        strokeWidth="7"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M88 20L91 27L98 30L91 33L88 40L85 33L78 30L85 27Z"
        fill={isMono ? 'currentColor' : '#F3FAFF'}
      />
      <path
        d="M21 60C21 46 30 34 41 29"
        stroke={isMono ? 'currentColor' : '#58DDF5'}
        strokeOpacity="0.7"
        strokeWidth="2.2"
        strokeLinecap="round"
      />
      <path
        d="M99 60C99 74 90 86 79 91"
        stroke={isMono ? 'currentColor' : '#9477FF'}
        strokeOpacity="0.7"
        strokeWidth="2.2"
        strokeLinecap="round"
      />
    </svg>
  );

  if (variant === 'symbol' || variant === 'monochrome') {
    return <span className={`inline-flex items-center ${className}`}>{symbol}</span>;
  }

  return (
    <span className={`inline-flex items-center gap-3 select-none ${className}`}>
      {symbol}
      <span className="flex flex-col leading-none">
        <span
          className={`font-extrabold tracking-[0.18em] ${
            variant === 'compact' ? 'text-base' : 'text-xl'
          } ${
            theme === 'dark'
              ? 'bg-gradient-to-r from-[#F3FAFF] via-[#A9E5FF] to-[#9477FF] bg-clip-text text-transparent'
              : 'bg-gradient-to-r from-[#091526] via-[#408DFF] to-[#9477FF] bg-clip-text text-transparent'
          }`}
        >
          DZNOVA
        </span>
        {variant !== 'compact' && (
          <span className="mt-1 text-[10px] font-semibold tracking-[0.26em] text-ice-glacier uppercase">
            ICE AURORA
          </span>
        )}
      </span>
    </span>
  );
};
