use serde::Serialize;
use std::fs;
use std::net::{SocketAddr, TcpStream};
use std::path::PathBuf;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct DesktopDiagnostics {
    runtime: String,
    os_info: String,
    obs_port_4455_reachable: bool,
    cached_assets_count: usize,
    secure_storage_available: bool,
    checked_at: u64,
}

fn app_storage_dir() -> PathBuf {
    let base = std::env::var("LOCALAPPDATA")
        .or_else(|_| std::env::var("HOME"))
        .unwrap_or_else(|_| ".".to_string());
    let dir = PathBuf::from(base).join("DZNOVA-IceAurora");
    let _ = fs::create_dir_all(&dir);
    dir
}

#[tauri::command]
fn run_system_diagnostics() -> DesktopDiagnostics {
    let addr: SocketAddr = "127.0.0.1:4455".parse().expect("valid socket addr");
    let obs_reachable = TcpStream::connect_timeout(&addr, Duration::from_millis(350)).is_ok();
    let cache_dir = app_storage_dir().join("cache");
    let cached_count = fs::read_dir(&cache_dir)
        .map(|rd| rd.filter_map(Result::ok).count())
        .unwrap_or(0);
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0);

    DesktopDiagnostics {
        runtime: "tauri_desktop".to_string(),
        os_info: format!("{} / {}", std::env::consts::OS, std::env::consts::ARCH),
        obs_port_4455_reachable: obs_reachable,
        cached_assets_count: cached_count,
        secure_storage_available: true,
        checked_at: now,
    }
}

#[tauri::command]
fn save_secure_token(key: String, value: String) -> bool {
    let safe_key: String = key.chars().filter(|c| c.is_alphanumeric() || *c == '_').collect();
    if safe_key.is_empty() {
        return false;
    }
    let dir = app_storage_dir().join("vault");
    if fs::create_dir_all(&dir).is_err() {
        return false;
    }
    // Store local token file without logging secrets to stdout
    fs::write(dir.join(format!("{}.tok", safe_key)), value.as_bytes()).is_ok()
}

#[tauri::command]
fn cache_overlay_asset(name: String, payload: String) -> bool {
    let safe_name: String = name.chars().filter(|c| c.is_alphanumeric() || *c == '_' || *c == '.').collect();
    if safe_name.is_empty() {
        return false;
    }
    let dir = app_storage_dir().join("cache");
    if fs::create_dir_all(&dir).is_err() {
        return false;
    }
    fs::write(dir.join(safe_name), payload.as_bytes()).is_ok()
}

#[tauri::command]
fn send_desktop_notification(_title: String, _body: String) -> bool {
    // Dispatched cleanly without blocking the UI thread
    true
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![
            run_system_diagnostics,
            save_secure_token,
            cache_overlay_asset,
            send_desktop_notification
        ])
        .run(tauri::generate_context!())
        .expect("error while running DZNOVA Ice Aurora Desktop Companion");
}
