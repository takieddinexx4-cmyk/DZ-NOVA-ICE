# Changelog

## v3.1.0 (2026-11-25)
- **Arabic TTS Engine (`src/engine/tts/`)**:
  - Added `arabicText.ts` normalization (strips emojis/URLs, collapses elongations, converts Arabic-Indic & Western digits to spoken Arabic words, splits mixed usernames like `Amine_DZ16`, editable pronunciation dictionary).
  - Rebuilt `WebSpeechProvider` with `voiceschanged` loading, `ar-DZ → ar-MA/ar-TN → ar-SA/ar-EG → ar-*` Natural/Neural voice ranking, 180-char sentence chunking, Chrome keep-alive timer, and length-scaled watchdog.
  - Added optional `CloudNeuralProvider` + `/server` Cloudflare Worker proxy (Azure/Google/ElevenLabs with zero client API keys) and IndexedDB TTS audio caching.
  - Added 7 voice presets (Woman, Young Woman, Girl, Child Boy, Man, Deep Man, Announcer) with honest "Approximated" labels on pitch-shifted presets, per-event templates (MSA & Algerian dialect), and Voice Diagnostics panel.
- **Sound & Ringtone Studio (`src/engine/audio/`)**:
  - Replaced single-oscillator synth with a single shared `AudioContext`, master `DynamicsCompressorNode`, TTS ducking (~60%), FM/bell/pluck/reverb/delay/sequencer engine, and **44 built-in sounds & Arabic-maqam/modern ringtones**.
  - Added custom MP3/WAV/OGG uploads (≤ 3 MB) in IndexedDB, per-event assignment dialog, favorites, search, JSON import/export, and priority/merging `AudioQueue`.
- **Cross-Process Transport (`/server`)**:
  - Added Cloudflare Worker SSE/POST relay + honest transport status ("Preview only – not reaching OBS" when no relay URL is configured).
- **Android APK (Capacitor 6)**:
  - Added `capacitor.config.ts`, native `MainActivity.java` Android `TextToSpeech` JS bridge, `scripts/apply-android-native.mjs`, mobile bottom navigation + safe areas, and GitHub Actions Android APK build job.
