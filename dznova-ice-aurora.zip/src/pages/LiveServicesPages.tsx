import React, { useState } from 'react';
import { useDznova } from '../context/DznovaContext';
import { GlassBadge, GlassButton, GlassCard } from '../components/GlassUI';
import {
  AudioIcon,
  CountdownIcon,
  GoalsIcon,
  PollsIcon,
  WheelIcon,
} from '../components/icons';

export const WheelAndPollsPage: React.FC = () => {
  const {
    lang,
    wheelSlices,
    setWheelSlices,
    wheelAngle,
    lastWheelWinner,
    spinWheel,
    poll,
    setPoll,
    votePoll,
  } = useDznova();
  const isAr = lang === 'ar';
  const [newSlice, setNewSlice] = useState('');
  const [newOption, setNewOption] = useState('');
  const totalVotes = Math.max(1, poll.options.reduce((s, o) => s + o.votes, 0));

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <GlassCard className="space-y-5">
        <div className="ice-title-plate">
          <WheelIcon size={36} />
          <h1 className="text-xl font-extrabold">{isAr ? 'عجلة الحظ التفاعلية (متزامنة مع الأوفرلاي)' : 'Interactive Spin Wheel (Live Synced)'}</h1>
        </div>
        <div className="flex flex-col items-center gap-4 py-2">
          <div
            className="flex h-48 w-48 items-center justify-center rounded-full border-4 border-ice-glacier bg-gradient-to-tr from-ice-midnight via-ice-aurora/45 to-ice-nebula/55 shadow-ice-glow transition-transform duration-1000"
            style={{ transform: `rotate(${wheelAngle}deg)` }}
          >
            <span className="px-4 text-center text-sm font-extrabold text-ice-white">
              {lastWheelWinner ?? (isAr ? 'اضغط تدوير' : 'Spin Now')}
            </span>
          </div>
          {lastWheelWinner && <GlassBadge tone="emerald">{lastWheelWinner}</GlassBadge>}
          <GlassButton variant="primary" size="lg" onClick={spinWheel}>
            <WheelIcon size={20} />
            <span>{isAr ? 'تدوير العجلة وبث النتيجة للأوفرلاي' : 'Spin Wheel & Sync to Overlay'}</span>
          </GlassButton>
        </div>

        <form
          className="flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            if (!newSlice.trim()) return;
            setWheelSlices((prev) => [...prev, newSlice.trim()]);
            setNewSlice('');
          }}
        >
          <input
            value={newSlice}
            onChange={(e) => setNewSlice(e.target.value)}
            placeholder={isAr ? 'أضف خياراً جديداً للعجلة...' : 'Add new wheel slice...'}
            className="flex-1 rounded-xl border border-ice-crystal/25 bg-ice-midnight/60 px-3 py-2 text-xs text-ice-white"
          />
          <GlassButton type="submit" size="sm" variant="primary">{isAr ? 'إضافة' : 'Add'}</GlassButton>
        </form>

        <div className="flex flex-wrap gap-2">
          {wheelSlices.map((slice, idx) => (
            <span key={`${slice}-${idx}`} className="ice-pill inline-flex items-center gap-2 rounded-xl px-3 py-1.5 text-xs font-bold">
              {slice}
              <button
                type="button"
                onClick={() => setWheelSlices((p) => p.filter((_, i) => i !== idx))}
                className="text-rose-300 hover:text-rose-200"
              >
                ✕
              </button>
            </span>
          ))}
        </div>
      </GlassCard>

      <GlassCard className="space-y-5">
        <div className="ice-title-plate">
          <PollsIcon size={36} />
          <h2 className="text-xl font-extrabold">{isAr ? 'استطلاعات الرأي المباشرة' : 'Live Stream Polls'}</h2>
        </div>
        <input
          value={poll.question}
          onChange={(e) => setPoll((p) => ({ ...p, question: e.target.value }))}
          className="w-full rounded-xl border border-ice-crystal/25 bg-ice-midnight/60 px-3 py-2 text-sm font-bold text-ice-white"
        />
        <div className="space-y-3">
          {poll.options.map((opt) => {
            const pct = Math.round((opt.votes / totalVotes) * 100);
            return (
              <div key={opt.id} className="rounded-xl bg-ice-midnight/50 p-3">
                <div className="mb-1.5 flex items-center justify-between text-xs font-bold">
                  <span>{opt.label}</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-ice-glacier">{opt.votes} ({pct}%)</span>
                    <GlassButton size="sm" variant="primary" onClick={() => votePoll(opt.id)}>
                      +1
                    </GlassButton>
                  </div>
                </div>
                <div className="h-2.5 w-full overflow-hidden rounded-full bg-ice-deep">
                  <div className="h-full rounded-full bg-gradient-to-r from-ice-glacier to-ice-nebula transition-all" style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
        <form
          className="flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            if (!newOption.trim()) return;
            setPoll((p) => ({
              ...p,
              options: [...p.options, { id: `opt_${Date.now()}`, label: newOption.trim(), votes: 0 }],
            }));
            setNewOption('');
          }}
        >
          <input
            value={newOption}
            onChange={(e) => setNewOption(e.target.value)}
            placeholder={isAr ? 'أضف خيار تصويت...' : 'Add poll option...'}
            className="flex-1 rounded-xl border border-ice-crystal/25 bg-ice-midnight/60 px-3 py-2 text-xs text-ice-white"
          />
          <GlassButton type="submit" size="sm" variant="primary">{isAr ? 'إضافة' : 'Add'}</GlassButton>
        </form>
      </GlassCard>
    </div>
  );
};

export const GoalsAndTimerPage: React.FC = () => {
  const { lang, goal, updateGoal, countdown, updateCountdown } = useDznova();
  const isAr = lang === 'ar';
  const pct = Math.min(100, Math.round((goal.current / Math.max(1, goal.target)) * 100));

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <GlassCard className="space-y-4">
        <div className="ice-title-plate">
          <GoalsIcon size={36} />
          <h1 className="text-xl font-extrabold">{isAr ? 'أهداف البث المباشر (متزامنة مع #overlay/goal)' : 'Live Stream Goals (#overlay/goal)'}</h1>
        </div>
        <input
          value={goal.title}
          onChange={(e) => updateGoal({ title: e.target.value })}
          className="w-full rounded-xl border border-ice-crystal/25 bg-ice-midnight/60 px-3 py-2 text-sm text-ice-white"
        />
        <div className="grid grid-cols-2 gap-3 text-xs">
          <label className="space-y-1">
            <span className="font-bold">{isAr ? 'الحالي' : 'Current'}</span>
            <input
              type="number"
              value={goal.current}
              onChange={(e) => updateGoal({ current: Math.max(0, Number(e.target.value) || 0) })}
              className="w-full rounded-xl border border-ice-crystal/25 bg-ice-midnight/60 px-3 py-2 text-ice-white"
            />
          </label>
          <label className="space-y-1">
            <span className="font-bold">{isAr ? 'الهدف' : 'Target'}</span>
            <input
              type="number"
              value={goal.target}
              onChange={(e) => updateGoal({ target: Math.max(1, Number(e.target.value) || 100) })}
              className="w-full rounded-xl border border-ice-crystal/25 bg-ice-midnight/60 px-3 py-2 text-ice-white"
            />
          </label>
        </div>
        <div className="h-4 w-full overflow-hidden rounded-full bg-ice-midnight/80">
          <div className="h-full rounded-full bg-gradient-to-r from-ice-glacier via-ice-aurora to-ice-nebula transition-all" style={{ width: `${pct}%` }} />
        </div>
        <div className="flex flex-wrap gap-2">
          <GlassButton size="sm" variant="primary" onClick={() => updateGoal({ current: goal.current + 100 })}>+100</GlassButton>
          <GlassButton size="sm" onClick={() => updateGoal({ current: goal.current + 500 })}>+500</GlassButton>
          <GlassButton size="sm" variant="danger" onClick={() => updateGoal({ current: 0 })}>{isAr ? 'تصفير' : 'Reset'}</GlassButton>
        </div>
      </GlassCard>

      <GlassCard className="space-y-4">
        <div className="ice-title-plate">
          <CountdownIcon size={36} />
          <h2 className="text-xl font-extrabold">{isAr ? 'مؤقت العد التنازلي (#overlay/countdown)' : 'Live Countdown Timer (#overlay/countdown)'}</h2>
        </div>
        <input
          value={countdown.label}
          onChange={(e) => updateCountdown({ label: e.target.value })}
          className="w-full rounded-xl border border-ice-crystal/25 bg-ice-midnight/60 px-3 py-2 text-sm text-ice-white"
        />
        <p className="py-2 text-center font-mono text-5xl font-extrabold text-ice-glacier">
          {String(Math.floor(countdown.secondsLeft / 60)).padStart(2, '0')}:
          {String(countdown.secondsLeft % 60).padStart(2, '0')}
        </p>
        <div className="flex flex-wrap justify-center gap-2">
          <GlassButton variant="primary" onClick={() => updateCountdown({ running: !countdown.running })}>
            {countdown.running ? (isAr ? 'إيقاف مؤقت' : 'Pause') : isAr ? 'تشغيل المؤقت' : 'Start Timer'}
          </GlassButton>
          <GlassButton onClick={() => updateCountdown({ secondsLeft: countdown.secondsLeft + 60 })}>+1m</GlassButton>
          <GlassButton onClick={() => updateCountdown({ secondsLeft: 300, running: false })}>05:00</GlassButton>
          <GlassButton variant="danger" onClick={() => updateCountdown({ secondsLeft: 0, running: false })}>
            {isAr ? 'تصفير' : 'Reset'}
          </GlassButton>
        </div>
      </GlassCard>
    </div>
  );
};

export const SoundboardPage: React.FC = () => {
  const { lang, soundPads, setSoundPads, soundVolume, setSoundVolume, triggerSoundPad } = useDznova();
  const isAr = lang === 'ar';
  return (
    <GlassCard className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="ice-title-plate">
          <AudioIcon size={38} />
          <div>
            <h1 className="text-xl font-extrabold">{isAr ? 'لوحة المؤثرات الصوتية المباشرة (Web Audio API)' : 'Live Web Audio Soundboard'}</h1>
            <p className="text-xs opacity-75">
              {isAr ? 'أصوات حقيقية تعمل فوراً في المتصفح وتُبث إلى OBS و TikTok LIVE Studio.' : 'Real synthesized Web Audio effects synced directly to overlays.'}
            </p>
          </div>
        </div>
        <label className="flex items-center gap-2 text-xs font-bold">
          <span>{isAr ? `الصوت ${Math.round(soundVolume * 100)}%` : `Volume ${Math.round(soundVolume * 100)}%`}</span>
          <input
            type="range"
            min="0.05"
            max="0.7"
            step="0.05"
            value={soundVolume}
            onChange={(e) => setSoundVolume(Number(e.target.value))}
          />
        </label>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {soundPads.map((pad) => (
          <GlassCard key={pad.id} interactive className="flex flex-col justify-between gap-3 p-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-extrabold">{isAr ? pad.nameAr : pad.nameEn}</span>
              <GlassBadge tone="cyan">{pad.preset}</GlassBadge>
            </div>
            <div className="flex items-center justify-between gap-2">
              <GlassButton size="sm" variant="primary" onClick={() => triggerSoundPad(pad)}>
                <AudioIcon size={16} />
                <span>{isAr ? 'تشغيل' : 'Play'}</span>
              </GlassButton>
              <label className="flex cursor-pointer items-center gap-1 text-[11px] opacity-80">
                <input
                  type="checkbox"
                  checked={pad.triggerOnGift}
                  onChange={(e) =>
                    setSoundPads((prev) =>
                      prev.map((p) => (p.id === pad.id ? { ...p, triggerOnGift: e.target.checked } : p)),
                    )
                  }
                />
                <span>{isAr ? 'مع الهدايا' : 'On Gift'}</span>
              </label>
            </div>
          </GlassCard>
        ))}
      </div>
    </GlassCard>
  );
};
