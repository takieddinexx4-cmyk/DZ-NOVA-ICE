export interface SynthNote {
  freq: number;
  startSec: number;
  durSec: number;
  wave?: OscillatorType;
  fmRatio?: number;
  fmDepth?: number;
  gain?: number;
}

export interface SynthRecipe {
  notes: SynthNote[];
  useReverb?: boolean;
  useDelay?: boolean;
  noiseBurstAt?: number[];
  attackSec?: number;
  releaseSec?: number;
}

/**
 * Single shared Web Audio API engine with:
 * - One persistent AudioContext (resumed on user gesture)
 * - Master bus with DynamicsCompressorNode limiter
 * - Automatic SFX ducking (~60% reduction) while TTS speaks
 * - Multi-voice FM/bell/pluck synth, generated-impulse reverb, delay, noise percussion & sequencer
 */
export class AudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private compressor: DynamicsCompressorNode | null = null;
  private reverbNode: ConvolverNode | null = null;
  private masterVolume = 0.75;
  private ducked = false;
  private unlocked = false;

  public isUnlocked(): boolean {
    return this.unlocked && this.ctx?.state === 'running';
  }

  public async unlock(): Promise<boolean> {
    const ctx = this.ensureContext();
    if (!ctx) return false;
    if (ctx.state === 'suspended') {
      try {
        await ctx.resume();
      } catch {
        return false;
      }
    }
    this.unlocked = ctx.state === 'running';
    return this.unlocked;
  }

  public setMasterVolume(v: number): void {
    this.masterVolume = Math.max(0, Math.min(1, v));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.masterVolume, this.ctx.currentTime, 0.03);
    }
  }

  public getMasterVolume(): number {
    return this.masterVolume;
  }

  public setDucking(active: boolean): void {
    this.ducked = active;
    if (this.sfxGain && this.ctx) {
      // Lower SFX ~60% (to 0.40) while TTS speaks
      this.sfxGain.gain.setTargetAtTime(active ? 0.4 : 1.0, this.ctx.currentTime, 0.06);
    }
  }

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (this.ctx) return this.ctx;
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return null;

    const ctx = new AudioCtx();
    const compressor = ctx.createDynamicsCompressor();
    compressor.threshold.value = -14;
    compressor.knee.value = 18;
    compressor.ratio.value = 6;
    compressor.attack.value = 0.004;
    compressor.release.value = 0.18;

    const masterGain = ctx.createGain();
    masterGain.gain.value = this.masterVolume;

    const sfxGain = ctx.createGain();
    sfxGain.gain.value = this.ducked ? 0.4 : 1.0;

    sfxGain.connect(compressor);
    compressor.connect(masterGain);
    masterGain.connect(ctx.destination);

    // Generated impulse response for lush crystal hall reverb
    const reverb = ctx.createConvolver();
    const length = Math.floor(ctx.sampleRate * 1.15);
    const impulse = ctx.createBuffer(2, length, ctx.sampleRate);
    for (let ch = 0; ch < 2; ch += 1) {
      const data = impulse.getChannelData(ch);
      for (let i = 0; i < length; i += 1) {
        data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, 2.4);
      }
    }
    reverb.buffer = impulse;

    this.ctx = ctx;
    this.compressor = compressor;
    this.masterGain = masterGain;
    this.sfxGain = sfxGain;
    this.reverbNode = reverb;
    return ctx;
  }

  public async playRecipe(recipe: SynthRecipe, volume = 0.7): Promise<void> {
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;
    if (ctx.state === 'suspended') {
      await ctx.resume().catch(() => undefined);
    }
    this.unlocked = ctx.state === 'running';

    const now = ctx.currentTime + 0.015;
    const voiceBus = ctx.createGain();
    voiceBus.gain.value = Math.max(0.02, Math.min(1, volume));
    voiceBus.connect(this.sfxGain);

    if (recipe.useReverb && this.reverbNode) {
      const wet = ctx.createGain();
      wet.gain.value = 0.28;
      voiceBus.connect(this.reverbNode);
      this.reverbNode.connect(wet);
      wet.connect(this.sfxGain);
    }

    if (recipe.useDelay) {
      const delay = ctx.createDelay(0.6);
      delay.delayTime.value = 0.18;
      const fb = ctx.createGain();
      fb.gain.value = 0.22;
      voiceBus.connect(delay);
      delay.connect(fb);
      fb.connect(delay);
      delay.connect(this.sfxGain);
    }

    const attack = recipe.attackSec ?? 0.012;
    const release = recipe.releaseSec ?? 0.14;
    let maxEnd = 0.25;

    for (const note of recipe.notes) {
      const t0 = now + note.startSec;
      const t1 = t0 + note.durSec;
      maxEnd = Math.max(maxEnd, note.startSec + note.durSec + release);

      const env = ctx.createGain();
      const peak = note.gain ?? 0.26;
      env.gain.setValueAtTime(0.0001, t0);
      env.gain.linearRampToValueAtTime(peak, t0 + attack);
      env.gain.exponentialRampToValueAtTime(0.0008, t1 + release);
      env.connect(voiceBus);

      const carrier = ctx.createOscillator();
      carrier.type = note.wave ?? 'triangle';
      carrier.frequency.setValueAtTime(note.freq, t0);

      if (note.fmRatio && note.fmDepth) {
        const mod = ctx.createOscillator();
        const modGain = ctx.createGain();
        mod.frequency.setValueAtTime(note.freq * note.fmRatio, t0);
        modGain.gain.setValueAtTime(note.fmDepth, t0);
        modGain.gain.exponentialRampToValueAtTime(1, t1);
        mod.connect(modGain);
        modGain.connect(carrier.frequency);
        mod.start(t0);
        mod.stop(t1 + release + 0.02);
      }

      carrier.connect(env);
      carrier.start(t0);
      carrier.stop(t1 + release + 0.02);
    }

    if (recipe.noiseBurstAt) {
      for (const offset of recipe.noiseBurstAt) {
        const t0 = now + offset;
        const bufLen = Math.floor(ctx.sampleRate * 0.09);
        const buf = ctx.createBuffer(1, bufLen, ctx.sampleRate);
        const data = buf.getChannelData(0);
        for (let i = 0; i < bufLen; i += 1) {
          data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufLen * 0.35));
        }
        const src = ctx.createBufferSource();
        src.buffer = buf;
        const hp = ctx.createBiquadFilter();
        hp.type = 'highpass';
        hp.frequency.value = 1800;
        const ng = ctx.createGain();
        ng.gain.value = 0.14;
        src.connect(hp);
        hp.connect(ng);
        ng.connect(voiceBus);
        src.start(t0);
      }
    }

    await new Promise((r) => setTimeout(r, Math.ceil(maxEnd * 1000)));
  }

  public async playArrayBuffer(
    data: ArrayBuffer,
    options?: {
      volume?: number;
      trimStartSec?: number;
      trimEndSec?: number;
      fadeInSec?: number;
      fadeOutSec?: number;
      isSfx?: boolean;
      onSourceCreated?: (src: AudioBufferSourceNode) => void;
    },
  ): Promise<void> {
    const ctx = this.ensureContext();
    if (!ctx || !this.compressor || !this.sfxGain) return;
    if (ctx.state === 'suspended') {
      await ctx.resume().catch(() => undefined);
    }
    this.unlocked = ctx.state === 'running';

    const decoded = await ctx.decodeAudioData(data);
    const src = ctx.createBufferSource();
    src.buffer = decoded;
    options?.onSourceCreated?.(src);

    const start = Math.max(0, options?.trimStartSec ?? 0);
    const rawEnd = options?.trimEndSec && options.trimEndSec > start ? Math.min(decoded.duration, options.trimEndSec) : decoded.duration;
    const duration = Math.max(0.05, rawEnd - start);

    const gain = ctx.createGain();
    const vol = Math.max(0.02, Math.min(1, options?.volume ?? 0.85));
    const now = ctx.currentTime;
    const fadeIn = Math.min(duration * 0.4, options?.fadeInSec ?? 0.01);
    const fadeOut = Math.min(duration * 0.4, options?.fadeOutSec ?? 0.02);

    gain.gain.setValueAtTime(fadeIn > 0 ? 0.001 : vol, now);
    if (fadeIn > 0) gain.gain.linearRampToValueAtTime(vol, now + fadeIn);
    if (fadeOut > 0) {
      gain.gain.setValueAtTime(vol, now + Math.max(0.01, duration - fadeOut));
      gain.gain.linearRampToValueAtTime(0.001, now + duration);
    }

    src.connect(gain);
    gain.connect(options?.isSfx ? this.sfxGain : this.compressor);

    await new Promise<void>((resolve) => {
      src.onended = () => resolve();
      src.start(now, start, duration);
    });
  }
}

export const sharedAudioEngine = new AudioEngine();
