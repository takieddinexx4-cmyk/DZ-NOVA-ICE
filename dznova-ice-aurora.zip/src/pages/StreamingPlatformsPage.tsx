import React, { useState } from 'react';
import { useDznova } from '../context/DznovaContext';
import { GlassBadge, GlassButton, GlassCard } from '../components/GlassUI';
import {
  COMPATIBILITY_PROFILES,
  buildOverlayUrl,
} from '../engine/OverlayEngine';
import { testObsWebSocketConnection } from '../engine/ObsWebSocketClient';
import { loadRelayConfig, saveRelayConfig, type RelayConfig } from '../engine/OverlayTransport';
import type {
  CompatibilityProfileId,
  OverlayType,
  PlatformConnectionStage,
  StreamingPlatformId,
} from '../types/dznova';
import {
  AlertsIcon,
  ChatIcon,
  CountdownIcon,
  DiagnosticsIcon,
  GiftsIcon,
  GoalsIcon,
  LeaderboardsIcon,
  LiveStreamIcon,
  ObsStudioIcon,
  OverlayLibraryIcon,
  SecurityIcon,
  SetupWizardIcon,
  StreamingPlatformsIcon,
  TikTokLiveStudioIcon,
  WheelIcon,
  WilayaBattleIcon,
} from '../components/icons';
import { t } from '../i18n/translations';

const RESOLUTIONS = [
  { width: 1920, height: 1080, label: '1920 × 1080 (Full HD 16:9)' },
  { width: 1280, height: 720, label: '1280 × 720 (HD 16:9)' },
  { width: 1080, height: 1920, label: '1080 × 1920 (Vertical 9:16 TikTok)' },
];

const OVERLAY_OPTIONS: {
  id: OverlayType;
  labelAr: string;
  labelEn: string;
  Icon: React.FC<{ size?: number }>;
}[] = [
  { id: 'alerts', labelAr: 'تنبيهات الهدايا والمتابعات', labelEn: 'Gift & Follow Alerts', Icon: AlertsIcon },
  { id: 'wilaya', labelAr: 'تحدي الولايات الجزائري', labelEn: 'Algerian Wilaya Battle', Icon: WilayaBattleIcon },
  { id: 'chat', labelAr: 'صندوق الدردشة الزجاجي', labelEn: 'Aurora Live Chat', Icon: ChatIcon },
  { id: 'goal', labelAr: 'شريط الأهداف المباشر', labelEn: 'Stream Goal Bar', Icon: GoalsIcon },
  { id: 'wheel', labelAr: 'عجلة الحظ التفاعلية', labelEn: 'Interactive Spin Wheel', Icon: WheelIcon },
  { id: 'countdown', labelAr: 'مؤقت العد التنازلي', labelEn: 'Stream Countdown', Icon: CountdownIcon },
  { id: 'leaderboard', labelAr: 'لوحة المتصدرين', labelEn: 'Top Supporters Board', Icon: LeaderboardsIcon },
];

function stageBadgeTone(stage: PlatformConnectionStage): 'neutral' | 'amber' | 'cyan' | 'violet' | 'emerald' {
  switch (stage) {
    case 'integration_verified':
      return 'emerald';
    case 'events_received':
      return 'violet';
    case 'browser_source_loaded':
      return 'cyan';
    case 'overlay_opened':
    case 'url_generated':
      return 'amber';
    default:
      return 'neutral';
  }
}

function stageLabel(lang: 'ar' | 'en' | 'fr', stage: PlatformConnectionStage): string {
  const map: Record<PlatformConnectionStage, string> = {
    not_configured: t(lang, 'stageNotConfigured'),
    url_generated: t(lang, 'stageUrlGenerated'),
    overlay_opened: t(lang, 'stageOverlayOpened'),
    browser_source_loaded: t(lang, 'stageBrowserSourceLoaded'),
    events_received: t(lang, 'stageEventsReceived'),
    integration_verified: t(lang, 'stageIntegrationVerified'),
  };
  return map[stage];
}

export const StreamingPlatformsPage: React.FC = () => {
  const {
    lang,
    tokens,
    generateToken,
    revokeToken,
    platforms,
    markOverlayOpened,
    updatePlatformProfile,
    updatePlatformResolution,
    runPlatformCheck,
    wizard,
    updateWizard,
    resetWizard,
    obsWs,
    setObsWs,
    triggerMockGift,
    pushToast,
  } = useDznova();

  const isAr = lang === 'ar';
  const [selectedOverlay, setSelectedOverlay] = useState<OverlayType>('alerts');
  const [obsPasswordInput, setObsPasswordInput] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'hub' | 'wizard' | 'monitor'>('hub');
  const [relayCfg, setRelayCfg] = useState<RelayConfig>(() => loadRelayConfig());

  const baseUrl = typeof window !== 'undefined' ? window.location.href : 'https://takieddinexx4-cmyk.github.io/DZ-NOVA/';

  const latestTokenFor = (platform: StreamingPlatformId, overlay: OverlayType) =>
    tokens.find((tok) => !tok.revoked && tok.platform === platform && tok.overlayType === overlay);

  const handleGenerate = (platform: StreamingPlatformId, overlay: OverlayType = selectedOverlay) => {
    const plat = platforms[platform];
    const rec = generateToken({
      overlayType: overlay,
      platform,
      profile: plat.activeProfile,
      width: plat.resolution.width,
      height: plat.resolution.height,
    });
    pushToast(
      isAr ? 'تم توليد رابط Browser Source آمن' : 'Secure Browser Source URL generated',
      isAr
        ? 'ملاحظة: توليد الرابط لا يعني اتصال المنصة بعد — افتحه داخل البرنامج للتحقق.'
        : 'Note: Generating a URL does not mark the platform connected until the source loads.',
      'cyan',
    );
    return rec;
  };

  const handleCopy = async (id: string, url: string) => {
    try {
      await navigator.clipboard.writeText(url);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
      pushToast(isAr ? 'تم نسخ الرابط الآمن' : 'Secure URL copied', undefined, 'emerald');
    } catch {
      pushToast(isAr ? 'انسخ الرابط يدوياً من الحقل' : 'Copy the URL manually from the field', undefined, 'amber');
    }
  };

  const handleOpenPreview = (platform: StreamingPlatformId, url: string) => {
    markOverlayOpened(platform);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleTestObsWs = async () => {
    setObsWs((prev) => ({ ...prev, status: 'connecting', lastError: null }));
    const res = await testObsWebSocketConnection({
      host: obsWs.host,
      port: obsWs.port,
      password: obsPasswordInput || undefined,
    });
    // Password is never logged or persisted in plaintext
    setObsWs((prev) => ({
      ...prev,
      hasPassword: Boolean(obsPasswordInput),
      status: res.connected ? 'connected' : 'error',
      lastError: res.error ?? null,
      lastCheckedAt: Date.now(),
    }));
    pushToast(
      res.connected
        ? isAr
          ? 'تم التحقق من OBS WebSocket'
          : 'OBS WebSocket verified'
        : isAr
          ? 'تعذر الاتصال بـ OBS WebSocket'
          : 'OBS WebSocket unreachable',
      res.error,
      res.connected ? 'emerald' : 'amber',
    );
  };

  const renderPlatformCard = (platformId: StreamingPlatformId) => {
    const isTikTok = platformId === 'tiktok_live_studio';
    const st = platforms[platformId];
    const activeTok = latestTokenFor(platformId, selectedOverlay);
    const url = activeTok ? buildOverlayUrl(baseUrl, activeTok) : '';

    return (
      <GlassCard key={platformId} interactive className="flex flex-col gap-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="ice-title-plate">
            {isTikTok ? <TikTokLiveStudioIcon size={40} /> : <ObsStudioIcon size={40} />}
            <div>
              <h2 className="text-lg font-extrabold">
                {isTikTok ? 'TikTok LIVE Studio' : 'OBS Studio'}
              </h2>
              <p className="text-xs opacity-75">
                {isTikTok
                  ? isAr
                    ? 'دعم أساسي عبر Browser / Webpage Source المعتمد'
                    : 'First-class Browser / Webpage Source workflow'
                  : isAr
                    ? 'تكامل Browser Source + دعم OBS WebSocket v5 الاختياري'
                    : 'Browser Source + optional secure OBS WebSocket v5'}
              </p>
            </div>
          </div>
          <GlassBadge tone={stageBadgeTone(st.stage)}>{stageLabel(lang, st.stage)}</GlassBadge>
        </div>

        {/* Honest 5-Step Verification Pipeline */}
        <div className="grid grid-cols-5 gap-1.5 text-center text-[10px]">
          {[
            { done: Boolean(st.urlGeneratedAt), label: isAr ? '1. رابط' : '1. URL' },
            { done: Boolean(st.overlayOpenedAt), label: isAr ? '2. فتح' : '2. Open' },
            { done: Boolean(st.browserSourceLoadedAt), label: isAr ? '3. تحميل' : '3. Loaded' },
            { done: Boolean(st.lastEventAt), label: isAr ? '4. أحداث' : '4. Events' },
            { done: st.stage === 'integration_verified', label: isAr ? '5. موثّق' : '5. Verified' },
          ].map((s) => (
            <div
              key={s.label}
              className={`rounded-lg border px-1 py-1.5 font-semibold ${
                s.done
                  ? 'border-ice-glacier/50 bg-ice-glacier/20 text-ice-glacier'
                  : 'border-ice-crystal/15 bg-ice-deep/30 opacity-60'
              }`}
            >
              {s.label}
            </div>
          ))}
        </div>

        {/* Resolution & Compatibility Profile */}
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="flex flex-col gap-1 text-xs">
            <span className="font-semibold opacity-80">{isAr ? 'دقة المصدر' : 'Source Resolution'}</span>
            <select
              value={`${st.resolution.width}x${st.resolution.height}`}
              onChange={(e) => {
                const [w, h] = e.target.value.split('x').map(Number);
                updatePlatformResolution(platformId, w, h);
              }}
              className="rounded-xl border border-ice-crystal/25 bg-ice-midnight/70 px-3 py-2 text-xs text-ice-white"
            >
              {RESOLUTIONS.map((r) => (
                <option key={r.label} value={`${r.width}x${r.height}`}>
                  {r.label}
                </option>
              ))}
            </select>
          </label>
          <label className="flex flex-col gap-1 text-xs">
            <span className="font-semibold opacity-80">{isAr ? 'ملف التوافق' : 'Compatibility Profile'}</span>
            <select
              value={st.activeProfile}
              onChange={(e) => updatePlatformProfile(platformId, e.target.value as CompatibilityProfileId)}
              className="rounded-xl border border-ice-crystal/25 bg-ice-midnight/70 px-3 py-2 text-xs text-ice-white"
            >
              {Object.values(COMPATIBILITY_PROFILES).map((p) => (
                <option key={p.id} value={p.id}>
                  {isAr ? p.nameAr : p.nameEn}
                </option>
              ))}
            </select>
          </label>
        </div>

        {/* Secure Revocable URL Generation */}
        <div className="rounded-xl border border-ice-crystal/20 bg-ice-midnight/50 p-3.5">
          <div className="mb-2 flex items-center justify-between gap-2">
            <span className="text-xs font-bold text-ice-crystal">
              {isAr ? 'رابط Browser Source الآمن' : 'Secure Browser Source URL'} ({selectedOverlay})
            </span>
            <GlassButton size="sm" variant="primary" onClick={() => handleGenerate(platformId)}>
              <OverlayLibraryIcon size={16} />
              <span>{activeTok ? (isAr ? 'توليد جديد' : 'Regenerate') : isAr ? 'توليد الرابط' : 'Generate URL'}</span>
            </GlassButton>
          </div>
          {url ? (
            <>
              <input
                readOnly
                value={url}
                className="w-full rounded-lg border border-ice-crystal/20 bg-ice-deep/80 px-2.5 py-2 font-mono text-[11px] text-ice-glacier"
              />
              <div className="mt-2.5 flex flex-wrap gap-2">
                <GlassButton size="sm" onClick={() => void handleCopy(`${platformId}-${selectedOverlay}`, url)}>
                  {copiedId === `${platformId}-${selectedOverlay}` ? t(lang, 'copied') : t(lang, 'copyUrl')}
                </GlassButton>
                <GlassButton size="sm" onClick={() => handleOpenPreview(platformId, url)}>
                  <LiveStreamIcon size={16} />
                  <span>{t(lang, 'openPreview')}</span>
                </GlassButton>
                <GlassButton
                  size="sm"
                  variant="primary"
                  onClick={() => {
                    triggerMockGift(platformId);
                    pushToast(
                      isAr ? 'تم إرسال حدث اختباري عبر MockLiveSource' : 'MockLiveSource test event sent',
                      platformId,
                      'cyan',
                    );
                  }}
                >
                  <GiftsIcon size={16} />
                  <span>{t(lang, 'sendTestEvent')}</span>
                </GlassButton>
                <GlassButton size="sm" variant="danger" onClick={() => activeTok && revokeToken(activeTok.token)}>
                  {t(lang, 'revokeToken')}
                </GlassButton>
              </div>
            </>
          ) : (
            <p className="text-xs opacity-70">
              {isAr
                ? 'اضغط "توليد الرابط" لإنشاء رمز أمني قابل للإلغاء متوافق مع هذه المنصة.'
                : 'Click Generate URL to create a secure, revocable Browser Source token for this platform.'}
            </p>
          )}
        </div>

        {/* Platform-Specific Setup Instructions & Honest Limitations */}
        <div className="space-y-2 rounded-xl border border-ice-crystal/15 bg-ice-deep/35 p-3.5 text-xs">
          <p className="font-bold text-ice-crystal">
            {isTikTok
              ? isAr
                ? 'خطوات الإضافة في TikTok LIVE Studio:'
                : 'TikTok LIVE Studio Setup Steps:'
              : isAr
                ? 'خطوات الإضافة في OBS Studio:'
                : 'OBS Studio Setup Steps:'}
          </p>
          {isTikTok ? (
            <ol className="list-inside list-decimal space-y-1 opacity-85">
              <li>{isAr ? 'افتح TikTok LIVE Studio واختر المشهد النشط.' : 'Open TikTok LIVE Studio and select your active scene.'}</li>
              <li>{isAr ? 'اضغط Add Source ← Link / Browser Source (حسب إصدار البرنامج المثبّت).' : 'Click Add Source → Link / Browser Source (where supported by your installed version).'}</li>
              <li>{isAr ? `أدخل الرابط المنسوخ واضبط الأبعاد ${st.resolution.width}×${st.resolution.height} مع تفعيل الشفافية.` : `Paste the copied URL, set ${st.resolution.width}×${st.resolution.height}, and keep transparent background enabled.`}</li>
              <li>{isAr ? 'استخدم زر "إرسال حدث اختباري" للتأكد من ظهور التنبيه.' : 'Click Send Test Event to confirm rendering via MockLiveSource.'}</li>
            </ol>
          ) : (
            <ol className="list-inside list-decimal space-y-1 opacity-85">
              <li>{isAr ? 'في OBS Studio، اضغط (+) في Sources ← Browser.' : 'In OBS Studio, click (+) under Sources → Browser.'}</li>
              <li>{isAr ? `الصق الرابط واضبط العرض ${st.resolution.width} والارتفاع ${st.resolution.height} و FPS 60.` : `Paste URL, set Width ${st.resolution.width}, Height ${st.resolution.height}, and 60 FPS.`}</li>
              <li>{isAr ? 'اترك Custom CSS فارغاً لأن الخلفية شفافة تلقائياً.' : 'Leave Custom CSS empty — DZNOVA enforces alpha transparency automatically.'}</li>
              <li>{isAr ? 'فعّل "Control audio via OBS" لإدارة الصوت من طابور الصوت.' : 'Enable "Control audio via OBS" to route the AudioQueue cleanly.'}</li>
            </ol>
          )}
          <div className="mt-2 rounded-lg border border-amber-400/30 bg-amber-400/10 p-2.5 text-[11px] text-amber-200">
            {isTikTok
              ? isAr
                ? 'شفافية تقنية: لا يزعم DZNOVA التحكم عن بُعد بمشاهد TikTok LIVE Studio أو محاكاة ضغطات المفاتيح عبر المتصفح؛ التكامل يتم فقط عبر مصادر المتصفح المدعومة رسمياً.'
                : 'Technical Honesty: DZNOVA does not claim undocumented remote scene control or browser keystroke injection for TikTok LIVE Studio; integration uses supported Browser/Webpage sources only.'
              : isAr
                ? 'OBS WebSocket v5 اختياري ومعطّل افتراضياً ولا يتم حفظ كلمة المرور في السجلات العامة.'
                : 'OBS WebSocket v5 is optional, disabled by default, and never exposes passwords to public logs.'}
          </div>
        </div>

        {/* Optional Secure OBS WebSocket Panel */}
        {!isTikTok && (
          <div className="rounded-xl border border-ice-nebula/30 bg-ice-midnight/50 p-3.5 text-xs">
            <div className="mb-2 flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-ice-crystal">
                <SecurityIcon size={20} />
                <span>{isAr ? 'تكامل OBS WebSocket v5 (اختياري)' : 'Optional OBS WebSocket v5'}</span>
              </div>
              <label className="inline-flex cursor-pointer items-center gap-2">
                <input
                  type="checkbox"
                  checked={obsWs.enabled}
                  onChange={(e) =>
                    setObsWs((prev) => ({
                      ...prev,
                      enabled: e.target.checked,
                      status: e.target.checked ? 'disconnected' : 'disabled',
                    }))
                  }
                />
                <span>{obsWs.enabled ? (isAr ? 'مُفعّل' : 'Enabled') : isAr ? 'معطّل' : 'Disabled'}</span>
              </label>
            </div>
            {obsWs.enabled && (
              <div className="mt-2 space-y-2">
                <div className="grid grid-cols-3 gap-2">
                  <input
                    value={obsWs.host}
                    onChange={(e) => setObsWs((p) => ({ ...p, host: e.target.value }))}
                    placeholder="127.0.0.1"
                    className="rounded-lg border border-ice-crystal/20 bg-ice-deep/80 px-2.5 py-1.5 text-ice-white"
                  />
                  <input
                    type="number"
                    value={obsWs.port}
                    onChange={(e) => setObsWs((p) => ({ ...p, port: Number(e.target.value) || 4455 }))}
                    placeholder="4455"
                    className="rounded-lg border border-ice-crystal/20 bg-ice-deep/80 px-2.5 py-1.5 text-ice-white"
                  />
                  <input
                    type="password"
                    value={obsPasswordInput}
                    onChange={(e) => setObsPasswordInput(e.target.value)}
                    placeholder={isAr ? 'كلمة المرور (آمنة)' : 'Password (never logged)'}
                    className="rounded-lg border border-ice-crystal/20 bg-ice-deep/80 px-2.5 py-1.5 text-ice-white"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <GlassBadge tone={obsWs.status === 'connected' ? 'emerald' : obsWs.status === 'error' ? 'rose' : 'neutral'}>
                    WS: {obsWs.status}
                  </GlassBadge>
                  <GlassButton size="sm" variant="primary" onClick={() => void handleTestObsWs()}>
                    {isAr ? 'اختبار الاتصال الآمن' : 'Test WebSocket'}
                  </GlassButton>
                </div>
                {obsWs.lastError && <p className="text-[11px] text-rose-300">{obsWs.lastError}</p>}
              </div>
            )}
          </div>
        )}
      </GlassCard>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="ice-title-plate">
          <StreamingPlatformsIcon size={42} />
          <div>
            <h1 className="text-xl font-extrabold sm:text-2xl">
              {isAr ? 'مركز منصات البث الموحد' : 'Unified Streaming Platforms Hub'}
            </h1>
            <p className="text-sm opacity-75">
              {isAr
                ? 'إدارة وتشغيل أوفرلاي DZNOVA في TikTok LIVE Studio و OBS Studio من لوحة واحدة.'
                : 'Manage and verify DZNOVA overlays across TikTok LIVE Studio and OBS Studio from one control center.'}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <GlassButton variant={activeTab === 'hub' ? 'primary' : 'secondary'} onClick={() => setActiveTab('hub')}>
            <StreamingPlatformsIcon size={18} />
            {isAr ? 'المنصتان' : 'Platforms'}
          </GlassButton>
          <GlassButton variant={activeTab === 'wizard' ? 'primary' : 'secondary'} onClick={() => setActiveTab('wizard')}>
            <SetupWizardIcon size={18} />
            {isAr ? 'معالج الإعداد التفاعلي' : 'Setup Wizard'}
          </GlassButton>
          <GlassButton variant={activeTab === 'monitor' ? 'primary' : 'secondary'} onClick={() => setActiveTab('monitor')}>
            <DiagnosticsIcon size={18} />
            {isAr ? 'مراقب حالة الاتصال' : 'Connection Monitor'}
          </GlassButton>
        </div>
      </div>

      {activeTab === 'hub' && (
        <>
          <GlassCard className="space-y-2.5 text-xs">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="font-extrabold text-ice-crystal">
                {isAr ? 'حالة النقل إلى OBS / TikTok LIVE Studio:' : 'Cross-Process Overlay Transport Status:'}
              </span>
              <GlassBadge tone={relayCfg.relayUrl ? 'emerald' : 'amber'}>
                {relayCfg.relayUrl
                  ? isAr ? 'خادم Relay مُعدّ (عبر المتصفحات)' : 'Relay Configured (Cross-Process)'
                  : isAr ? 'معاينة فقط – لا يصل إلى OBS بدون رابط Relay' : 'Preview only – not reaching OBS until Relay URL is set'}
              </GlassBadge>
            </div>
            <div className="grid gap-2 sm:grid-cols-3">
              <input
                value={relayCfg.relayUrl}
                onChange={(e) => {
                  const next = { ...relayCfg, relayUrl: e.target.value };
                  setRelayCfg(next);
                  saveRelayConfig(next);
                }}
                placeholder="https://dznova-ice-aurora-relay.yourname.workers.dev"
                className="sm:col-span-2 rounded-xl border border-ice-crystal/25 bg-ice-midnight/75 px-3 py-2 font-mono text-[11px] text-ice-white"
              />
              <input
                value={relayCfg.roomId}
                onChange={(e) => {
                  const next = { ...relayCfg, roomId: e.target.value };
                  setRelayCfg(next);
                  saveRelayConfig(next);
                }}
                placeholder="Room ID"
                className="rounded-xl border border-ice-crystal/25 bg-ice-midnight/75 px-3 py-2 font-mono text-[11px] text-ice-white"
              />
            </div>
          </GlassCard>
          <GlassCard className="flex flex-wrap items-center justify-between gap-3">
            <span className="text-sm font-bold">
              {isAr ? 'اختر الأوفرلاي المراد توليده للمنصتين:' : 'Select Overlay to Configure Across Platforms:'}
            </span>
            <div className="flex flex-wrap gap-2">
              {OVERLAY_OPTIONS.map((o) => {
                const OvIcon = o.Icon;
                return (
                  <GlassButton
                    key={o.id}
                    size="sm"
                    variant={selectedOverlay === o.id ? 'primary' : 'secondary'}
                    onClick={() => setSelectedOverlay(o.id)}
                  >
                    <OvIcon size={18} />
                    <span>{isAr ? o.labelAr : o.labelEn}</span>
                  </GlassButton>
                );
              })}
            </div>
          </GlassCard>

          <div className="grid gap-6 lg:grid-cols-2">
            {renderPlatformCard('tiktok_live_studio')}
            {renderPlatformCard('obs_studio')}
          </div>
        </>
      )}

      {activeTab === 'wizard' && (
        <GlassCard className="space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <SetupWizardIcon size={36} />
              <div>
                <h2 className="text-xl font-extrabold">
                  {isAr ? 'معالج إعداد البث التفاعلي (يحفظ تقدمك تلقائياً)' : 'Interactive Streaming Setup Wizard (Auto-Saved)'}
                </h2>
                <p className="text-xs opacity-75">
                  {isAr ? `الخطوة ${wizard.step} من 5 — يمكنك العودة لتعديل الإعدادات في أي وقت.` : `Step ${wizard.step} of 5 — progress is saved so you can return anytime.`}
                </p>
              </div>
            </div>
            <GlassButton size="sm" variant="ghost" onClick={resetWizard}>
              {isAr ? 'إعادة ضبط المعالج' : 'Reset Wizard'}
            </GlassButton>
          </div>

          <div className="grid grid-cols-5 gap-2">
            {[1, 2, 3, 4, 5].map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => updateWizard({ step: s })}
                className={`rounded-xl py-2 text-xs font-bold transition ${
                  wizard.step === s
                    ? 'ice-btn-primary'
                    : wizard.step > s
                      ? 'bg-emerald-400/20 text-emerald-300 border border-emerald-400/35'
                      : 'ice-glass opacity-65'
                }`}
              >
                {s}. {['Platform', 'Overlays', 'Resolution', 'URLs & Test', 'Verify'][s - 1]}
              </button>
            ))}
          </div>

          {wizard.step === 1 && (
            <div className="grid gap-4 md:grid-cols-3">
              {(
                [
                  { id: 'tiktok_live_studio', label: 'TikTok LIVE Studio' },
                  { id: 'obs_studio', label: 'OBS Studio' },
                  { id: 'both', label: isAr ? 'كلا المنصتين (TikTok + OBS)' : 'Both Platforms (TikTok + OBS)' },
                ] as const
              ).map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => updateWizard({ target: opt.id })}
                  className={`rounded-2xl border p-5 text-start transition ${
                    wizard.target === opt.id
                      ? 'border-ice-glacier bg-ice-glacier/15'
                      : 'border-ice-crystal/20 bg-ice-midnight/40'
                  }`}
                >
                  <p className="text-base font-extrabold">{opt.label}</p>
                  <p className="mt-1 text-xs opacity-75">
                    {isAr ? 'مُهيأ بمحرك شفافية موحد بدون WebGL.' : 'Configured with unified zero-WebGL transparent overlays.'}
                  </p>
                </button>
              ))}
            </div>
          )}

          {wizard.step === 2 && (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {OVERLAY_OPTIONS.map((o) => {
                const checked = wizard.selectedOverlays.includes(o.id);
                return (
                  <button
                    key={o.id}
                    type="button"
                    onClick={() => {
                      const next = checked
                        ? wizard.selectedOverlays.filter((x) => x !== o.id)
                        : [...wizard.selectedOverlays, o.id];
                      updateWizard({ selectedOverlays: next.length ? next : ['alerts'] });
                    }}
                    className={`rounded-xl border p-4 text-start text-sm font-bold ${
                      checked ? 'border-ice-glacier bg-ice-glacier/15' : 'border-ice-crystal/20 bg-ice-midnight/40'
                    }`}
                  >
                    {isAr ? o.labelAr : o.labelEn}
                  </button>
                );
              })}
            </div>
          )}

          {wizard.step === 3 && (
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <p className="text-sm font-bold">{isAr ? 'اختر الدقة:' : 'Choose Resolution:'}</p>
                {RESOLUTIONS.map((r) => (
                  <button
                    key={r.label}
                    type="button"
                    onClick={() => updateWizard({ resolution: r })}
                    className={`block w-full rounded-xl border px-4 py-3 text-start text-sm font-semibold ${
                      wizard.resolution.label === r.label
                        ? 'border-ice-glacier bg-ice-glacier/15'
                        : 'border-ice-crystal/20 bg-ice-midnight/40'
                    }`}
                  >
                    {r.label}
                  </button>
                ))}
              </div>
              <div className="space-y-2">
                <p className="text-sm font-bold">{isAr ? 'ملف التوافق:' : 'Compatibility Profile:'}</p>
                {Object.values(COMPATIBILITY_PROFILES).map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => updateWizard({ profile: p.id })}
                    className={`block w-full rounded-xl border px-4 py-3 text-start text-xs ${
                      wizard.profile === p.id
                        ? 'border-ice-glacier bg-ice-glacier/15'
                        : 'border-ice-crystal/20 bg-ice-midnight/40'
                    }`}
                  >
                    <p className="font-bold">{isAr ? p.nameAr : p.nameEn}</p>
                    <p className="opacity-75">{isAr ? p.notesAr : p.notesEn}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {wizard.step === 4 && (
            <div className="space-y-4">
              <div className="flex flex-wrap gap-3">
                <GlassButton
                  variant="primary"
                  onClick={() => {
                    const targets: StreamingPlatformId[] =
                      wizard.target === 'both' ? ['tiktok_live_studio', 'obs_studio'] : [wizard.target];
                    const nextMap = { ...wizard.generatedTokens };
                    targets.forEach((plat) => {
                      wizard.selectedOverlays.forEach((ov) => {
                        const rec = generateToken({
                          overlayType: ov,
                          platform: plat,
                          profile: wizard.profile,
                          width: wizard.resolution.width,
                          height: wizard.resolution.height,
                        });
                        nextMap[`${plat}:${ov}`] = buildOverlayUrl(baseUrl, rec);
                      });
                    });
                    updateWizard({ generatedTokens: nextMap });
                    pushToast(isAr ? 'تم توليد جميع روابط المعالج' : 'All wizard URLs generated', undefined, 'emerald');
                  }}
                >
                  {isAr ? 'توليد جميع الروابط الآمنة' : 'Generate All Secure URLs'}
                </GlassButton>
                <GlassButton
                  onClick={() => {
                    triggerMockGift(wizard.target === 'both' ? 'all' : wizard.target);
                    updateWizard({ testEventSent: true });
                  }}
                >
                  {t(lang, 'sendTestEvent')}
                </GlassButton>
              </div>
              <div className="space-y-2">
                {Object.entries(wizard.generatedTokens).map(([key, url]) => (
                  <div key={key} className="flex flex-wrap items-center gap-2 rounded-xl border border-ice-crystal/20 bg-ice-midnight/50 p-3">
                    <GlassBadge tone="cyan">{key}</GlassBadge>
                    <input readOnly value={url} className="min-w-[200px] flex-1 bg-transparent font-mono text-[11px] text-ice-glacier" />
                    <GlassButton size="sm" onClick={() => void handleCopy(key, url)}>
                      {copiedId === key ? t(lang, 'copied') : t(lang, 'copyUrl')}
                    </GlassButton>
                    <GlassButton
                      size="sm"
                      onClick={() => handleOpenPreview(key.startsWith('obs') ? 'obs_studio' : 'tiktok_live_studio', url)}
                    >
                      {t(lang, 'openPreview')}
                    </GlassButton>
                  </div>
                ))}
              </div>
            </div>
          )}

          {wizard.step === 5 && (
            <div className="space-y-4">
              <p className="text-sm">
                {isAr
                  ? 'تحقق من الحالة الفعلية لكل منصة أدناه. لن يُعلّم التكامل كـ "موثّق" إلا بعد فتح الرابط واستقبال حدث اختباري فعلي.'
                  : 'Review real verification status below. Integration is marked Verified only after both Browser Source load heartbeat and event receipt are confirmed.'}
              </p>
              <div className="grid gap-4 md:grid-cols-2">
                {(['tiktok_live_studio', 'obs_studio'] as StreamingPlatformId[]).map((p) => (
                  <div key={p} className="rounded-xl border border-ice-crystal/20 bg-ice-midnight/45 p-4">
                    <div className="flex items-center justify-between">
                      <span className="font-bold">{p === 'tiktok_live_studio' ? 'TikTok LIVE Studio' : 'OBS Studio'}</span>
                      <GlassBadge tone={stageBadgeTone(platforms[p].stage)}>{stageLabel(lang, platforms[p].stage)}</GlassBadge>
                    </div>
                  </div>
                ))}
              </div>
              <GlassButton
                variant="primary"
                onClick={() => {
                  updateWizard({ completed: true });
                  pushToast(isAr ? 'تم حفظ إعدادات المعالج بنجاح' : 'Setup progress saved', undefined, 'emerald');
                }}
              >
                {isAr ? 'حفظ وإنهاء المعالج' : 'Save & Complete Setup'}
              </GlassButton>
            </div>
          )}

          <div className="flex justify-between pt-2">
            <GlassButton disabled={wizard.step <= 1} onClick={() => updateWizard({ step: wizard.step - 1 })}>
              {isAr ? 'السابق' : 'Previous'}
            </GlassButton>
            <GlassButton variant="primary" disabled={wizard.step >= 5} onClick={() => updateWizard({ step: wizard.step + 1 })}>
              {isAr ? 'التالي' : 'Next'}
            </GlassButton>
          </div>
        </GlassCard>
      )}

      {activeTab === 'monitor' && (
        <div className="grid gap-6 md:grid-cols-2">
          {(['tiktok_live_studio', 'obs_studio'] as StreamingPlatformId[]).map((pid) => {
            const st = platforms[pid];
            return (
              <GlassCard key={pid} className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-extrabold">
                    {pid === 'tiktok_live_studio' ? 'TikTok LIVE Studio' : 'OBS Studio'}
                  </h3>
                  <GlassBadge tone={stageBadgeTone(st.stage)}>{stageLabel(lang, st.stage)}</GlassBadge>
                </div>
                <dl className="grid grid-cols-2 gap-2 text-xs">
                  <div className="rounded-xl bg-ice-midnight/45 p-3">
                    <dt className="opacity-65">{isAr ? 'حالة Browser Source' : 'Browser Source'}</dt>
                    <dd className="mt-1 font-bold text-ice-glacier">
                      {st.browserSourceLoadedAt ? (isAr ? 'مُحمّل (Heartbeat نشط)' : 'Loaded (Heartbeat active)') : isAr ? 'لم يتم رصد تحميل' : 'Not detected yet'}
                    </dd>
                  </div>
                  <div className="rounded-xl bg-ice-midnight/45 p-3">
                    <dt className="opacity-65">{isAr ? 'حالة مصدر الأحداث' : 'Event Source'}</dt>
                    <dd className="mt-1 font-bold text-ice-nebula">
                      {st.eventSourceActive ? (isAr ? 'يستقبل الأحداث' : 'Receiving Events') : isAr ? 'في انتظار حدث' : 'Idle / Awaiting Events'}
                    </dd>
                  </div>
                  <div className="rounded-xl bg-ice-midnight/45 p-3">
                    <dt className="opacity-65">{isAr ? 'آخر حدث مستلم' : 'Last Received Event'}</dt>
                    <dd className="mt-1 font-semibold">{st.lastEventSummary ?? '—'}</dd>
                  </div>
                  <div className="rounded-xl bg-ice-midnight/45 p-3">
                    <dt className="opacity-65">{isAr ? 'آخر فحص' : 'Last Check'}</dt>
                    <dd className="mt-1 font-semibold">
                      {st.lastCheckAt ? new Date(st.lastCheckAt).toLocaleTimeString() : '—'}
                    </dd>
                  </div>
                </dl>
                {st.errors.length > 0 && (
                  <div className="rounded-xl border border-amber-400/35 bg-amber-400/10 p-3 text-xs text-amber-200">
                    {st.errors.map((err, i) => (
                      <p key={i}>• {err}</p>
                    ))}
                  </div>
                )}
                <div className="flex flex-wrap gap-2">
                  <GlassButton size="sm" variant="primary" onClick={() => runPlatformCheck(pid)}>
                    {isAr ? 'تشغيل فحص التشخيص' : 'Run Diagnostics'}
                  </GlassButton>
                  <GlassButton size="sm" onClick={() => triggerMockGift(pid)}>
                    {t(lang, 'sendTestEvent')}
                  </GlassButton>
                </div>
              </GlassCard>
            );
          })}
        </div>
      )}
    </div>
  );
};
