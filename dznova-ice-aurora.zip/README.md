# DZNOVA — ICE AURORA EDITION (v3.1.0)

**Two Streaming Platforms. One Intelligent Streaming Ecosystem.**

DZNOVA Ice Aurora Edition is a unified live streaming control center for **TikTok LIVE Studio** and **OBS Studio**, available as a **Web Platform**, a **Tauri v2 Windows Desktop Companion**, and a **Capacitor Android APK**.

## OBS Studio & TikTok LIVE Studio Audio Setup
1. Add your generated DZNOVA overlay URL as a **Browser Source** (`1920×1080`, 60 FPS).
2. In OBS Studio, enable **"Control audio via OBS"** so sounds and TTS appear in your OBS Audio Mixer.
3. Click **Interact** on the OBS Browser Source once and click **"Enable Overlay Sound"** to unlock Chromium autoplay if needed.
4. For cross-process live control (sending events/sounds from Chrome or your Android phone to OBS Studio / TikTok LIVE Studio), deploy the `/server` Cloudflare Worker and enter its URL in **Streaming Platforms → Overlay Transport**.

## Building the Android APK
### Automatically via GitHub Actions (Recommended)
Push `dznova-ice-aurora.zip` to `main` — the `build_android_apk` job in `.github/workflows/deploy.yml` runs JDK 17 + Android SDK + `npx cap add android` + `scripts/apply-android-native.mjs` + `./gradlew assembleDebug` and uploads `DZNOVA-Ice-Aurora.apk`.
- Optional Release Signing: add GitHub Secrets `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`.

### Locally
```bash
npm install
npm run build
npx cap add android
node scripts/apply-android-native.mjs
npx cap sync android
cd android && ./gradlew assembleDebug
```
