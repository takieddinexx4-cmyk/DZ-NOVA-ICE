import { sharedAudioEngine } from './audio/AudioEngine';
import { playSoundById } from './audio/SoundLibrary';
import { sharedTtsManager } from './tts/TtsManager';
import type { VoicePresetId } from './tts/types';

export type QueuePriority = 1 | 2 | 3 | 4; // 4 = legendary/big gift, 3 = small gift, 2 = follow/system, 1 = chat

export interface QueuedAudioItem {
  id: string;
  kind: 'sound' | 'tts' | 'sound+tts';
  priority: QueuePriority;
  mergeKey?: string;
  count?: number;
  soundId?: string;
  soundVolume?: number;
  trimStartSec?: number;
  trimEndSec?: number;
  fadeInSec?: number;
  fadeOutSec?: number;
  text?: string;
  lang?: string;
  presetId?: VoicePresetId;
  rate?: number;
  pitch?: number;
  volume?: number;
}

export interface AudioQueueSnapshot {
  playing: boolean;
  currentLabel: string | null;
  pendingCount: number;
  muted: boolean;
}

const MAX_QUEUE_SIZE = 20;

/**
 * Priority AudioQueue supporting:
 * - Priority ordering (big gift > small gift > follow/system > chat)
 * - Merging rapid identical events (e.g. "Rose x5")
 * - Smart dropping of lowest-priority items when queue is full
 * - Automatic SFX ducking while TTS speaks
 * - Skip-current control
 */
export class AudioQueue {
  private queue: QueuedAudioItem[] = [];
  private playing = false;
  private muted = false;
  private currentItem: QueuedAudioItem | null = null;
  private listeners: Set<(snap: AudioQueueSnapshot) => void> = new Set();

  public subscribe(fn: (snap: AudioQueueSnapshot) => void): () => void {
    this.listeners.add(fn);
    fn(this.getSnapshot());
    return () => {
      this.listeners.delete(fn);
    };
  }

  public getSnapshot(): AudioQueueSnapshot {
    return {
      playing: this.playing,
      currentLabel: this.currentItem
        ? this.currentItem.text || this.currentItem.soundId || this.currentItem.kind
        : null,
      pendingCount: this.queue.length,
      muted: this.muted,
    };
  }

  private notify(): void {
    const snap = this.getSnapshot();
    this.listeners.forEach((fn) => fn(snap));
  }

  public setMuted(muted: boolean): void {
    this.muted = muted;
    if (muted) this.clear();
    this.notify();
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public getPendingCount(): number {
    return this.queue.length;
  }

  public getQueueItems(): QueuedAudioItem[] {
    return [...this.queue];
  }

  public enqueue(item: QueuedAudioItem, autoDrain = true): void {
    if (this.muted) return;

    // 1. Merge rapid identical events waiting in queue (e.g. "Rose x5")
    if (item.mergeKey) {
      const existing = this.queue.find((q) => q.mergeKey === item.mergeKey);
      if (existing) {
        existing.count = (existing.count ?? 1) + (item.count ?? 1);
        if (existing.text) {
          existing.text = existing.text.replace(/\s*x\d+$/i, '') + ` x${existing.count}`;
        }
        existing.priority = Math.max(existing.priority, item.priority) as QueuePriority;
        this.sortQueue();
        this.notify();
        return;
      }
    }

    // 2. Smart drop lowest-priority item if queue is full
    if (this.queue.length >= MAX_QUEUE_SIZE) {
      let lowestIdx = this.queue.length - 1;
      for (let i = this.queue.length - 1; i >= 0; i -= 1) {
        if (this.queue[i].priority <= this.queue[lowestIdx].priority) {
          lowestIdx = i;
        }
      }
      if (this.queue[lowestIdx].priority <= item.priority) {
        this.queue.splice(lowestIdx, 1);
      } else {
        return; // Incoming item has lower priority than everything queued
      }
    }

    this.queue.push({ ...item, count: item.count ?? 1 });
    this.sortQueue();
    this.notify();

    if (autoDrain) {
      void this.drain();
    }
  }

  private sortQueue(): void {
    this.queue.sort((a, b) => b.priority - a.priority);
  }

  public skipCurrent(): void {
    sharedTtsManager.cancel();
    sharedAudioEngine.setDucking(false);
    this.currentItem = null;
    this.playing = false;
    this.notify();
    if (this.queue.length > 0) {
      void this.drain();
    }
  }

  public clear(): void {
    this.queue = [];
    this.currentItem = null;
    this.playing = false;
    sharedTtsManager.cancel();
    sharedAudioEngine.setDucking(false);
    this.notify();
  }

  private async drain(): Promise<void> {
    if (this.playing || this.queue.length === 0) return;
    this.playing = true;
    const item = this.queue.shift() ?? null;
    this.currentItem = item;
    this.notify();

    if (!item) {
      this.playing = false;
      this.notify();
      return;
    }

    try {
      if ((item.kind === 'sound' || item.kind === 'sound+tts') && item.soundId) {
        await playSoundById(item.soundId, {
          volume: item.soundVolume ?? 0.8,
          trimStartSec: item.trimStartSec,
          trimEndSec: item.trimEndSec,
          fadeInSec: item.fadeInSec,
          fadeOutSec: item.fadeOutSec,
        });
      }
      if ((item.kind === 'tts' || item.kind === 'sound+tts') && item.text) {
        sharedAudioEngine.setDucking(true);
        try {
          await sharedTtsManager.speak(item.text, {
            lang: item.lang,
            presetId: item.presetId,
            rate: item.rate,
            pitch: item.pitch,
            volume: item.volume,
          });
        } finally {
          sharedAudioEngine.setDucking(false);
        }
      }
    } catch {
      sharedAudioEngine.setDucking(false);
    } finally {
      this.currentItem = null;
      this.playing = false;
      this.notify();
      if (this.queue.length > 0) {
        void this.drain();
      }
    }
  }
}

export const sharedAudioQueue = new AudioQueue();
