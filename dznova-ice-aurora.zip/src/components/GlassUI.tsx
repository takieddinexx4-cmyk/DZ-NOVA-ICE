import React from 'react';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  interactive?: boolean;
}

export const GlassCard: React.FC<GlassCardProps> = ({
  children,
  className = '',
  interactive = false,
}) => (
  <div
    className={`ice-glass rounded-2xl p-5 ${interactive ? 'ice-card-interactive' : ''} ${className}`}
  >
    {children}
  </div>
);

interface GlassButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
}

export const GlassButton: React.FC<GlassButtonProps> = ({
  variant = 'secondary',
  size = 'md',
  className = '',
  children,
  ...rest
}) => {
  const sizeCls =
    size === 'sm'
      ? 'px-3 py-1.5 text-xs rounded-xl'
      : size === 'lg'
        ? 'px-6 py-3 text-base rounded-2xl'
        : 'px-4 py-2 text-sm rounded-xl';

  const variantCls =
    variant === 'primary'
      ? 'ice-btn-primary'
      : variant === 'danger'
        ? 'bg-rose-500/25 border border-rose-400/50 text-rose-100 hover:bg-rose-500/35 shadow-md'
        : variant === 'ghost'
          ? 'ice-pill opacity-90 hover:opacity-100 text-current'
          : 'ice-pill text-current';

  return (
    <button
      type="button"
      className={`inline-flex items-center justify-center gap-2 font-bold transition-all disabled:opacity-45 disabled:cursor-not-allowed ${sizeCls} ${variantCls} ${className}`}
      {...rest}
    >
      {children}
    </button>
  );
};

export const GlassBadge: React.FC<{
  children: React.ReactNode;
  tone?: 'cyan' | 'violet' | 'emerald' | 'amber' | 'rose' | 'neutral';
  className?: string;
}> = ({ children, tone = 'cyan', className = '' }) => {
  const tones: Record<string, string> = {
    cyan: 'bg-ice-glacier/20 border-ice-glacier/50 text-ice-glacier',
    violet: 'bg-ice-nebula/20 border-ice-nebula/50 text-ice-nebula',
    emerald: 'bg-emerald-400/20 border-emerald-400/50 text-emerald-200',
    amber: 'bg-amber-400/20 border-amber-400/50 text-amber-200',
    rose: 'bg-rose-400/20 border-rose-400/50 text-rose-200',
    neutral: 'bg-ice-crystal/15 border-ice-crystal/35 text-ice-silver',
  };
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-bold shadow-sm ${tones[tone]} ${className}`}
    >
      {children}
    </span>
  );
};
