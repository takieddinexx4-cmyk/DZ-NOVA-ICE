import React, { useEffect, useMemo, useState } from 'react';
import type {
  CompatibilityProfileId,
  LiveEventPayload,
  OverlayTokenRecord,
  OverlayType,
  StreamingPlatformId,
} from '../types/dznova';
import {
  COMPATIBILITY_PROFILES,
  STORAGE_TOKENS_KEY,
  broadcastOverlayMessage,
  isTokenValid,
  subscribeOverlayBus,
} from '../engine/OverlayEngine';
import { sharedAudioQueue } from '../engine/AudioQueue';
import { DznovaLogo } from '../components/DznovaLogo';

interface OverlayRendererProps {
  overlayType: OverlayType;
  queryString: string;
}

export const OverlayRenderer: React.FC<OverlayRendererProps> = ({ overlayType, queryString }) => {
  const params = useMemo(() => new URLSearchParams(queryString), [queryString]);
  const token = params.get('token');
  const platform = (params.get('platform') as StreamingPlatformId) || 'obs_studio';
  const profileId = (params.get('profile') as CompatibilityProfileId) || 'obs_standard';
  const profile = COMPATIBILITY_PROFILES[profileId] ?? COMPATIBILITY_PROFILES.obs_standard;

  const [revoked, setRevoked] = useState<boolean>(false);
  const [connectedBus, setConnectedBus] = useState<boolean>(true);
  const [recentEvents, setRecentEvents] = useState<LiveEventPayload[]>([]);
  const [activeAlert, setActiveAlert] = useState<LiveEventPayload | null>(null);
  const [goalProgress, setGoalProgress] = useState<number>(640);
  const [secondsLeft, setSecondsLeft] = useState<number>(300);
  const [wheelAngle, setWheelAngle] = useState<number>(0);
  const [viewportScale, setViewportScale] = useState<number>(1);
  const [wilayaBoard, setWilayaBoard] = useState<Record<string, number>>({
    '16': 1420,
    '31': 1290,
    '18': 1180,
    '25': 960,
  });

  // Enforce 100% transparent background for OBS & TikTok LIVE Studio
  useEffect(() => {
    document.documentElement.classList.add('overlay-transparent');
    document.body.classList.add('overlay-transparent');
    const updateScale = () => {
      const sx = window.innerWidth / 1920;
      const sy = window.innerHeight / 1080;
      setViewportScale(Math.min(sx, sy));
    };
    updateScale();
    window.addEventListener('resize', updateScale);
    return () => {
      document.documentElement.classList.remove('overlay-transparent');
      document.body.classList.remove('overlay-transparent');
      window.removeEventListener('resize', updateScale);
    };
  }, []);

  // Validate token on mount
  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_TOKENS_KEY);
      const records = stored ? (JSON.parse(stored) as OverlayTokenRecord[]) : [];
      if (token && !isTokenValid(records, token)) {
        setRevoked(true);
      }
    } catch {
      // Allow isolated preview if storage is blocked
    }
  }, [token]);

  // Send genuine live heartbeat every 3.5s so the dashboard honestly knows Browser Source loaded
  useEffect(() => {
    if (revoked) return;
    const sendHeartbeat = () => {
      broadcastOverlayMessage({
        kind: 'heartbeat',
        payload: { platform, overlayType, profile: profileId, ts: Date.now() },
      });
    };
    sendHeartbeat();
    const timer = setInterval(sendHeartbeat, 3500);
    return () => clearInterval(timer);
  }, [overlayType, platform, profileId, revoked]);

  // Countdown tick
  useEffect(() => {
    if (overlayType !== 'countdown') return;
    const id = setInterval(() => setSecondsLeft((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => clearInterval(id);
  }, [overlayType]);

  // Subscribe to real-time events & token revocation
  useEffect(() => {
    const unsub = subscribeOverlayBus((msg) => {
      setConnectedBus(true);
      if (msg.kind === 'token_revoked' && msg.payload && typeof msg.payload === 'object') {
        const revokedTok = (msg.payload as { token?: string }).token;
        if (revokedTok && revokedTok === token) {
          setRevoked(true);
        }
        return;
      }
      if (msg.kind === 'event' && msg.payload && typeof msg.payload === 'object') {
        const ev = msg.payload as LiveEventPayload;
        if (ev.targetPlatform !== 'all' && ev.targetPlatform !== platform) return;
        setRecentEvents((prev) => [ev, ...prev].slice(0, 12));
        if (ev.type === 'gift' || ev.type === 'follow') {
          setActiveAlert(ev);
          sharedAudioQueue.enqueue({ id: ev.id, kind: 'tone', frequency: 720, durationMs: 220 });
          setTimeout(() => setActiveAlert(null), 4600);
        }
        if (ev.type === 'gift') {
          const coins = ev.coins ?? 50;
          setGoalProgress((g) => g + coins);
          setWheelAngle((a) => a + 360 + Math.floor(Math.random() * 240));
          if (ev.wilayaCode) {
            setWilayaBoard((prev) => ({
              ...prev,
              [ev.wilayaCode as string]: (prev[ev.wilayaCode as string] ?? 0) + coins,
            }));
          }
        }
      }
    });
    return unsub;
  }, [platform, token]);

  const cardSurface = profile.useBackdropBlur
    ? 'bg-[#091526]/70 backdrop-blur-xl border border-[#A9E5FF]/40 shadow-[0_18px_45px_rgba(9,21,38,0.65)]'
    : 'bg-[#091526]/90 border border-[#58DDF5]/45 shadow-lg';

  if (revoked) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-transparent p-8">
        <div className="rounded-2xl border border-rose-400/50 bg-[#091526]/95 px-8 py-6 text-center text-[#F3FAFF]">
          <p className="text-lg font-bold text-rose-300">DZNOVA Security — Token Revoked</p>
          <p className="mt-2 text-sm text-[#D8E7F2]">
            Generate a new Browser Source URL from /app/streaming-platforms.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-transparent">
      <div
        style={{
          width: 1920,
          height: 1080,
          transform: `scale(${viewportScale})`,
          transformOrigin: 'top left',
        }}
        className="relative bg-transparent p-14 text-[#F3FAFF]"
      >
        {!connectedBus && (
          <div className="absolute right-8 top-8 rounded-full border border-amber-400/50 bg-[#091526]/90 px-4 py-1.5 text-sm text-amber-300">
            Reconnecting to DZNOVA Bus...
          </div>
        )}

        {overlayType === 'alerts' && (
          <div className="flex h-full items-start justify-center pt-10">
            {activeAlert ? (
              <div className={`rounded-3xl px-12 py-8 text-center transition-all ${cardSurface}`}>
                <div className="mb-3 flex items-center justify-center gap-3">
                  <DznovaLogo variant="symbol" size={44} />
                  <span className="text-sm font-bold uppercase tracking-[0.26em] text-[#58DDF5]">
                    DZNOVA {activeAlert.type}
                  </span>
                </div>
                <p className="text-4xl font-extrabold text-[#F3FAFF]">{activeAlert.username}</p>
                <p className="mt-2 text-2xl font-semibold text-[#A9E5FF]">
                  {activeAlert.giftName
                    ? `${activeAlert.giftName} • ${activeAlert.coins ?? 0} Coins`
                    : activeAlert.message ?? 'New Live Event!'}
                </p>
              </div>
            ) : (
              <div className={`rounded-2xl px-6 py-3 text-sm text-[#A9E5FF]/80 ${cardSurface}`}>
                DZNOVA Alerts Ready ({platform === 'tiktok_live_studio' ? 'TikTok LIVE Studio' : 'OBS Studio'} • {profile.nameEn})
              </div>
            )}
          </div>
        )}

        {overlayType === 'goal' && (
          <div className="flex h-full items-end justify-center pb-12">
            <div className={`w-[780px] rounded-3xl p-7 ${cardSurface}`}>
              <div className="mb-3 flex items-center justify-between text-xl font-bold">
                <span>Ice Aurora Stream Goal</span>
                <span className="text-[#58DDF5]">{goalProgress} / 2000 Coins</span>
              </div>
              <div className="h-6 w-full overflow-hidden rounded-full bg-[#101D35]">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-[#58DDF5] via-[#408DFF] to-[#9477FF] transition-all duration-500"
                  style={{ width: `${Math.min(100, (goalProgress / 2000) * 100)}%` }}
                />
              </div>
            </div>
          </div>
        )}

        {overlayType === 'wilaya' && (
          <div className={`w-[560px] rounded-3xl p-7 ${cardSurface}`}>
            <div className="mb-4 flex items-center justify-between">
              <span className="text-2xl font-extrabold text-[#F3FAFF]">تحدي الولايات — Wilaya Battle</span>
              <span className="rounded-full bg-[#58DDF5]/20 px-3 py-1 text-sm font-bold text-[#58DDF5]">LIVE</span>
            </div>
            <div className="space-y-3">
              {Object.entries(wilayaBoard)
                .sort((a, b) => b[1] - a[1])
                .map(([code, pts], idx) => (
                  <div key={code} className="flex items-center justify-between rounded-2xl bg-[#101D35]/80 px-5 py-3">
                    <span className="text-lg font-bold">#{idx + 1} • Wilaya {code}</span>
                    <span className="font-mono text-xl font-extrabold text-[#58DDF5]">{pts} pts</span>
                  </div>
                ))}
            </div>
          </div>
        )}

        {overlayType === 'chat' && (
          <div className={`ml-auto w-[540px] rounded-3xl p-6 ${cardSurface}`}>
            <p className="mb-4 text-sm font-bold uppercase tracking-[0.22em] text-[#58DDF5]">DZNOVA Live Chat</p>
            <div className="space-y-2.5">
              {recentEvents.length === 0 ? (
                <p className="text-base text-[#D8E7F2]/80">Waiting for live messages or MockLiveSource events...</p>
              ) : (
                recentEvents.slice(0, 6).map((ev) => (
                  <div key={ev.id} className="rounded-xl bg-[#101D35]/80 px-4 py-2.5 text-base">
                    <span className="font-bold text-[#58DDF5]">{ev.username}: </span>
                    <span className="text-[#F3FAFF]">{ev.message ?? ev.giftName ?? ev.type}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {overlayType === 'wheel' && (
          <div className="flex h-full items-center justify-center">
            <div className={`flex flex-col items-center rounded-3xl p-10 ${cardSurface}`}>
              <div
                className="flex h-72 w-72 items-center justify-center rounded-full border-8 border-[#58DDF5] bg-gradient-to-tr from-[#091526] via-[#408DFF]/40 to-[#9477FF]/50 transition-transform duration-1000"
                style={{ transform: `rotate(${wheelAngle}deg)` }}
              >
                <span className="text-2xl font-extrabold text-[#F3FAFF]">DZNOVA WHEEL</span>
              </div>
              <p className="mt-5 text-lg text-[#A9E5FF]">Triggers automatically on incoming gifts</p>
            </div>
          </div>
        )}

        {overlayType === 'countdown' && (
          <div className="flex h-full items-center justify-center">
            <div className={`rounded-3xl px-14 py-9 text-center ${cardSurface}`}>
              <p className="text-lg font-semibold uppercase tracking-[0.24em] text-[#A9E5FF]">Stream Countdown</p>
              <p className="mt-2 font-mono text-7xl font-extrabold text-[#F3FAFF]">
                {String(Math.floor(secondsLeft / 60)).padStart(2, '0')}:{String(secondsLeft % 60).padStart(2, '0')}
              </p>
            </div>
          </div>
        )}

        {overlayType === 'leaderboard' && (
          <div className={`w-[520px] rounded-3xl p-7 ${cardSurface}`}>
            <p className="mb-4 text-2xl font-extrabold">Top Supporters</p>
            <div className="space-y-3">
              {['Amine_DZ16 • 2,400', 'Yasmine_Oran31 • 1,850', 'Karim_Jijel18 • 1,320'].map((row, idx) => (
                <div key={row} className="flex items-center justify-between rounded-xl bg-[#101D35]/80 px-4 py-3 text-lg">
                  <span>#{idx + 1} {row.split(' • ')[0]}</span>
                  <span className="font-mono font-bold text-[#58DDF5]">{row.split(' • ')[1]}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
