import { DEFAULT_PRONUNCIATION_DICT, normalizeArabicText } from './arabicText';
import { CloudNeuralProvider } from './CloudNeuralProvider';
import { NativeAndroidProvider } from './NativeAndroidProvider';
import { WebSpeechProvider, rankArabicVoices } from './WebSpeechProvider';
import {
  VOICE_PRESETS,
  type EventTtsRule,
  type TtsDiagnostics,
  type TtsEventKind,
  type TtsSettings,
  type TtsSpeakProfile,
  type TtsVoiceInfo,
  type VoicePresetId,
} from './types';

export const TTS_SETTINGS_STORAGE_KEY = 'dznova_tts_settings_v31';

export const DEFAULT_EVENT_TTS_RULES: Record<TtsEventKind, EventTtsRule> = {
  gift: {
    eventKind: 'gift',
    enabled: true,
    presetId: 'announcer',
    volume: 1,
    rate: 1.04,
    templateArMsa: 'شكراً يا {username} على هدية {gift} بقيمة {coins} عملة!',
    templateArDz: 'يعطيك الصحة {username} على {gift}، {coins} عملة، ربي يحفظك!',
    templateEn: 'Thank you {username} for sending {gift} worth {coins} coins!',
    templateFr: 'Merci {username} pour le cadeau {gift} de {coins} pièces !',
  },
  follow: {
    eventKind: 'follow',
    enabled: true,
    presetId: 'woman',
    volume: 0.95,
    rate: 1.0,
    templateArMsa: 'مرحباً بالمتابع الجديد {username} في البث المباشر.',
    templateArDz: 'مرحبا بيك خويا {username} في البث!',
    templateEn: 'Welcome {username}, thanks for following!',
    templateFr: 'Bienvenue {username}, merci pour le suivi !',
  },
  share: {
    eventKind: 'share',
    enabled: true,
    presetId: 'young_woman',
    volume: 0.9,
    rate: 1.04,
    templateArMsa: 'شكراً يا {username} على مشاركة البث.',
    templateArDz: 'بارك الله فيك {username} على البارطاج!',
    templateEn: 'Thanks {username} for sharing the live!',
    templateFr: 'Merci {username} pour le partage !',
  },
  chat: {
    eventKind: 'chat',
    enabled: false,
    presetId: 'man',
    volume: 0.85,
    rate: 1.02,
    templateArMsa: '{username} يقول: {message}',
    templateArDz: '{username} قال: {message}',
    templateEn: '{username} says: {message}',
    templateFr: '{username} dit : {message}',
  },
  wilaya_win: {
    eventKind: 'wilaya_win',
    enabled: true,
    presetId: 'deep_man',
    volume: 1,
    rate: 0.96,
    templateArMsa: 'ولاية {wilaya} تتصدر التحدي الآن بفضل {username}!',
    templateArDz: 'تحيا ولاية {wilaya} في الصدارة بفضل {username}!',
    templateEn: 'Wilaya {wilaya} takes the lead thanks to {username}!',
    templateFr: 'La wilaya {wilaya} prend la tête grâce à {username} !',
  },
  automation: {
    eventKind: 'automation',
    enabled: true,
    presetId: 'announcer',
    volume: 1,
    rate: 1.0,
    templateArMsa: '{message}',
    templateArDz: '{message}',
    templateEn: '{message}',
    templateFr: '{message}',
  },
};

export function createDefaultTtsSettings(): TtsSettings {
  return {
    preferredProvider: 'web_speech',
    cloudProxyUrl: '',
    selectedPreset: 'woman',
    selectedVoiceId: '',
    lang: 'ar-DZ',
    dialect: 'dz',
    rate: 1.0,
    pitch: 1.04,
    volume: 1.0,
    userCooldownSec: 6,
    minGiftCoins: 10,
    maxLength: 260,
    chatReadMode: 'commands',
    blockedWords: ['spam', 'http'],
    dictionary: DEFAULT_PRONUNCIATION_DICT,
    eventRules: DEFAULT_EVENT_TTS_RULES,
  };
}

export function renderTtsTemplate(
  template: string,
  vars: Record<string, string | number | undefined>,
): string {
  return template.replace(/\{(\w+)\}/g, (_, key: string) => {
    const val = vars[key];
    return val === undefined ? '' : String(val);
  });
}

export class TtsManager {
  public readonly webSpeech = new WebSpeechProvider();
  public readonly cloudNeural = new CloudNeuralProvider();
  public readonly nativeAndroid = new NativeAndroidProvider();

  private settings: TtsSettings = createDefaultTtsSettings();
  private cachedVoices: TtsVoiceInfo[] = [];
  private lastUserSpokeAt: Map<string, number> = new Map();
  private lastError: string | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      try {
        const raw = window.localStorage.getItem(TTS_SETTINGS_STORAGE_KEY);
        if (raw) {
          const parsed = JSON.parse(raw) as Partial<TtsSettings>;
          this.settings = {
            ...createDefaultTtsSettings(),
            ...parsed,
            eventRules: {
              ...DEFAULT_EVENT_TTS_RULES,
              ...(parsed.eventRules ?? {}),
            },
          };
          if (this.settings.cloudProxyUrl) {
            this.cloudNeural.setProxyUrl(this.settings.cloudProxyUrl);
          }
        }
      } catch {
        // Use defaults
      }
    }
  }

  public getSettings(): TtsSettings {
    return this.settings;
  }

  public updateSettings(patch: Partial<TtsSettings>): TtsSettings {
    this.settings = {
      ...this.settings,
      ...patch,
      eventRules: patch.eventRules
        ? { ...this.settings.eventRules, ...patch.eventRules }
        : this.settings.eventRules,
    };
    this.cloudNeural.setProxyUrl(this.settings.cloudProxyUrl);
    if (typeof window !== 'undefined') {
      try {
        window.localStorage.setItem(TTS_SETTINGS_STORAGE_KEY, JSON.stringify(this.settings));
      } catch {
        // Ignore storage quota
      }
    }
    return this.settings;
  }

  public resolveActiveProvider() {
    if (this.settings.preferredProvider === 'native_android' && this.nativeAndroid.isAvailable()) {
      return this.nativeAndroid;
    }
    if (this.settings.preferredProvider === 'cloud_neural' && this.cloudNeural.isAvailable()) {
      return this.cloudNeural;
    }
    if (this.nativeAndroid.isAvailable()) return this.nativeAndroid;
    return this.webSpeech;
  }

  public async refreshVoices(): Promise<{ voices: TtsVoiceInfo[]; diagnostics: TtsDiagnostics }> {
    const provider = this.resolveActiveProvider();
    let voices: TtsVoiceInfo[] = [];
    this.lastError = null;
    try {
      voices = await provider.listVoices();
    } catch (err) {
      this.lastError = err instanceof Error ? err.message : 'Failed to list voices';
      voices = await this.webSpeech.listVoices();
    }

    this.cachedVoices = voices;
    const arabicVoices = rankArabicVoices(voices);
    const hasArabicVoice = arabicVoices.length > 0;

    return {
      voices,
      diagnostics: {
        activeProvider: provider.id,
        voicesCount: voices.length,
        arabicVoicesCount: arabicVoices.length,
        bestArabicVoice: arabicVoices[0]?.name ?? null,
        hasArabicVoice,
        isNeuralActive: provider.id === 'cloud_neural' && this.cloudNeural.isAvailable(),
        lastError: this.lastError,
        checkedAt: Date.now(),
      },
    };
  }

  public pickVoiceForPreset(presetId: VoicePresetId, lang: string): TtsVoiceInfo | null {
    const preset = VOICE_PRESETS[presetId];
    const isAr = lang.toLowerCase().startsWith('ar');
    const pool = isAr
      ? rankArabicVoices(this.cachedVoices)
      : this.cachedVoices.filter((v) => v.lang.toLowerCase().startsWith(lang.split('-')[0].toLowerCase()));

    if (pool.length === 0) return null;
    const genderMatch = pool.find((v) => v.gender === preset.targetGender);
    return genderMatch ?? pool[0];
  }

  public shouldSpeakForUser(username: string, rawText: string): boolean {
    const lower = rawText.toLowerCase();
    if (this.settings.blockedWords.some((w) => w.trim() && lower.includes(w.trim().toLowerCase()))) {
      return false;
    }
    const now = Date.now();
    const prev = this.lastUserSpokeAt.get(username) ?? 0;
    if (now - prev < this.settings.userCooldownSec * 1000) {
      return false;
    }
    this.lastUserSpokeAt.set(username, now);
    return true;
  }

  public async speak(
    rawText: string,
    override?: Partial<TtsSpeakProfile>,
  ): Promise<void> {
    const lang = override?.lang ?? this.settings.lang;
    const presetId = override?.presetId ?? this.settings.selectedPreset;
    const preset = VOICE_PRESETS[presetId];

    const preparedText = lang.toLowerCase().startsWith('ar')
      ? normalizeArabicText(rawText, {
          dictionary: this.settings.dictionary,
          maxLength: this.settings.maxLength,
          convertNumbers: true,
        })
      : rawText.slice(0, this.settings.maxLength).trim();

    if (!preparedText) return;

    if (this.cachedVoices.length === 0) {
      await this.refreshVoices();
    }

    const bestPresetVoice = this.pickVoiceForPreset(presetId, lang);
    const profile: TtsSpeakProfile = {
      lang,
      voiceId: override?.voiceId ?? (this.settings.selectedVoiceId || bestPresetVoice?.id),
      presetId,
      pitch: override?.pitch ?? preset.pitch ?? this.settings.pitch,
      rate: override?.rate ?? preset.rate ?? this.settings.rate,
      volume: override?.volume ?? this.settings.volume,
    };

    const arabicCount = rankArabicVoices(this.cachedVoices).length;
    let provider = this.resolveActiveProvider();

    // Auto-fallback to Cloud Neural provider if Arabic is requested and local WebSpeech has no Arabic voice
    if (
      lang.toLowerCase().startsWith('ar') &&
      provider.id === 'web_speech' &&
      arabicCount === 0 &&
      this.cloudNeural.isAvailable()
    ) {
      provider = this.cloudNeural;
    }

    try {
      await provider.speak(preparedText, profile);
      this.lastError = null;
    } catch (err) {
      this.lastError = err instanceof Error ? err.message : 'TTS playback failed';
      throw err;
    }
  }

  public cancel(): void {
    this.webSpeech.cancel();
    this.cloudNeural.cancel();
    this.nativeAndroid.cancel();
  }
}

export const sharedTtsManager = new TtsManager();
