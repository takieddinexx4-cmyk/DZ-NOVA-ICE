import { getCachedTtsAudio, putCachedTtsAudio } from '../audio/SoundDatabase';
import { sharedAudioEngine } from '../audio/AudioEngine';
import type { TtsProvider, TtsSpeakProfile, TtsVoiceInfo } from './types';

function hashKey(text: string, voiceId: string, rate: number, pitch: number): string {
  const str = `${voiceId}|${rate.toFixed(2)}|${pitch.toFixed(2)}|${text}`;
  let h = 2166136261;
  for (let i = 0; i < str.length; i += 1) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return `tts_${(h >>> 0).toString(16)}`;
}

/**
 * Optional pluggable Cloud Neural TTS adapter.
 * Calls the user-deployed Cloudflare Worker proxy (/server) — NEVER embeds API keys in client code.
 */
export class CloudNeuralProvider implements TtsProvider {
  public readonly id = 'cloud_neural' as const;
  private proxyBaseUrl = '';
  private currentSource: AudioBufferSourceNode | null = null;

  public setProxyUrl(url: string): void {
    this.proxyBaseUrl = url.trim().replace(/\/+$/, '');
  }

  public getProxyUrl(): string {
    return this.proxyBaseUrl;
  }

  public isAvailable(): boolean {
    return Boolean(this.proxyBaseUrl && /^https?:\/\//i.test(this.proxyBaseUrl));
  }

  public async listVoices(): Promise<TtsVoiceInfo[]> {
    if (!this.isAvailable()) return [];
    const res = await fetch(`${this.proxyBaseUrl}/api/tts/voices`);
    if (!res.ok) {
      throw new Error(`Cloud TTS voices request failed (${res.status})`);
    }
    const data = (await res.json()) as { voices?: TtsVoiceInfo[] };
    return (data.voices ?? []).map((v) => ({
      ...v,
      isNatural: true,
      provider: 'cloud_neural' as const,
    }));
  }

  public cancel(): void {
    if (this.currentSource) {
      try {
        this.currentSource.stop();
      } catch {
        // Ignore already stopped
      }
      this.currentSource = null;
    }
  }

  public async speak(text: string, profile: TtsSpeakProfile): Promise<void> {
    if (!this.isAvailable()) {
      throw new Error('Cloud Neural TTS proxy URL is not configured.');
    }
    const key = hashKey(text, profile.voiceId || profile.lang, profile.rate, profile.pitch);
    let audioBytes = await getCachedTtsAudio(key);

    if (!audioBytes) {
      const res = await fetch(`${this.proxyBaseUrl}/api/tts/speak`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          lang: profile.lang,
          voiceId: profile.voiceId,
          rate: profile.rate,
          pitch: profile.pitch,
        }),
      });
      if (!res.ok) {
        throw new Error(`Cloud Neural TTS synthesis failed (${res.status})`);
      }
      audioBytes = await res.arrayBuffer();
      await putCachedTtsAudio(key, audioBytes.slice(0));
    }

    await sharedAudioEngine.playArrayBuffer(audioBytes.slice(0), {
      volume: profile.volume,
      onSourceCreated: (src) => {
        this.currentSource = src;
      },
    });
    this.currentSource = null;
  }
}
