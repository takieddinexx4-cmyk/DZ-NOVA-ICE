import { broadcastOverlayMessage, subscribeOverlayBus } from './OverlayEngine';

export const RELAY_CONFIG_STORAGE_KEY = 'dznova_relay_config_v31';

export type TransportModeStatus = 'relay_connected' | 'relay_error' | 'preview_only_same_browser';

export interface RelayConfig {
  relayUrl: string;
  roomId: string;
}

export function loadRelayConfig(): RelayConfig {
  if (typeof window === 'undefined') return { relayUrl: '', roomId: 'dznova-main' };
  try {
    const raw = window.localStorage.getItem(RELAY_CONFIG_STORAGE_KEY);
    if (!raw) return { relayUrl: '', roomId: 'dznova-main' };
    const parsed = JSON.parse(raw) as Partial<RelayConfig>;
    return {
      relayUrl: (parsed.relayUrl ?? '').trim().replace(/\/+$/, ''),
      roomId: (parsed.roomId ?? 'dznova-main').trim() || 'dznova-main',
    };
  } catch {
    return { relayUrl: '', roomId: 'dznova-main' };
  }
}

export function saveRelayConfig(cfg: RelayConfig): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(RELAY_CONFIG_STORAGE_KEY, JSON.stringify(cfg));
  } catch {
    // Ignore
  }
}

export function encodeCompactOverlayConfig(cfg: Record<string, unknown>): string {
  try {
    const json = JSON.stringify(cfg);
    return btoa(unescape(encodeURIComponent(json)));
  } catch {
    return '';
  }
}

export function decodeCompactOverlayConfig<T>(encoded: string | null): T | null {
  if (!encoded) return null;
  try {
    const json = decodeURIComponent(escape(atob(encoded)));
    return JSON.parse(json) as T;
  } catch {
    return null;
  }
}

/**
 * Publishes an overlay message to BOTH:
 * 1. Same-browser BroadcastChannel + localStorage (instant local preview)
 * 2. Optional Cloudflare Worker cross-process relay (reaches OBS & TikTok LIVE Studio)
 */
export function publishOverlayTransport(
  message: {
    kind:
      | 'event'
      | 'heartbeat'
      | 'token_revoked'
      | 'config_update'
      | 'goal_update'
      | 'countdown_update'
      | 'wheel_spin'
      | 'wilaya_update'
      | 'leaderboard_update'
      | 'sound_play';
    payload: unknown;
  },
  relay?: RelayConfig,
): void {
  broadcastOverlayMessage(message);
  const cfg = relay ?? loadRelayConfig();
  if (cfg.relayUrl && /^https?:\/\//i.test(cfg.relayUrl)) {
    void fetch(`${cfg.relayUrl}/api/relay/${encodeURIComponent(cfg.roomId)}/publish`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(message),
    }).catch(() => undefined);
  }
}

export function subscribeOverlayTransport(
  onMessage: (msg: { kind: string; payload: unknown }) => void,
  relay?: RelayConfig,
  onStatusChange?: (status: TransportModeStatus) => void,
): () => void {
  const unsubLocal = subscribeOverlayBus(onMessage);
  const cfg = relay ?? loadRelayConfig();
  let es: EventSource | null = null;

  if (cfg.relayUrl && /^https?:\/\//i.test(cfg.relayUrl) && typeof EventSource !== 'undefined') {
    try {
      es = new EventSource(`${cfg.relayUrl}/api/relay/${encodeURIComponent(cfg.roomId)}/stream`);
      es.onopen = () => onStatusChange?.('relay_connected');
      es.onerror = () => onStatusChange?.('relay_error');
      es.onmessage = (ev: MessageEvent) => {
        try {
          const parsed = JSON.parse(String(ev.data)) as { kind: string; payload: unknown };
          onMessage(parsed);
        } catch {
          // Ignore malformed SSE frame
        }
      };
    } catch {
      onStatusChange?.('relay_error');
    }
  } else {
    onStatusChange?.('preview_only_same_browser');
  }

  return () => {
    unsubLocal();
    if (es) es.close();
  };
}
