import React from 'react';

interface IceAuroraBackgroundProps {
  lowEffects: boolean;
  theme: 'dark' | 'light';
}

const SNOW_PARTICLES = [
  { left: '8%', top: '12%', delay: '0s', size: 4 },
  { left: '22%', top: '28%', delay: '2.1s', size: 3 },
  { left: '38%', top: '14%', delay: '4.4s', size: 5 },
  { left: '54%', top: '22%', delay: '1.3s', size: 3 },
  { left: '68%', top: '10%', delay: '3.7s', size: 4 },
  { left: '84%', top: '18%', delay: '0.8s', size: 5 },
  { left: '92%', top: '34%', delay: '5.1s', size: 3 },
];

/**
 * Lightweight, zero-WebGL Ice Aurora atmospheric background:
 * Aurora curtains, floating clouds, translucent ice crystals, soft mist, and subtle snow particles.
 */
export const IceAuroraBackground: React.FC<IceAuroraBackgroundProps> = ({ lowEffects, theme }) => {
  const isDark = theme === 'dark';

  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 -z-10 overflow-hidden"
      style={{
        background: isDark
          ? 'radial-gradient(120% 80% at 15% 10%, rgba(64,141,255,0.22), transparent 55%), radial-gradient(100% 70% at 85% 18%, rgba(148,119,255,0.22), transparent 58%), linear-gradient(180deg, #091526 0%, #101D35 58%, #091526 100%)'
          : 'radial-gradient(110% 80% at 20% 8%, rgba(88,221,245,0.26), transparent 55%), radial-gradient(90% 70% at 85% 15%, rgba(148,119,255,0.18), transparent 55%), linear-gradient(180deg, #F3FAFF 0%, #DFF1FF 52%, #EDF6FF 100%)',
      }}
    >
      {/* Aurora Curtains */}
      <div
        className={`absolute -top-24 left-[-10%] h-[420px] w-[120%] rounded-full blur-3xl ${
          lowEffects ? 'opacity-30' : 'animate-aurora-curtain opacity-65'
        }`}
        style={{
          background:
            'linear-gradient(90deg, rgba(88,221,245,0.30) 0%, rgba(64,141,255,0.26) 45%, rgba(148,119,255,0.32) 85%, transparent 100%)',
        }}
      />

      {/* Soft Floating Clouds */}
      {!lowEffects && (
        <>
          <div
            className="animate-cloud-drift absolute top-[18%] left-[4%] h-48 w-96 rounded-full blur-3xl"
            style={{ background: isDark ? 'rgba(169,229,255,0.11)' : 'rgba(255,255,255,0.75)' }}
          />
          <div
            className="animate-cloud-drift absolute top-[52%] right-[6%] h-56 w-[440px] rounded-full blur-3xl"
            style={{
              animationDelay: '-9s',
              background: isDark ? 'rgba(148,119,255,0.12)' : 'rgba(169,229,255,0.45)',
            }}
          />
        </>
      )}

      {/* Translucent Floating Ice Crystals */}
      {!lowEffects && (
        <>
          <svg
            viewBox="0 0 120 120"
            className="animate-crystal-float absolute top-[14%] right-[10%] h-24 w-24 opacity-35"
          >
            <polygon
              points="60,6 108,48 82,112 34,104 12,46"
              fill={isDark ? 'rgba(169,229,255,0.14)' : 'rgba(64,141,255,0.12)'}
              stroke="rgba(243,250,255,0.42)"
              strokeWidth="1.5"
            />
          </svg>
          <svg
            viewBox="0 0 100 100"
            className="animate-crystal-float absolute bottom-[16%] left-[7%] h-20 w-20 opacity-30"
            style={{ animationDelay: '-4s' }}
          >
            <polygon
              points="50,4 92,38 74,94 24,90 8,40"
              fill={isDark ? 'rgba(148,119,255,0.16)' : 'rgba(88,221,245,0.16)'}
              stroke="rgba(169,229,255,0.48)"
              strokeWidth="1.5"
            />
          </svg>
        </>
      )}

      {/* Subtle Snow-like Crystal Particles */}
      {!lowEffects &&
        SNOW_PARTICLES.map((p, idx) => (
          <span
            key={idx}
            className="animate-snow-drift absolute rounded-full"
            style={{
              left: p.left,
              top: p.top,
              width: p.size,
              height: p.size,
              animationDelay: p.delay,
              background: isDark ? 'rgba(243,250,255,0.75)' : 'rgba(64,141,255,0.45)',
              boxShadow: '0 0 10px rgba(88,221,245,0.7)',
            }}
          />
        ))}
    </div>
  );
};
