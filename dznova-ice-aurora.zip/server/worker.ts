/**
 * DZNOVA Ice Aurora v3.1.0 — Cloudflare Worker Serverless Proxy & Overlay Relay
 *
 * 1. Secure Cloud Neural TTS Proxy (NO API keys ever reach the browser):
 *    - GET  /api/tts/voices -> runtime voice list from configured provider (verifies Arabic ar-DZ/ar-* voices)
 *    - POST /api/tts/speak  -> returns audio/mpeg bytes
 * 2. Cross-Process Overlay Relay (bridges Dashboard -> OBS Studio / TikTok LIVE Studio):
 *    - POST /api/relay/:room/publish -> pushes event/settings to room subscribers
 *    - GET  /api/relay/:room/stream  -> Server-Sent Events (SSE) stream for browser sources
 *    - PUT  /api/relay/:room/sound/:id -> temporarily stores custom sound (<= 3MB) for overlay fetch
 *    - GET  /api/relay/:room/sound/:id -> serves custom sound audio to OBS/TikTok browser sources
 */

interface Env {
  TTS_PROVIDER?: 'azure' | 'google' | 'elevenlabs';
  AZURE_SPEECH_KEY?: string;
  AZURE_SPEECH_REGION?: string;
  GOOGLE_TTS_KEY?: string;
  ELEVENLABS_API_KEY?: string;
}

const roomSubscribers = new Map<string, Set<WritableStreamDefaultWriter<Uint8Array>>>();
const roomSounds = new Map<string, { bytes: ArrayBuffer; contentType: string }>();

const CORS_HEADERS: Record<string, string> = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...CORS_HEADERS },
  });
}

async function handleListVoices(env: Env): Promise<Response> {
  const provider = env.TTS_PROVIDER;
  if (provider === 'azure' && env.AZURE_SPEECH_KEY && env.AZURE_SPEECH_REGION) {
    const res = await fetch(
      `https://${env.AZURE_SPEECH_REGION}.tts.speech.microsoft.com/cognitiveservices/voices/list`,
      { headers: { 'Ocp-Apim-Subscription-Key': env.AZURE_SPEECH_KEY } },
    );
    if (!res.ok) return json({ error: 'Azure voice list failed' }, res.status);
    const list = (await res.json()) as Array<{
      ShortName: string;
      LocalName: string;
      Locale: string;
      Gender: string;
    }>;
    const voices = list
      .filter((v) => /^(ar|en|fr)-/i.test(v.Locale))
      .map((v) => ({
        id: v.ShortName,
        name: `${v.LocalName} (${v.Locale})`,
        lang: v.Locale,
        gender: v.Gender.toLowerCase() === 'female' ? 'female' : 'male',
        isNatural: true,
      }));
    return json({ provider: 'azure', hasArabicDz: voices.some((v) => v.lang.toLowerCase() === 'ar-dz'), voices });
  }

  if (provider === 'google' && env.GOOGLE_TTS_KEY) {
    const res = await fetch(`https://texttospeech.googleapis.com/v1/voices?key=${encodeURIComponent(env.GOOGLE_TTS_KEY)}`);
    if (!res.ok) return json({ error: 'Google TTS voice list failed' }, res.status);
    const data = (await res.json()) as {
      voices?: Array<{ name: string; languageCodes: string[]; ssmlGender: string }>;
    };
    const voices = (data.voices ?? [])
      .filter((v) => v.languageCodes.some((c) => /^(ar|en|fr)/i.test(c)))
      .map((v) => ({
        id: v.name,
        name: v.name,
        lang: v.languageCodes[0] ?? 'ar-XA',
        gender: v.ssmlGender === 'FEMALE' ? 'female' : 'male',
        isNatural: true,
      }));
    return json({ provider: 'google', voices });
  }

  if (provider === 'elevenlabs' && env.ELEVENLABS_API_KEY) {
    const res = await fetch('https://api.elevenlabs.io/v1/voices', {
      headers: { 'xi-api-key': env.ELEVENLABS_API_KEY },
    });
    if (!res.ok) return json({ error: 'ElevenLabs voice list failed' }, res.status);
    const data = (await res.json()) as { voices?: Array<{ voice_id: string; name: string }> };
    const voices = (data.voices ?? []).map((v) => ({
      id: v.voice_id,
      name: `${v.name} (Multilingual v2)`,
      lang: 'ar-DZ',
      gender: 'neutral',
      isNatural: true,
    }));
    return json({ provider: 'elevenlabs', voices });
  }

  return json({ error: 'No Cloud Neural TTS provider configured in Worker secrets.', voices: [] }, 503);
}

async function handleSpeak(request: Request, env: Env): Promise<Response> {
  const body = (await request.json()) as {
    text?: string;
    lang?: string;
    voiceId?: string;
    rate?: number;
    pitch?: number;
  };
  const text = (body.text ?? '').trim().slice(0, 400);
  if (!text) return json({ error: 'Empty text' }, 400);

  if (env.TTS_PROVIDER === 'azure' && env.AZURE_SPEECH_KEY && env.AZURE_SPEECH_REGION) {
    const voice = body.voiceId || 'ar-DZ-AminaNeural';
    const ratePct = Math.round(((body.rate ?? 1) - 1) * 100);
    const pitchPct = Math.round(((body.pitch ?? 1) - 1) * 40);
    const escaped = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const ssml = `<speak version="1.0" xml:lang="${body.lang || 'ar-DZ'}"><voice name="${voice}"><prosody rate="${ratePct >= 0 ? '+' : ''}${ratePct}%" pitch="${pitchPct >= 0 ? '+' : ''}${pitchPct}%">${escaped}</prosody></voice></speak>`;
    const res = await fetch(
      `https://${env.AZURE_SPEECH_REGION}.tts.speech.microsoft.com/cognitiveservices/v1`,
      {
        method: 'POST',
        headers: {
          'Ocp-Apim-Subscription-Key': env.AZURE_SPEECH_KEY,
          'Content-Type': 'application/ssml+xml',
          'X-Microsoft-OutputFormat': 'audio-24khz-48kbitrate-mono-mp3',
        },
        body: ssml,
      },
    );
    if (!res.ok) return json({ error: 'Azure synthesis failed' }, res.status);
    return new Response(res.body, { headers: { 'Content-Type': 'audio/mpeg', ...CORS_HEADERS } });
  }

  if (env.TTS_PROVIDER === 'elevenlabs' && env.ELEVENLABS_API_KEY && body.voiceId) {
    const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(body.voiceId)}`, {
      method: 'POST',
      headers: {
        'xi-api-key': env.ELEVENLABS_API_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ text, model_id: 'eleven_multilingual_v2' }),
    });
    if (!res.ok) return json({ error: 'ElevenLabs synthesis failed' }, res.status);
    return new Response(res.body, { headers: { 'Content-Type': 'audio/mpeg', ...CORS_HEADERS } });
  }

  return json({ error: 'Cloud Neural TTS provider not configured.' }, 503);
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: CORS_HEADERS });
    }
    const url = new URL(request.url);

    if (url.pathname === '/api/health') {
      return json({ ok: true, service: 'dznova-relay', version: '3.1.0' });
    }
    if (url.pathname === '/api/tts/voices' && request.method === 'GET') {
      return handleListVoices(env);
    }
    if (url.pathname === '/api/tts/speak' && request.method === 'POST') {
      return handleSpeak(request, env);
    }

    const streamMatch = url.pathname.match(/^\/api\/relay\/([A-Za-z0-9_-]+)\/stream$/);
    if (streamMatch && request.method === 'GET') {
      const room = streamMatch[1];
      const { readable, writable } = new TransformStream<Uint8Array, Uint8Array>();
      const writer = writable.getWriter();
      const enc = new TextEncoder();
      if (!roomSubscribers.has(room)) roomSubscribers.set(room, new Set());
      roomSubscribers.get(room)!.add(writer);
      void writer.write(enc.encode(`data: ${JSON.stringify({ kind: 'relay_connected', payload: { room, ts: Date.now() } })}\n\n`));
      return new Response(readable, {
        headers: {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          Connection: 'keep-alive',
          ...CORS_HEADERS,
        },
      });
    }

    const pubMatch = url.pathname.match(/^\/api\/relay\/([A-Za-z0-9_-]+)\/publish$/);
    if (pubMatch && request.method === 'POST') {
      const room = pubMatch[1];
      const payload = await request.text();
      const subs = roomSubscribers.get(room);
      const enc = new TextEncoder();
      if (subs) {
        const frame = enc.encode(`data: ${payload}\n\n`);
        for (const w of Array.from(subs)) {
          w.write(frame).catch(() => subs.delete(w));
        }
      }
      return json({ delivered: subs?.size ?? 0 });
    }

    const soundMatch = url.pathname.match(/^\/api\/relay\/([A-Za-z0-9_-]+)\/sound\/([A-Za-z0-9_-]+)$/);
    if (soundMatch) {
      const key = `${soundMatch[1]}:${soundMatch[2]}`;
      if (request.method === 'PUT') {
        const bytes = await request.arrayBuffer();
        if (bytes.byteLength > 3 * 1024 * 1024) return json({ error: 'Sound exceeds 3MB limit' }, 413);
        roomSounds.set(key, { bytes, contentType: request.headers.get('Content-Type') || 'audio/mpeg' });
        return json({ stored: true, key });
      }
      if (request.method === 'GET') {
        const item = roomSounds.get(key);
        if (!item) return json({ error: 'Not found' }, 404);
        return new Response(item.bytes, { headers: { 'Content-Type': item.contentType, ...CORS_HEADERS } });
      }
    }

    return json({ error: 'Not found' }, 404);
  },
};
