import React from 'react';

export interface DzIconProps {
  size?: number;
  className?: string;
  active?: boolean;
}

interface IconShellProps extends DzIconProps {
  id: string;
  from: string;
  via?: string;
  to: string;
  children: React.ReactNode;
}

export const IconShell: React.FC<IconShellProps> = ({
  id,
  from,
  via,
  to,
  size = 28,
  className = '',
  active = false,
  children,
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    className={`dz-icon-3d shrink-0 ${active ? 'drop-shadow-[0_0_10px_rgba(88,221,245,0.65)]' : ''} ${className}`}
    aria-hidden="true"
  >
    <defs>
      <linearGradient id={`${id}-bg`} x1="4" y1="4" x2="44" y2="44" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor={from} />
        {via && <stop offset="50%" stopColor={via} />}
        <stop offset="100%" stopColor={to} />
      </linearGradient>
      <linearGradient id={`${id}-spec`} x1="8" y1="4" x2="40" y2="26" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#F3FAFF" stopOpacity="0.62" />
        <stop offset="100%" stopColor="#F3FAFF" stopOpacity="0.02" />
      </linearGradient>
      <linearGradient id={`${id}-glass`} x1="6" y1="6" x2="42" y2="42" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#F3FAFF" stopOpacity="0.34" />
        <stop offset="100%" stopColor="#A9E5FF" stopOpacity="0.08" />
      </linearGradient>
    </defs>
    {/* Base 3D Squircle */}
    <rect x="3" y="3" width="42" height="42" rx="13" fill={`url(#${id}-bg)`} />
    {/* Specular Top Reflection */}
    <path d="M16 4H32C38.6 4 44 9.4 44 16V18C35 23 13 23 4 18V16C4 9.4 9.4 4 16 4Z" fill={`url(#${id}-spec)`} />
    {/* Crystal Inner Rim */}
    <rect x="3.75" y="3.75" width="40.5" height="40.5" rx="12.25" stroke="#F3FAFF" strokeOpacity="0.35" strokeWidth="1.2" />
    {children}
  </svg>
);
