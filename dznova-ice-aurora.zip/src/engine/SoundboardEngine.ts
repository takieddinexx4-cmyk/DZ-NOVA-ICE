import type { SoundPad } from '../types/dznova';

export const DEFAULT_SOUND_PADS: SoundPad[] = [
  { id: 's1', nameAr: 'جرس الكريستال', nameEn: 'Crystal Chime', preset: 'chime', triggerOnGift: true },
  { id: 's2', nameAr: 'بوق الحماس', nameEn: 'Hype Airhorn', preset: 'airhorn', triggerOnGift: false },
  { id: 's3', nameAr: 'ترقية المستوى', nameEn: 'Level Up', preset: 'levelup', triggerOnGift: false },
  { id: 's4', nameAr: 'سقوط العملات', nameEn: 'Coin Drop', preset: 'coin', triggerOnGift: true },
  { id: 's5', nameAr: 'شعاع أورورا', nameEn: 'Aurora Laser', preset: 'laser', triggerOnGift: false },
  { id: 's6', nameAr: 'فوز الولاية', nameEn: 'Wilaya Victory', preset: 'victory', triggerOnGift: false },
  { id: 's7', nameAr: 'تنبيه عاجل', nameEn: 'Stream Alert', preset: 'alert', triggerOnGift: false },
  { id: 's8', nameAr: 'قرع الطبول', nameEn: 'Drum Roll', preset: 'drum', triggerOnGift: false },
];

export function playSoundPreset(preset: SoundPad['preset'], volume = 0.25): void {
  if (typeof window === 'undefined') return;
  const AudioCtx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioCtx) return;

  try {
    const ctx = new AudioCtx();
    const now = ctx.currentTime;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(Math.max(0.02, Math.min(0.8, volume)), now);
    gain.connect(ctx.destination);

    const osc = ctx.createOscillator();
    osc.connect(gain);

    if (preset === 'chime') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(660, now);
      osc.frequency.exponentialRampToValueAtTime(1180, now + 0.28);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
      osc.start(now);
      osc.stop(now + 0.36);
    } else if (preset === 'airhorn') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(340, now);
      osc.frequency.linearRampToValueAtTime(420, now + 0.12);
      osc.frequency.setValueAtTime(415, now + 0.45);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.55);
      osc.start(now);
      osc.stop(now + 0.56);
    } else if (preset === 'levelup') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.setValueAtTime(554, now + 0.1);
      osc.frequency.setValueAtTime(659, now + 0.2);
      osc.frequency.setValueAtTime(880, now + 0.3);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.48);
      osc.start(now);
      osc.stop(now + 0.5);
    } else if (preset === 'coin') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(988, now);
      osc.frequency.setValueAtTime(1319, now + 0.08);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
      osc.start(now);
      osc.stop(now + 0.3);
    } else if (preset === 'laser') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(1200, now);
      osc.frequency.exponentialRampToValueAtTime(180, now + 0.32);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.34);
      osc.start(now);
      osc.stop(now + 0.35);
    } else if (preset === 'victory') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(523, now);
      osc.frequency.setValueAtTime(659, now + 0.12);
      osc.frequency.setValueAtTime(784, now + 0.24);
      osc.frequency.setValueAtTime(1046, now + 0.36);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
      osc.start(now);
      osc.stop(now + 0.62);
    } else if (preset === 'alert') {
      osc.type = 'square';
      osc.frequency.setValueAtTime(740, now);
      osc.frequency.setValueAtTime(540, now + 0.14);
      osc.frequency.setValueAtTime(740, now + 0.28);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.44);
      osc.start(now);
      osc.stop(now + 0.45);
    } else {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(140, now);
      osc.frequency.exponentialRampToValueAtTime(65, now + 0.3);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);
      osc.start(now);
      osc.stop(now + 0.34);
    }

    setTimeout(() => {
      void ctx.close().catch(() => undefined);
    }, 750);
  } catch {
    // Ignore autoplay errors gracefully
  }
}
