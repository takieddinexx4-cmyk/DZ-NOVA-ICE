# DZNOVA — ICE AURORA EDITION (v3.0)

**Two Streaming Platforms. One Intelligent Streaming Ecosystem.**

DZNOVA Ice Aurora Edition is a unified live streaming control center supporting both **TikTok LIVE Studio** and **OBS Studio**, paired with a **Tauri v2 Windows Desktop Companion** and the original **Ice Aurora** liquid-glass visual identity.

## Key Capabilities
- **Unified Dual-Platform Hub (`/app/streaming-platforms`)**: Dedicated setup wizards, compatibility profiles (`obs_standard`, `tiktok_standard`, `lightweight`, `high_quality`), revocable secure Browser Source URLs, and optional secure OBS WebSocket v5 testing.
- **Honest Connection Monitor**: Separately tracks `url_generated`, `overlay_opened`, `browser_source_loaded`, `events_received`, and `integration_verified` — never marking a platform connected merely because a URL was copied.
- **Shared Zero-WebGL Overlay Engine**: 7 transparent 1920×1080 overlays (`alerts`, `goal`, `wilaya`, `chat`, `wheel`, `countdown`, `leaderboard`) with `AudioQueue`, reconnection handling, and live token revocation.
- **Ice Aurora Visual System**: Original DZNOVA logo suite (wordmark, symbol, monochrome, `.ico`, animated intro), 54 distinct 3D crystal SVG icons, Dark/Light themes, Arabic RTL / English / French, and Low-Effects Mode.
- **Windows Desktop Companion (`src-tauri/`)**: Standalone Tauri v2 app for local diagnostics, secure token storage, asset caching, and native notifications, while keeping the web platform 100% usable standalone.
