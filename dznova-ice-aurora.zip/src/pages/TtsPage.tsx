import React, { useEffect, useMemo, useState } from 'react';
import { useDznova } from '../context/DznovaContext';
import { GlassBadge, GlassButton, GlassCard } from '../components/GlassUI';
import { sharedAudioQueue, type AudioQueueSnapshot } from '../engine/AudioQueue';
import { sharedTtsManager, renderTtsTemplate } from '../engine/tts/TtsManager';
import { normalizeArabicText } from '../engine/tts/arabicText';
import {
  VOICE_PRESETS,
  type ArabicDialect,
  type TtsDiagnostics,
  type TtsEventKind,
  type TtsSettings,
  type TtsVoiceInfo,
  type VoicePresetId,
} from '../engine/tts/types';
import { DiagnosticsIcon, TtsIcon } from '../components/icons';
import { t } from '../i18n/translations';

const EVENT_KINDS: { id: TtsEventKind; labelAr: string; labelEn: string }[] = [
  { id: 'gift', labelAr: 'الهدايا', labelEn: 'Gifts' },
  { id: 'follow', labelAr: 'المتابعة', labelEn: 'Follows' },
  { id: 'share', labelAr: 'المشاركة', labelEn: 'Shares' },
  { id: 'chat', labelAr: 'الدردشة', labelEn: 'Chat' },
  { id: 'wilaya_win', labelAr: 'فوز الولاية', labelEn: 'Wilaya Win' },
  { id: 'automation', labelAr: 'الأتمتة', labelEn: 'Automation' },
];

export const TtsPage: React.FC = () => {
  const { lang, pushToast } = useDznova();
  const isAr = lang === 'ar';

  const [settings, setSettings] = useState<TtsSettings>(() => sharedTtsManager.getSettings());
  const [voices, setVoices] = useState<TtsVoiceInfo[]>([]);
  const [diag, setDiag] = useState<TtsDiagnostics | null>(null);
  const [queueSnap, setQueueSnap] = useState<AudioQueueSnapshot>(() => sharedAudioQueue.getSnapshot());
  const [sampleText, setSampleText] = useState<string>(
    'يعطيك الصحة Amine_DZ16 على هدية Crystal Crown بقيمة 199 عملة لولاية 16!',
  );
  const [activeEventKind, setActiveEventKind] = useState<TtsEventKind>('gift');
  const [dictFrom, setDictFrom] = useState('');
  const [dictTo, setDictTo] = useState('');

  const reloadVoices = async () => {
    const res = await sharedTtsManager.refreshVoices();
    setVoices(res.voices);
    setDiag(res.diagnostics);
  };

  useEffect(() => {
    void reloadVoices();
    return sharedAudioQueue.subscribe(setQueueSnap);
  }, []);

  const update = (patch: Partial<TtsSettings>) => {
    const next = sharedTtsManager.updateSettings(patch);
    setSettings({ ...next });
  };

  const groupedVoices = useMemo(() => {
    const groups: Record<string, TtsVoiceInfo[]> = { Arabic: [], English: [], French: [], Other: [] };
    for (const v of voices) {
      const l = v.lang.toLowerCase();
      if (l.startsWith('ar')) groups.Arabic.push(v);
      else if (l.startsWith('en')) groups.English.push(v);
      else if (l.startsWith('fr')) groups.French.push(v);
      else groups.Other.push(v);
    }
    return groups;
  }, [voices]);

  const normalizedPreview = useMemo(
    () =>
      settings.lang.toLowerCase().startsWith('ar')
        ? normalizeArabicText(sampleText, { dictionary: settings.dictionary, maxLength: settings.maxLength })
        : sampleText,
    [sampleText, settings.dictionary, settings.lang, settings.maxLength],
  );

  const previewPreset = (presetId: VoicePresetId) => {
    const p = VOICE_PRESETS[presetId];
    update({ selectedPreset: presetId, pitch: p.pitch, rate: p.rate });
    sharedAudioQueue.enqueue({
      id: `tts_prev_${Date.now()}`,
      kind: 'tts',
      priority: 3,
      text: sampleText,
      lang: settings.lang,
      presetId,
      pitch: p.pitch,
      rate: p.rate,
      volume: settings.volume,
    });
  };

  const activeRule = settings.eventRules[activeEventKind];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="ice-title-plate">
          <TtsIcon size={40} />
          <div>
            <h1 className="text-xl font-extrabold sm:text-2xl">{t(lang, 'navTts')}</h1>
            <p className="text-xs opacity-75">
              {isAr
                ? 'محرك نطق عربي مطوّر مع تطبيع النص، تقسيم الجمل، 7 أصوات قابلة للمعاينة، ومزود سحابي اختياري.'
                : 'Upgraded Arabic TTS with text normalization, chunking, 7 voice presets, and optional neural proxy.'}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <GlassBadge tone={queueSnap.playing ? 'emerald' : 'cyan'}>
            {isAr ? `الطابور: ${queueSnap.pendingCount}` : `Queue: ${queueSnap.pendingCount}`}
          </GlassBadge>
          <GlassButton size="sm" onClick={() => sharedAudioQueue.skipCurrent()}>
            {isAr ? 'تخطي الحالي' : 'Skip Current'}
          </GlassButton>
          <GlassButton size="sm" variant="danger" onClick={() => sharedAudioQueue.clear()}>
            {isAr ? 'إيقاف الكل' : 'Clear Queue'}
          </GlassButton>
        </div>
      </div>

      {/* Honest Missing-Arabic-Voice Warning */}
      {diag && !diag.hasArabicVoice && (
        <GlassCard className="border-amber-400/50 bg-amber-500/10 text-xs space-y-2">
          <p className="font-extrabold text-amber-200">
            {isAr
              ? 'تنبيه مهم: لم يتم العثور على صوت عربي مثبّت في هذا المتصفح!'
              : 'Warning: No Arabic system voice was detected in this browser.'}
          </p>
          <p className="opacity-90">
            {isAr
              ? 'لتشغيل النطق العربي بشكل صحيح: في ويندوز افتح Settings → Time & Language → Speech → Add voices (العربية)، أو في أندرويد ثبّت حزمة العربية من Google Speech Services، أو اربط رابط خادم Cloud Neural TTS (/server) أدناه للعمل داخل OBS و TikTok LIVE Studio.'
              : 'Install an Arabic speech pack in Windows/Android Speech Settings, or connect a Cloud Neural TTS Worker URL (/server) below so OBS and TikTok LIVE Studio speak natural Arabic reliably.'}
          </p>
        </GlassCard>
      )}

      {/* Voice Presets Grid */}
      <GlassCard className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-base font-extrabold">{isAr ? 'قوالب الأصوات (اضغط للمعاينة)' : 'Voice Presets (Tap to Preview)'}</h2>
          <GlassBadge tone={diag?.isNeuralActive ? 'emerald' : 'amber'}>
            {diag?.isNeuralActive
              ? isAr ? 'مزود عصبي سحابي نشط' : 'Neural Cloud Active'
              : isAr ? 'محرك المتصفح المحلي (WebSpeech)' : 'Local Browser WebSpeech'}
          </GlassBadge>
        </div>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {(Object.keys(VOICE_PRESETS) as VoicePresetId[]).map((pid) => {
            const p = VOICE_PRESETS[pid];
            const selected = settings.selectedPreset === pid;
            const showApprox = p.approximatedOnWebSpeech && !diag?.isNeuralActive;
            return (
              <div
                key={pid}
                className={`rounded-2xl border p-3.5 transition ${
                  selected ? 'border-ice-glacier bg-ice-glacier/15' : 'border-ice-crystal/20 bg-ice-midnight/45'
                }`}
              >
                <div className="flex items-center justify-between gap-1">
                  <span className="text-sm font-extrabold">{isAr ? p.nameAr : p.nameEn}</span>
                  {showApprox && (
                    <GlassBadge tone="amber" className="text-[10px] px-2 py-0.5">
                      {isAr ? 'تقريبي' : 'Approximated'}
                    </GlassBadge>
                  )}
                </div>
                <p className="mt-1 text-[11px] opacity-75">{isAr ? p.noteAr : p.noteEn}</p>
                <div className="mt-3 flex items-center justify-between">
                  <span className="font-mono text-[10px] opacity-70">P:{p.pitch} • R:{p.rate}</span>
                  <GlassButton size="sm" variant={selected ? 'primary' : 'secondary'} onClick={() => previewPreset(pid)}>
                    {isAr ? 'معاينة' : 'Preview'}
                  </GlassButton>
                </div>
              </div>
            );
          })}
        </div>
      </GlassCard>

      {/* Voice Dropdown, Sliders & Live Arabic Normalization Preview */}
      <div className="grid gap-6 lg:grid-cols-2">
        <GlassCard className="space-y-4">
          <h2 className="text-base font-extrabold">{isAr ? 'إعدادات الصوت واللغة' : 'Voice, Language & Sliders'}</h2>
          <div className="grid gap-3 sm:grid-cols-2 text-xs">
            <label className="space-y-1">
              <span className="font-bold">{isAr ? 'لغة النطق' : 'Speech Language'}</span>
              <select
                value={settings.lang}
                onChange={(e) => update({ lang: e.target.value })}
                className="w-full rounded-xl border border-ice-crystal/25 bg-ice-midnight/75 px-3 py-2 text-ice-white"
              >
                <option value="ar-DZ">العربية — الجزائر (ar-DZ)</option>
                <option value="ar-SA">العربية — فصحى (ar-SA)</option>
                <option value="ar-EG">العربية — مصر (ar-EG)</option>
                <option value="en-US">English (en-US)</option>
                <option value="fr-FR">Français (fr-FR)</option>
              </select>
            </label>
            <label className="space-y-1">
              <span className="font-bold">{isAr ? 'لهجة قوالب الأحداث' : 'Arabic Template Dialect'}</span>
              <select
                value={settings.dialect}
                onChange={(e) => update({ dialect: e.target.value as ArabicDialect })}
                className="w-full rounded-xl border border-ice-crystal/25 bg-ice-midnight/75 px-3 py-2 text-ice-white"
              >
                <option value="dz">{isAr ? 'دارجة جزائرية' : 'Algerian Dialect (DZ)'}</option>
                <option value="msa">{isAr ? 'العربية الفصحى' : 'Modern Standard Arabic'}</option>
              </select>
            </label>
          </div>

          <label className="block space-y-1 text-xs">
            <span className="font-bold">{isAr ? 'اختيار صوت محدد من النظام/السحابة' : 'Specific Voice Override'}</span>
            <select
              value={settings.selectedVoiceId}
              onChange={(e) => update({ selectedVoiceId: e.target.value })}
              className="w-full rounded-xl border border-ice-crystal/25 bg-ice-midnight/75 px-3 py-2 text-ice-white"
            >
              <option value="">{isAr ? 'تلقائي (أفضل صوت عربي متاح)' : 'Auto (Best Ranked Arabic Voice)'}</option>
              {Object.entries(groupedVoices).map(([grp, list]) =>
                list.length > 0 ? (
                  <optgroup key={grp} label={`${grp} (${list.length})`}>
                    {list.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.name} [{v.lang}]
                      </option>
                    ))}
                  </optgroup>
                ) : null,
              )}
            </select>
          </label>

          <div className="grid gap-3 sm:grid-cols-3 text-xs">
            <label>
              <span>{isAr ? `السرعة: ${settings.rate.toFixed(2)}` : `Rate: ${settings.rate.toFixed(2)}`}</span>
              <input type="range" min="0.6" max="1.6" step="0.05" value={settings.rate} onChange={(e) => update({ rate: Number(e.target.value) })} className="w-full" />
            </label>
            <label>
              <span>{isAr ? `الطبقة: ${settings.pitch.toFixed(2)}` : `Pitch: ${settings.pitch.toFixed(2)}`}</span>
              <input type="range" min="0.5" max="1.8" step="0.05" value={settings.pitch} onChange={(e) => update({ pitch: Number(e.target.value) })} className="w-full" />
            </label>
            <label>
              <span>{isAr ? `الصوت: ${Math.round(settings.volume * 100)}%` : `Volume: ${Math.round(settings.volume * 100)}%`}</span>
              <input type="range" min="0.1" max="1" step="0.05" value={settings.volume} onChange={(e) => update({ volume: Number(e.target.value) })} className="w-full" />
            </label>
          </div>

          <textarea
            rows={2}
            value={sampleText}
            onChange={(e) => setSampleText(e.target.value)}
            className="w-full rounded-xl border border-ice-crystal/25 bg-ice-midnight/60 p-3 text-sm text-ice-white"
          />
          <div className="rounded-xl bg-ice-midnight/50 p-2.5 text-[11px]">
            <span className="font-bold text-ice-glacier">{isAr ? 'النص بعد التطبيع العربي:' : 'Normalized Arabic Output:'} </span>
            <span className="opacity-90">{normalizedPreview}</span>
          </div>
          <GlassButton
            variant="primary"
            onClick={() => {
              sharedAudioQueue.enqueue({
                id: `tts_manual_${Date.now()}`,
                kind: 'tts',
                priority: 3,
                text: sampleText,
                lang: settings.lang,
                presetId: settings.selectedPreset,
                rate: settings.rate,
                pitch: settings.pitch,
                volume: settings.volume,
              });
              pushToast(isAr ? 'تمت الإضافة إلى طابور النطق' : 'Queued for TTS', undefined, 'cyan');
            }}
          >
            {isAr ? 'نطق النص الآن' : 'Speak Now'}
          </GlassButton>
        </GlassCard>

        {/* Diagnostics + Cloud Neural Proxy */}
        <GlassCard className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <DiagnosticsIcon size={26} />
              <h2 className="text-base font-extrabold">{isAr ? 'تشخيص الأصوات والمزود السحابي' : 'Voice Diagnostics & Cloud Neural Proxy'}</h2>
            </div>
            <GlassButton size="sm" onClick={() => void reloadVoices()}>
              {isAr ? 'تحديث الفحص' : 'Re-check'}
            </GlassButton>
          </div>

          {diag && (
            <dl className="grid grid-cols-2 gap-2 text-xs">
              <div className="rounded-xl bg-ice-midnight/50 p-3">
                <dt className="opacity-65">{isAr ? 'المزود النشط' : 'Active Provider'}</dt>
                <dd className="mt-1 font-mono font-bold text-ice-glacier">{diag.activeProvider}</dd>
              </div>
              <div className="rounded-xl bg-ice-midnight/50 p-3">
                <dt className="opacity-65">{isAr ? 'الأصوات المكتشفة' : 'Voices Detected'}</dt>
                <dd className="mt-1 font-mono font-bold">{diag.voicesCount} ({diag.arabicVoicesCount} Arabic)</dd>
              </div>
              <div className="rounded-xl bg-ice-midnight/50 p-3 col-span-2">
                <dt className="opacity-65">{isAr ? 'أفضل صوت عربي متاح' : 'Best Arabic Voice'}</dt>
                <dd className="mt-1 font-bold text-emerald-300">{diag.bestArabicVoice ?? (isAr ? 'غير متوفر محلياً' : 'None detected locally')}</dd>
              </div>
              {diag.lastError && (
                <div className="rounded-xl border border-rose-400/40 bg-rose-500/10 p-3 col-span-2 text-rose-200">
                  {diag.lastError}
                </div>
              )}
            </dl>
          )}

          <div className="space-y-2 rounded-xl border border-ice-crystal/20 bg-ice-midnight/45 p-3.5 text-xs">
            <p className="font-bold text-ice-crystal">
              {isAr ? 'رابط خادم Cloud Neural TTS الاختياري (/server)' : 'Optional Cloud Neural TTS Worker URL (/server)'}
            </p>
            <input
              value={settings.cloudProxyUrl}
              onChange={(e) =>
                update({
                  cloudProxyUrl: e.target.value,
                  preferredProvider: e.target.value.trim() ? 'cloud_neural' : 'web_speech',
                })
              }
              placeholder="https://dznova-ice-aurora-relay.yourname.workers.dev"
              className="w-full rounded-xl border border-ice-crystal/25 bg-ice-midnight/80 px-3 py-2 font-mono text-[11px] text-ice-white"
            />
            <p className="text-[11px] opacity-75">
              {isAr
                ? 'لا يتم تخزين أي مفاتيح API داخل المتصفح — الخادم الوسيط في مجلد /server يتولى الاتصال بـ Azure/Google/ElevenLabs.'
                : 'API keys never live in client code — deploy /server Cloudflare Worker with your provider secrets.'}
            </p>
          </div>

          {/* Editable Pronunciation Dictionary */}
          <div className="space-y-2 text-xs">
            <p className="font-bold">{isAr ? 'قاموس النطق المخصص (الولايات والهدايا)' : 'Custom Pronunciation Dictionary'}</p>
            <div className="flex gap-2">
              <input value={dictFrom} onChange={(e) => setDictFrom(e.target.value)} placeholder="DZ" className="w-28 rounded-xl border border-ice-crystal/25 bg-ice-midnight/60 px-2.5 py-1.5 text-ice-white" />
              <input value={dictTo} onChange={(e) => setDictTo(e.target.value)} placeholder="الجزائر" className="flex-1 rounded-xl border border-ice-crystal/25 bg-ice-midnight/60 px-2.5 py-1.5 text-ice-white" />
              <GlassButton
                size="sm"
                variant="primary"
                onClick={() => {
                  if (!dictFrom.trim() || !dictTo.trim()) return;
                  update({ dictionary: [...settings.dictionary, { from: dictFrom.trim(), to: dictTo.trim() }] });
                  setDictFrom('');
                  setDictTo('');
                }}
              >
                +
              </GlassButton>
            </div>
            <div className="flex max-h-24 flex-wrap gap-1.5 overflow-y-auto">
              {settings.dictionary.map((d, i) => (
                <span key={`${d.from}-${i}`} className="ice-pill rounded-lg px-2 py-0.5 text-[10px]">
                  {d.from} → {d.to}
                </span>
              ))}
            </div>
          </div>
        </GlassCard>
      </div>

      {/* Per-Event TTS Assignment & Templates */}
      <GlassCard className="space-y-4">
        <h2 className="text-base font-extrabold">{isAr ? 'تخصيص النطق لكل حدث (قوالب + فلاتر)' : 'Per-Event Voice Rules & Templates'}</h2>
        <div className="flex flex-wrap gap-2">
          {EVENT_KINDS.map((ek) => (
            <GlassButton
              key={ek.id}
              size="sm"
              variant={activeEventKind === ek.id ? 'primary' : 'secondary'}
              onClick={() => setActiveEventKind(ek.id)}
            >
              {isAr ? ek.labelAr : ek.labelEn}
            </GlassButton>
          ))}
        </div>

        <div className="grid gap-3 md:grid-cols-3 text-xs">
          <label className="flex items-center justify-between rounded-xl bg-ice-midnight/50 p-3">
            <span>{isAr ? 'تفعيل النطق لهذا الحدث' : 'Enable TTS for Event'}</span>
            <input
              type="checkbox"
              checked={activeRule.enabled}
              onChange={(e) =>
                update({
                  eventRules: { ...settings.eventRules, [activeEventKind]: { ...activeRule, enabled: e.target.checked } },
                })
              }
            />
          </label>
          <label className="space-y-1">
            <span className="font-bold">{isAr ? 'قالب الصوت للحدث' : 'Event Voice Preset'}</span>
            <select
              value={activeRule.presetId}
              onChange={(e) =>
                update({
                  eventRules: { ...settings.eventRules, [activeEventKind]: { ...activeRule, presetId: e.target.value as VoicePresetId } },
                })
              }
              className="w-full rounded-xl border border-ice-crystal/25 bg-ice-midnight/75 px-3 py-2 text-ice-white"
            >
              {(Object.keys(VOICE_PRESETS) as VoicePresetId[]).map((pid) => (
                <option key={pid} value={pid}>
                  {isAr ? VOICE_PRESETS[pid].nameAr : VOICE_PRESETS[pid].nameEn}
                </option>
              ))}
            </select>
          </label>
          <label className="space-y-1">
            <span className="font-bold">{isAr ? 'الحد الأدنى للعملات / مهلة المستخدم (ث)' : 'Min Coins / Cooldown (s)'}</span>
            <div className="flex gap-2">
              <input
                type="number"
                value={settings.minGiftCoins}
                onChange={(e) => update({ minGiftCoins: Math.max(0, Number(e.target.value) || 0) })}
                className="w-1/2 rounded-xl border border-ice-crystal/25 bg-ice-midnight/75 px-2.5 py-2 text-ice-white"
              />
              <input
                type="number"
                value={settings.userCooldownSec}
                onChange={(e) => update({ userCooldownSec: Math.max(0, Number(e.target.value) || 0) })}
                className="w-1/2 rounded-xl border border-ice-crystal/25 bg-ice-midnight/75 px-2.5 py-2 text-ice-white"
              />
            </div>
          </label>
        </div>

        <label className="block space-y-1 text-xs">
          <span className="font-bold">
            {isAr ? 'قالب الرسالة (المتغيرات: {username} {gift} {coins} {wilaya} {count})' : 'Message Template ({username} {gift} {coins} {wilaya} {count})'}
          </span>
          <input
            value={settings.dialect === 'dz' ? activeRule.templateArDz : activeRule.templateArMsa}
            onChange={(e) => {
              const key = settings.dialect === 'dz' ? 'templateArDz' : 'templateArMsa';
              update({
                eventRules: { ...settings.eventRules, [activeEventKind]: { ...activeRule, [key]: e.target.value } },
              });
            }}
            className="w-full rounded-xl border border-ice-crystal/25 bg-ice-midnight/75 px-3 py-2 text-ice-white"
          />
        </label>

        <GlassButton
          size="sm"
          variant="primary"
          onClick={() => {
            const tpl = settings.dialect === 'dz' ? activeRule.templateArDz : activeRule.templateArMsa;
            const rendered = renderTtsTemplate(tpl, {
              username: 'Amine_DZ16',
              gift: 'Crystal Crown',
              coins: 199,
              wilaya: 'الجزائر',
              count: 3,
              message: 'تحية لكل المتابعين!',
            });
            sharedAudioQueue.enqueue({
              id: `tts_evt_test_${Date.now()}`,
              kind: 'tts',
              priority: 3,
              text: rendered,
              lang: settings.lang,
              presetId: activeRule.presetId,
              rate: activeRule.rate,
              volume: activeRule.volume,
            });
          }}
        >
          {isAr ? 'اختبار قالب الحدث' : 'Test Event Template'}
        </GlassButton>
      </GlassCard>
    </div>
  );
};
